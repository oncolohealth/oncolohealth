#!/usr/bin/env bash
# Install what the NGC PyTorch image lacks. Uses a venv on the PVC so it survives restarts
# and keeps the container's CUDA torch (--system-site-packages).
set -euo pipefail
source "$(dirname "$0")/env.sh"
VENV="$WORK/venv"
if [ ! -d "$VENV" ]; then python3 -m venv --system-site-packages "$VENV"; fi
source "$VENV/bin/activate"
pip install -q --upgrade "transformers>=5.8" peft accelerate datasets scikit-learn huggingface_hub hf_transfer
python3 -c "import transformers, peft; print('transformers', transformers.__version__, 'peft', peft.__version__)"
echo "activate later with: source $VENV/bin/activate"
