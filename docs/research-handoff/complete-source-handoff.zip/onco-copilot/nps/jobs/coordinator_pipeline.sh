#!/usr/bin/env bash
# Full coordinator pipeline on one node with N GPUs (default 4 = one GB300 tray):
#   1. serve base Gemma (data-parallel replicas)  2. eval base (tool use + GSM8K retention)
#   3. generate self-distilled tool-use SFT data  4. LoRA SFT on N GPUs
#   5. merge + serve  6. eval tuned model on the same held-out tasks
# Each stage skips if its output already exists, so the job can be resubmitted after preemption.
set -euo pipefail
source "$(dirname "$0")/../env.sh"
[ -f "$WORK/venv/bin/activate" ] && source "$WORK/venv/bin/activate"
NGPU="${NGPU:-$(nvidia-smi -L | wc -l)}"
BASE="$HF_HOME/gemma-4-31B-it"
[ -d "$BASE" ] || { echo "Gemma weights missing at $BASE; acquire explicitly before this job" >&2; exit 1; }
[ -f "${GEMMA_CHAT_TEMPLATE:-}" ] || { echo "Set GEMMA_CHAT_TEMPLATE to vLLM's official Gemma 4 tool chat template" >&2; exit 1; }
URL=http://127.0.0.1:8000/v1
GSM=${GSM8K_N:-300}

serve() {  # $1 model path, $2 served name
  vllm serve "$1" --served-model-name "$2" --data-parallel-size "$NGPU" --max-model-len 65536 \
    --kv-cache-dtype fp8 --reasoning-parser gemma4 --enable-auto-tool-choice --tool-call-parser gemma4 \
    --chat-template "$GEMMA_CHAT_TEMPLATE" \
    --host 127.0.0.1 --port 8000 > "$WORK/vllm_$2.log" 2>&1 &
  VLLM_PID=$!
  for i in $(seq 1 180); do curl -sf $URL/models >/dev/null && return 0; sleep 10; done
  echo "vLLM did not come up; see $WORK/vllm_$2.log"; exit 1
}
stop() { kill "$VLLM_PID" 2>/dev/null || true; wait "$VLLM_PID" 2>/dev/null || true; sleep 5; }

if [ ! -f "$ONCO_RESULTS_DIR/coordinator_eval_base.json" ] || [ ! -f "$WORK/sft/train.jsonl" ]; then
  serve "$BASE" base
  [ -f "$ONCO_RESULTS_DIR/coordinator_eval_base.json" ] || python3 -m training.coordinator.evaluate --base-url $URL --model base --tag base --gsm8k "$GSM"
  [ -f "$ONCO_RESULTS_DIR/coordinator_eval_base_thinking.json" ] || python3 -m training.coordinator.evaluate --base-url $URL --model base --tag base_thinking --thinking
  [ -f "$WORK/sft/train.jsonl" ] || python3 -m training.coordinator.make_sft_data --base-url $URL --model base --out "$WORK/sft/train.jsonl" --samples 3 --paraphrases 4 --workers $((NGPU * 8))
  stop
fi
cp "$WORK/sft/train.stats.json" "$ONCO_RESULTS_DIR/sft_stats.json" 2>/dev/null || true

if [ ! -d "$WORK/ckpt/onco-lora/adapter" ]; then
  torchrun --nproc_per_node "$NGPU" -m training.coordinator.train_lora --data "$WORK/sft/train.jsonl" \
    --model "$BASE" --out "$WORK/ckpt/onco-lora" --epochs "${EPOCHS:-2}"
fi
if [ ! -d "$WORK/models/onco-gemma-4-31b-it" ]; then
  python3 -m training.coordinator.merge_lora --base "$BASE" --adapter "$WORK/ckpt/onco-lora/adapter" --out "$WORK/models/onco-gemma-4-31b-it"
fi
serve "$WORK/models/onco-gemma-4-31b-it" onco-lora
python3 -m training.coordinator.evaluate --base-url $URL --model onco-lora --tag lora --gsm8k "$GSM"
stop
python3 - <<'EOF'
import json, os
r = os.environ["ONCO_RESULTS_DIR"]
rows = {}
for tag in ("base", "base_thinking", "lora"):
    p = f"{r}/coordinator_eval_{tag}.json"
    if os.path.exists(p):
        rows[tag] = json.load(open(p))["summary"]
keys = ["required_tool_recall", "full_tool_coverage_rate", "invalid_calls_per_task", "unsupported_numbers_per_task", "completion_rate", "median_latency_s", "gsm8k_accuracy"]
print(f"{'metric':32}" + "".join(f"{t:>16}" for t in rows))
for k in keys:
    print(f"{k:32}" + "".join(f"{rows[t].get(k, float('nan')):>16.3f}" if isinstance(rows[t].get(k), (int, float)) else f"{'-':>16}" for t in rows))
json.dump(rows, open(f"{r}/coordinator_summary.json", "w"), indent=2)
EOF
