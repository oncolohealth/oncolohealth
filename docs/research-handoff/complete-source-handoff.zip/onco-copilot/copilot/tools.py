"""Tools the coordinator can call. Each returns JSON-serializable observed results."""

import json
import math
import os
import shlex
from pathlib import Path

from cancer_workbench.core import plan_experiment
from . import contract, evaluation, research

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RESULTS = Path(os.environ.get("ONCO_RESULTS_DIR", ROOT / "results"))


def load_json(path):
    return json.loads(Path(path).read_text())


def datasets():
    return load_json(DATA / "datasets.json")


def registry():
    reg = load_json(DATA / "models.json")
    # A specialist becomes runnable once its training run has written a model card.
    for m in reg:
        card = RESULTS / f"{m['id']}.card.json"
        if card.exists():
            info = load_json(card)
            m["state"] = "locally_reproduced"
            m["version"] = info.get("version", m["version"])
            m["metrics"] = info.get("metrics")
    return reg


def _norm(x):
    return (x or "").strip().lower().replace("-", "").replace(" ", "")


MODALITY_ALIASES = {"xray": "X-ray", "radiograph": "X-ray", "ct": "CT", "mri": "MRI", "mr": "MRI",
                    "pathology": "pathology", "histology": "pathology", "wsi": "pathology",
                    "genomics": "genomics", "rnaseq": "genomics"}


def _modality(x):
    return MODALITY_ALIASES.get(_norm(x), x)


# ---------------------------------------------------------------- tools

def t_search_literature(query, max_results=8, since_year=None, reviews_only=False):
    return research.search_literature(query, max_results, since_year, reviews_only)


def t_find_models(task, modality=None, anatomy=None, include_hub=True, hub_query=None):
    reg = registry()
    req = {"task": task, "modality": _modality(modality), "anatomy": anatomy}
    local = contract.discover(req, reg) if modality and anatomy else {
        "status": "needs_input", "missing": [k for k in ("modality", "anatomy") if not req.get(k)]}
    # encoders/coordinators that generalize across anatomies
    general = [{"model_id": m["id"], "kind": m["kind"], "params": m.get("params"), "license": m.get("license"),
                "notes": m.get("notes"), "serving": m.get("serving")}
               for m in reg if m.get("kind") in ("encoder", "vision_language", "coordinator")
               and (not modality or _modality(modality) in m.get("modalities", []) or m["kind"] == "coordinator")]
    out = {"registry_match": local, "general_backbones": general}
    if include_hub:
        q = hub_query or " ".join(x for x in (modality, anatomy, task.replace("_", " ")) if x)
        out["hub_latest"] = research.search_hf_models(q, max_results=8, sort="lastModified")
        out["hub_popular"] = research.search_hf_models(q, max_results=8, sort="downloads")
    out["selection_rule"] = ("Prefer a model whose training data, license, input spec and reported evaluation match the task; "
                             "registry compatibility is necessary, not sufficient. Never pick by parameter count.")
    return out


def t_find_datasets(modality=None, anatomy=None, task=None, include_gdc=False):
    mod = _modality(modality) if modality else None
    hits = []
    for d in datasets():
        if mod and d["modality"] != mod:
            continue
        if anatomy and anatomy not in d["anatomy"] and "multiple" not in d["anatomy"]:
            continue
        if task and task not in d["tasks"]:
            continue
        hits.append(d)
    out = {"catalog_matches": hits, "catalog_size": len(datasets())}
    if include_gdc or mod == "genomics":
        out["gdc_projects"] = research.search_gdc_projects(primary_site=anatomy.title() if anatomy else None)
    if not hits:
        out["next_step"] = "No curated match. Search literature for dataset papers (e.g. 'dataset' + modality + cancer) and TCIA/IDC collections."
    return out


def _n_for_proportion(p, half_width, z=1.96):
    return math.ceil(z * z * p * (1 - p) / (half_width * half_width))


def t_specify_dataset(task, modality, anatomy, classes=None, expected_sensitivity=0.85,
                      expected_specificity=0.85, ci_half_width=0.07, prevalence=None):
    """What a dataset must contain to train and credibly test a new model."""
    classes = classes or (["normal", "benign", "malignant"] if task == "classification" else [])
    mod = _modality(modality)
    n_pos = _n_for_proportion(expected_sensitivity, ci_half_width)
    n_neg = _n_for_proportion(expected_specificity, ci_half_width)
    spec = {
        "task": task, "modality": mod, "anatomy": anatomy, "classes": classes,
        "required_fields": ["unique image/study id", "pseudonymous patient id (for grouped splits)",
                            "acquisition site / scanner / source", "label per class definition",
                            "reference standard for each label (histopathology, follow-up, expert consensus)",
                            "image file checksum", "license and permitted uses"],
        "recommended_fields": ["age", "sex", "anatomical site", "view/sequence", "acquisition date", "label confidence / reader count"],
        "label_quality": ["Malignancy labels should be histopathology-confirmed where possible",
                          "Record who labeled, how many readers, and disagreement handling",
                          "Keep 'abnormal' or 'suspicious' distinct from confirmed cancer"],
        "independent_test_set": {
            "method": "Normal-approximation sample size for a proportion (Buderer 1996)",
            "target_ci_half_width": ci_half_width,
            "min_positive_cases": n_pos, "min_negative_cases": n_neg,
            "note": "Count independent patients, not images. Prefer a different site than training (external validation)."},
        "splits": ["Group by patient (and duplicate/near-duplicate family) before splitting",
                   "Hold out an entire site/source for external testing when possible",
                   "Freeze the test set and endpoint before looking at results"],
        "leakage_checks": ["patient overlap", "exact/near duplicate images across splits", "burned-in text or markers that encode the label",
                           "site-label confounding (one site contributes mostly one class)"],
    }
    if prevalence:
        spec["independent_test_set"]["total_patients_at_prevalence"] = math.ceil(n_pos / prevalence)
    if mod == "MRI":
        spec["required_fields"].append("all required sequences (e.g. T1, T1c, T2, FLAIR) co-registered")
    if mod == "pathology":
        spec["required_fields"].append("slide magnification/MPP and stain; tile-to-slide-to-patient mapping")
    if mod == "CT":
        spec["required_fields"].append("voxel spacing and reconstruction kernel; DICOM series UID")
    if task in ("segmentation", "detection"):
        spec["required_fields"].append("pixel masks or boxes with annotator id; annotation protocol")
    return spec


def t_audit_dataset(dataset_id):
    """Audit a dataset: catalog evidence plus local file checks if the data is present."""
    d = next((x for x in datasets() if x["id"] == dataset_id), None)
    if not d:
        return {"status": "needs_input", "detail": "Unknown dataset id", "known": [x["id"] for x in datasets()]}
    out = {"dataset": d["id"], "catalog_evidence": {k: d.get(k) for k in ("size", "sources", "labels", "license", "patient_ids", "release", "md5")},
           "cautions": d.get("cautions", [])}
    split_file = RESULTS / f"{dataset_id}_split.json"
    if split_file.exists():
        out["local_split"] = load_json(split_file)
        out["status"] = ("local_split_ready" if out["local_split"].get("ready_for_training") is True
                         else "local_split_exploratory")
    else:
        out["status"] = "data_not_local"
        out["next_step"] = f"Run nps/fetch_data.sh then python3 -m training.btxrd.prepare to build the split." if dataset_id == "btxrd" else "Acquire the data, then build a grouped split."
    return out


def t_plan_training(path, model_id, dataset_id, gpu_count=1, max_hours=2, max_storage_gb=200, profile_reference=None):
    model = next((m for m in registry() if m["id"] == model_id), None)
    if not model:
        return {"status": "needs_input", "detail": "Unknown model id", "known": [m["id"] for m in registry()]}
    audit = None
    split_file = RESULTS / f"{dataset_id}_split.json"
    if split_file.exists():
        s = load_json(split_file)
        audit = {"status": "declared_checks_passed" if s.get("status") == "ready" and s.get("ready_for_training") is True else "blocked",
                 "dataset_id": dataset_id, "dataset_version": s.get("release"),
                 "modality": s.get("modality"), "anatomy": s.get("anatomy")}
    plan = plan_experiment(path, model, audit, {"gpu_count": gpu_count, "max_hours": max_hours,
                                                "max_storage_gb": max_storage_gb, "profile_reference": profile_reference})
    scripts = {
        ("transfer_learning", "btxrd-medsiglip-head"): "bash nps/jobs/btxrd_medsiglip.sh",
        ("transfer_learning", "btxrd-cnn-baseline"): "bash nps/jobs/btxrd_cnn.sh",
        ("specialist_tools", "gemma-4-31b-it"): "NGPU=4 bash nps/jobs/coordinator_pipeline.sh",
    }
    cmd = scripts.get((path, model_id))
    if cmd and plan["status"] == "draft_ready_for_review":
        plan["command_on_nps"] = cmd
        plan["runai_hint"] = ("runai training submit <name> -p <project> -g " + str(gpu_count) +
                              " --image ${TRAIN_IMAGE} --existing-pvc claimname=<pvc>,path=/workspace -- " + shlex.quote(cmd))
    plan["submission"] = "Never auto-submitted. A human must review and submit on NPS."
    return plan


def t_list_results():
    if not RESULTS.exists():
        return {"results": []}
    out = []
    for f in sorted(RESULTS.glob("*.metrics.json")):
        m = load_json(f)
        out.append({"file": f.name, "model_id": m.get("model_id"), "partition": m.get("partition"), "n": m.get("n"),
                    "balanced_accuracy": m.get("balanced_accuracy"), "macro_f1": m.get("macro_f1"),
                    "malignant": (m.get("per_class") or {}).get("malignant"), "ci95": m.get("ci95")})
    preds = sorted(f.name for f in RESULTS.glob("*.predictions.json"))
    return {"results": out, "prediction_files": preds}


def _safe_result(name):
    p = (RESULTS / name).resolve()
    if not str(p).startswith(str(RESULTS.resolve())) or not p.exists():
        raise ValueError("Prediction file not found in results/: " + name)
    return load_json(p)


def t_compare_models(predictions_a, predictions_b, positive_class="malignant"):
    try:
        return evaluation.compare(_safe_result(predictions_a), _safe_result(predictions_b), positive=positive_class, bootstrap=500)
    except ValueError as e:
        return {"status": "blocked", "error": str(e)}


def t_evaluate_model(predictions, positive_class="malignant"):
    try:
        return evaluation.evaluate(_safe_result(predictions), positive=positive_class, bootstrap=500)
    except ValueError as e:
        return {"status": "blocked", "error": str(e)}


def t_run_specialist(model_id, task, modality, anatomy, input_ref, execution_authorization_ref=None):
    from .adapters import ADAPTERS, AUTHORIZATIONS
    req = {"request_id": "chat-" + os.urandom(4).hex(), "model_id": model_id, "task": task,
           "modality": _modality(modality), "anatomy": anatomy, "input_refs": [input_ref],
           "execution_authorization_ref": execution_authorization_ref}
    return contract.execute(req, registry(), ADAPTERS, AUTHORIZATIONS, contract.DEFAULT_SCHEMAS)


# ---------------------------------------------------------------- schemas

def _fn(name, description, props, required):
    return {"type": "function", "function": {"name": name, "description": description, "parameters": {
        "type": "object", "properties": props, "required": required, "additionalProperties": False}}}


S = {"type": "string"}
SCHEMAS = [
    _fn("search_literature", "Search peer-reviewed literature and preprints (Europe PMC). Use for methods, benchmarks, prior results, and citations.",
        {"query": S, "max_results": {"type": "integer"}, "since_year": {"type": "integer"}, "reviews_only": {"type": "boolean"}}, ["query"]),
    _fn("find_models", "Recommend models for a task: registry compatibility plus the newest and most-used open-weight models on Hugging Face.",
        {"task": S, "modality": S, "anatomy": S, "include_hub": {"type": "boolean"}, "hub_query": S}, ["task"]),
    _fn("find_datasets", "Find existing datasets for a modality/anatomy/task from the curated catalog (and GDC for genomics).",
        {"modality": S, "anatomy": S, "task": S, "include_gdc": {"type": "boolean"}}, []),
    _fn("specify_dataset", "Specify exactly what a dataset must contain to train and credibly test a new model, including minimum independent test-set size.",
        {"task": S, "modality": S, "anatomy": S, "classes": {"type": "array", "items": S},
         "expected_sensitivity": {"type": "number"}, "expected_specificity": {"type": "number"},
         "ci_half_width": {"type": "number"}, "prevalence": {"type": "number"}}, ["task", "modality", "anatomy"]),
    _fn("audit_dataset", "Audit a dataset's evidence, cautions, and local split status.", {"dataset_id": S}, ["dataset_id"]),
    _fn("plan_training", "Draft a reproducible training plan and the NPS command. Never submits.",
        {"path": {"type": "string", "enum": ["specialist_tools", "transfer_learning", "distillation"]},
         "model_id": S, "dataset_id": S, "gpu_count": {"type": "integer"}, "max_hours": {"type": "number"},
         "max_storage_gb": {"type": "number"}, "profile_reference": S}, ["path", "model_id", "dataset_id"]),
    _fn("list_results", "List completed experiment metrics and prediction files.", {}, []),
    _fn("evaluate_model", "Compute metrics with 95% bootstrap CIs for a prediction file in results/.",
        {"predictions": S, "positive_class": S}, ["predictions"]),
    _fn("compare_models", "Paired statistical comparison of two models on identical test samples (bootstrap CI on balanced-accuracy difference, McNemar).",
        {"predictions_a": S, "predictions_b": S, "positive_class": S}, ["predictions_a", "predictions_b"]),
    _fn("run_specialist", "Run one explicitly selected specialist model through the gated execution contract.",
        {"model_id": S, "task": S, "modality": S, "anatomy": S, "input_ref": S, "execution_authorization_ref": S},
        ["model_id", "task", "modality", "anatomy", "input_ref"]),
]

IMPL = {"search_literature": t_search_literature, "find_models": t_find_models, "find_datasets": t_find_datasets,
        "specify_dataset": t_specify_dataset, "audit_dataset": t_audit_dataset, "plan_training": t_plan_training,
        "list_results": t_list_results, "evaluate_model": t_evaluate_model, "compare_models": t_compare_models,
        "run_specialist": t_run_specialist}


def call(name, arguments):
    if name not in IMPL:
        return {"status": "blocked", "error": "Unknown tool " + name}
    schema = next(s["function"]["parameters"] for s in SCHEMAS if s["function"]["name"] == name)
    from cancer_workbench.core import _validate_arguments
    try:
        _validate_arguments(arguments, schema)
    except ValueError as e:
        return {"status": "needs_input", "error": str(e)}
    try:
        return IMPL[name](**arguments)
    except Exception as e:
        return {"status": "failed", "error": type(e).__name__ + ": " + str(e)[:300]}
