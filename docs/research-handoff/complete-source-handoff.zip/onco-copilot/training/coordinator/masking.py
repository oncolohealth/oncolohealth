"""Locate assistant turns without assuming a model's token syntax."""


def render_assistant_spans(tokenizer, messages, tools=None):
    """Return rendered chat and assistant character spans or fail closed.

    Prefix stability ensures the spans cannot include user or tool content.
    """
    if not messages or messages[0].get("role") == "assistant":
        raise ValueError("A training conversation must start with a non-assistant turn")
    prefixes = [None]
    for end in range(1, len(messages) + 1):
        prefixes.append(tokenizer.apply_chat_template(
            messages[:end], tools=tools, tokenize=False,
            add_generation_prompt=False, enable_thinking=False))
    full = prefixes[-1]
    spans = []
    for i, message in enumerate(messages):
        if i == 0 or message.get("role") != "assistant":
            continue
        before, after = prefixes[i], prefixes[i + 1]
        if not after.startswith(before) or not full.startswith(after):
            raise ValueError("Chat template is not prefix-stable; assistant masking needs review")
        spans.append((len(before), len(after)))
    if not spans:
        raise ValueError("No assistant turns to train on")
    return full, spans
