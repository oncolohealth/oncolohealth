#!/usr/bin/env bash
# Explicitly download model weights into the PVC cache (Gemma 4 31B BF16 ~70 GB plus MedSigLIP).
# MedSigLIP is gated: accept the terms at https://huggingface.co/google/medsiglip-448
# with the account whose token is in HF_TOKEN.
set -euo pipefail
source "$(dirname "$0")/env.sh"
export HF_HUB_ENABLE_HF_TRANSFER=1
df -h "$WORK" | tail -1
hf download "$GEMMA_MODEL" --local-dir "$HF_HOME/gemma-4-31B-it" || huggingface-cli download "$GEMMA_MODEL" --local-dir "$HF_HOME/gemma-4-31B-it"
hf download "$MEDSIGLIP" --local-dir "$HF_HOME/medsiglip-448" || huggingface-cli download "$MEDSIGLIP" --local-dir "$HF_HOME/medsiglip-448"
du -sh "$HF_HOME"/*
