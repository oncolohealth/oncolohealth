# Cancer workspace: proposed integration contract

Status: design proposal only. Not integrated, executed, or clinically validated.

## Scope and evidence
Reviewed Collaboration-context.md, especially the architecture, existing-software status, and documented entry points. No foundation source files, model weights, or datasets were supplied. The document reports existing tests; those tests were not rerun here. This proposal makes no medical-performance claim.

## First contribution: separate catalog discovery from execution
Keep the documented route_models(request, registry) and execute_specialist(model, request, adapters) signatures unchanged until their source is inspected. Introduce the following contract as a separate integration layer, not a claimed patch.

### Proposed request fields
- request_id: stable identifier for this request.
- task, modality, anatomy: explicit values; missing values produce needs_input, never guessed defaults.
- input_refs: references to permitted inputs, not embedded patient data.
- model_id and model_revision: explicit selection for execution; discovery may omit these.
- execution_authorization_ref: reference to a separately verified authorization record.

### Proposed result fields
- request_id, run_id, model_id, model_revision, adapter_id.
- status: needs_input, blocked, failed, or succeeded.
- output_kind: classification, detection, segmentation, or embedding.
- native_output: adapter-specific output, preserving label order and units where applicable.
- input_refs and preprocessing_revision.
- evidence_refs: references to reviewed compatibility and reproduction evidence.
- error: structured code and safe explanation; null on success.
- started_at and finished_at: actual observed timestamps, never estimated values.

These are proposed fields, not representations of the existing implementation.

## Proposed execution gates
1. Validate required request fields and supported task/modality/anatomy combinations.
2. Resolve an exact registry record and installed adapter.
3. Check the documented locally_reproduced state and reviewed inference permission, preserving existing behavior.
4. Independently resolve evidence and authorization references. A user-supplied Boolean must not authorize execution.
5. Validate adapter-specific inputs before invocation.
6. Invoke the adapter once; preserve its actual result or failure.
7. Validate the returned output against that adapter's declared schema.
8. Record provenance. Report succeeded only after validation and recording complete.

This is a proposed application gate, not a sandbox or a complete security boundary.

## Acceptance tests to implement once source is available
| Case | Required behavior |
| --- | --- |
| Missing modality | needs_input; adapter not called |
| Unknown model | blocked; no fallback model silently selected |
| Catalog-only model | blocked; adapter not called |
| Permission missing or denied | blocked; adapter not called |
| Authorization reference unresolved | blocked; adapter not called |
| Input incompatible with adapter | blocked; adapter not called |
| Adapter raises an exception | failed; no invented prediction |
| Adapter returns malformed output | failed; malformed output not presented as valid |
| Valid synthetic adapter result | succeeded; preserve exact output and provenance |
| Multiple compatible candidates | discovery returns candidates; execution requires explicit selection |

All future test fixtures should be clearly marked synthetic. These tests would establish software behavior, not cancer-detection accuracy.

## Prioritized handoff
1. Inspect core.py and test_foundation.py before implementing this contract. Check actual return shapes, errors, and registry semantics.
2. Implement a standalone validator and synthetic adapter tests without changing existing entry-point signatures.
3. Connect a coordinator only after blocked and failed outcomes are handled explicitly.
4. Keep the real-data workflow blocked pending reviewed cohort/grouping evidence and a defined endpoint. This proposal does not resolve those research dependencies.

## Verification performed here
- Read the supplied context document.
- Checked the available local files: only the context document was present.
- Produced this design artifact; no repository patch, automated test execution, dataset acquisition, training, or specialist inference was performed.

Source: supplied Collaboration-context.md. All new contract fields, gates, and acceptance tests above are recommendations, not verified existing features.
