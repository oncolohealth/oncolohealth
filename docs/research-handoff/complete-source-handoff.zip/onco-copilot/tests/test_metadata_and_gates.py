"""Synthetic checks for BTXRD metadata intake and research-only gates."""

import json
import csv
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from training.btxrd.metadata import read_metadata, read_xlsx
from training.btxrd.prepare import find_images
from training.coordinator.masking import render_assistant_spans

ROOT = Path(__file__).resolve().parents[1]


class MetadataIntake(unittest.TestCase):
    def test_visual_matches_do_not_move_external_images_and_label_conflicts_are_excluded(self):
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow needed for visual-candidate check")
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "images").mkdir()
            rows = [
                ("IMG000001", "1", "0", "0", "0"),
                ("IMG000002", "1", "1", "1", "0"),
                ("IMG000003", "1", "0", "0", "0"),
                ("IMG000004", "2", "1", "0", "1"),
                ("IMG000005", "3", "0", "0", "0"),
            ]
            with (root / "dataset.csv").open("w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(["image_id", "center", "tumor", "benign", "malignant"])
                writer.writerows(rows)
            for index in (1, 2, 4, 5):
                Image.new("RGB", (16, 16), (index * 25, 0, 0)).save(root / "images" / f"IMG{index:06d}.jpeg")
            (root / "images" / "IMG000003.jpeg").write_bytes(
                (root / "images" / "IMG000002.jpeg").read_bytes())
            result = subprocess.run([sys.executable, "-B", "-m", "training.btxrd.prepare",
                                     "--root", str(root), "--out", str(root / "out")],
                                    cwd=ROOT, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            with (root / "out" / "btxrd_manifest.csv").open(newline="") as stream:
                manifest = list(csv.DictReader(stream))
            self.assertEqual({r["image_id"] for r in manifest},
                             {"IMG000001.jpeg", "IMG000004.jpeg", "IMG000005.jpeg"})
            self.assertTrue(all(r["split"] == "external_test" for r in manifest if r["center"] != "1"))
            split = json.loads((root / "out" / "btxrd_split.json").read_text())
            self.assertEqual(split["excluded"]["conflicting_exact_label"], 2)
            self.assertGreater(split["duplicates"]["near_candidate_pairs"], 0)

    def test_published_xlsx_layout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            book = root / "dataset.xlsx"
            sheet = '''<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>
              <row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c><c r="C1" t="inlineStr"><is><t>tumor</t></is></c></row>
              <row r="2"><c r="A2" t="s"><v>2</v></c><c r="B2"><v>1</v></c><c r="C2"><v>0</v></c></row>
              <row r="3"><c r="A3" t="s"><v>3</v></c><c r="B3"><v>2</v></c><c r="C3"><v>1</v></c></row>
            </sheetData></worksheet>'''
            strings = '''<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
              <si><t>image_id</t></si><si><t>center</t></si><si><t>IMG000001</t></si><si><t>IMG000002</t></si>
            </sst>'''
            with ZipFile(book, "w") as archive:
                archive.writestr("xl/worksheets/sheet1.xml", sheet)
                archive.writestr("xl/sharedStrings.xml", strings)
            fields, rows, source = read_metadata(root)
            self.assertEqual(source, book)
            self.assertEqual(fields, ["image_id", "center", "tumor"])
            self.assertEqual(rows, [{"image_id": "IMG000001", "center": "1", "tumor": "0"},
                                    {"image_id": "IMG000002", "center": "2", "tumor": "1"}])

    def test_missing_metadata_is_explicit(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, "dataset.xlsx or dataset.csv"):
                read_metadata(tmp)

    def test_ambiguous_inputs_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for folder in (root / "a", root / "b"):
                folder.mkdir()
                (folder / "dataset.xlsx").write_bytes(b"synthetic")
                (folder / "same.jpeg").write_bytes(b"synthetic")
            with self.assertRaisesRegex(ValueError, "Multiple dataset.xlsx"):
                read_metadata(root)
            with self.assertRaisesRegex(ValueError, "Ambiguous BTXRD image name"):
                find_images(root)

    def test_prepare_accepts_xlsx_but_never_marks_patient_ready(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "images").mkdir()
            for index in (1, 2):
                image = root / "images" / f"IMG{index:06d}.jpeg"
                try:
                    from PIL import Image
                except ImportError:
                    image.write_bytes(f"synthetic-image-{index}".encode())
                else:
                    Image.new("RGB", (16, 16), (index * 70, 20, 30)).save(image)
            headers = ["image_id", "center", "tumor", "benign", "malignant"]
            def cell(column, row, value):
                return f'<c r="{column}{row}" t="inlineStr"><is><t>{value}</t></is></c>'
            sheet = '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
            sheet += '<row r="1">' + ''.join(cell(chr(65 + i), 1, value) for i, value in enumerate(headers)) + '</row>'
            for row, values in enumerate((("IMG000001", "1", "0", "0", "0"),
                                          ("IMG000002", "2", "1", "1", "0")), start=2):
                sheet += f'<row r="{row}">' + ''.join(cell(chr(65 + i), row, value) for i, value in enumerate(values)) + '</row>'
            sheet += '</sheetData></worksheet>'
            with ZipFile(root / "dataset.xlsx", "w") as archive:
                archive.writestr("xl/worksheets/sheet1.xml", sheet)
            result = subprocess.run([sys.executable, "-B", "-m", "training.btxrd.prepare",
                                     "--root", str(root), "--out", str(root / "out")],
                                    cwd=ROOT, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            split = json.loads((root / "out" / "btxrd_split.json").read_text())
            self.assertEqual(split["metadata_file"], "dataset.xlsx")
            self.assertEqual(split["status"], "exploratory_only")
            self.assertIs(split["ready_for_training"], False)


class ExploratoryGate(unittest.TestCase):
    def test_patient_grouping_block_requires_explicit_opt_in(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "btxrd_split.json"
            path.write_text(json.dumps({"status": "exploratory_only", "ready_for_training": False}))
            command = [sys.executable, "-B", "-m", "training.btxrd.guard", str(path)]
            env = {**os.environ, "ONCO_ALLOW_EXPLORATORY_BTXRD": ""}
            blocked = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
            self.assertNotEqual(blocked.returncode, 0)
            self.assertIn("patient grouping", blocked.stderr)
            env["ONCO_ALLOW_EXPLORATORY_BTXRD"] = "1"
            allowed = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
            self.assertEqual(allowed.returncode, 0)
            self.assertIn("Exploratory", allowed.stdout)


class AssistantMasking(unittest.TestCase):
    def test_only_assistant_turn_is_selected(self):
        class Tokenizer:
            def apply_chat_template(self, messages, **kwargs):
                return "<bos>" + "".join(f"<{m['role']}>{m['content']}</{m['role']}>" for m in messages)
        messages = [{"role": "system", "content": "rules"}, {"role": "user", "content": "question"},
                    {"role": "assistant", "content": "answer"}, {"role": "tool", "content": "evidence"}]
        text, spans = render_assistant_spans(Tokenizer(), messages)
        selected = "".join(text[a:b] for a, b in spans)
        self.assertIn("answer", selected)
        self.assertNotIn("question", selected)
        self.assertNotIn("evidence", selected)

    def test_unstable_template_fails_closed(self):
        class Tokenizer:
            def apply_chat_template(self, messages, **kwargs):
                return str(len(messages)) + "".join(m["content"] for m in messages)
        with self.assertRaisesRegex(ValueError, "prefix-stable"):
            render_assistant_spans(Tokenizer(), [{"role": "user", "content": "a"},
                                                {"role": "assistant", "content": "b"}])


if __name__ == "__main__":
    unittest.main()
