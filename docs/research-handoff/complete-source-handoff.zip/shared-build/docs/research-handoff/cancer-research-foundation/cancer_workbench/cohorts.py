"""Offline BTXRD metadata intake and proposed grouped partitions.

No image acquisition, image inspection, training, or remote execution.
Patient mappings and digests are supplied evidence, not independently verified.
"""

from collections import Counter, defaultdict
from pathlib import PurePosixPath, PureWindowsPath
import hashlib
import json
import math


CLASSES = ("normal", "benign", "malignant")
PARTITIONS = ("train", "validation", "test")
UNRESOLVED = {"", "unknown", "unavailable", "none", "n/a", "na", "not provided",
              "pending", "tbd", "unreviewed"}


def _text(value):
    return "" if value is None else str(value).strip()


def _flag(value):
    if isinstance(value, bool) or _text(value) not in ("0", "1"):
        raise ValueError("BTXRD tumor, benign, and malignant flags must be 0 or 1")
    return int(_text(value))


def _filename(value):
    name = _text(value)
    if (not name or name in (".", "..") or "\x00" in name
            or PurePosixPath(name).name != name or PureWindowsPath(name).name != name
            or PureWindowsPath(name).drive or "/" in name or "\\" in name
            or PurePosixPath(name).suffix.lower() not in (".jpg", ".jpeg")):
        raise ValueError("image_id must be a bare JPEG filename, not a path")
    return name


def _fractions(value):
    result = dict(value) if value is not None else {"train": 0.7, "validation": 0.15, "test": 0.15}
    if set(result) != set(PARTITIONS):
        raise ValueError("Specify train, validation, and test fractions")
    if any(isinstance(v, bool) or not isinstance(v, (int, float))
           or not math.isfinite(v) or v <= 0 for v in result.values()):
        raise ValueError("Partition fractions must be finite and positive")
    if not math.isclose(sum(result.values()), 1.0, rel_tol=0, abs_tol=1e-9):
        raise ValueError("Partition fractions must sum to one")
    return result


def _tie(seed, *values):
    return hashlib.sha256((str(seed) + "\0" + "\0".join(values)).encode()).hexdigest()


def _components(rows):
    """Join patient and exact-digest relations transitively."""
    parents = list(range(len(rows)))

    def root(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    def join(a, b):
        a, b = root(a), root(b)
        if a != b:
            parents[max(a, b)] = min(a, b)

    for field in ("patient_id", "sha256"):
        seen = {}
        for i, row in enumerate(rows):
            key = row[field]
            if key in seen:
                join(i, seen[key])
            else:
                seen[key] = i
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        groups[root(i)].append(row)
    return list(groups.values())


def _assign(groups, fractions, seed, totals):
    """Greedy draft balancing class counts and images; never split a group."""
    counts = {p: Counter() for p in PARTITIONS}
    sizes = Counter()
    total = sum(totals.values())

    def priority(group):
        hist = Counter(r["label"] for r in group)
        rarity = sum(hist[label] / totals[label] for label in CLASSES)
        names = sorted(r["sample_id"] for r in group)
        return (-rarity, -len(group), _tie(seed, *names))

    assigned = []
    for group in sorted(groups, key=priority):
        hist = Counter(r["label"] for r in group)
        names = sorted(r["sample_id"] for r in group)

        def score(partition):
            delta = 0.0
            for label in CLASSES:
                target = totals[label] * fractions[partition]
                before = counts[partition][label] - target
                delta += ((before + hist[label]) ** 2 - before ** 2) / max(target, 1.0)
            target = total * fractions[partition]
            before = sizes[partition] - target
            delta += 0.25 * ((before + len(group)) ** 2 - before ** 2) / max(target, 1.0)
            return delta, _tie(seed, *names, partition)

        partition = min(PARTITIONS, key=score)
        counts[partition].update(hist)
        sizes[partition] += len(group)
        assigned.extend({**r, "split": partition} for r in group)
    return sorted(assigned, key=lambda r: r["sample_id"]), counts


def prepare_btxrd_cohort(metadata, case_map=None, *, fractions=None, seed=17):
    """Normalize source flags and draft partitions only with declared grouping.

    Required metadata: image_id, center, tumor, benign, malignant.
    Optional sidecar joins image_id to patient_id, grouping_reference, sha256,
    and an optional file_path. It must use consistent pseudonymous patient IDs.
    A source center or image filename cannot replace patient evidence.
    """
    fractions = _fractions(fractions)
    if not isinstance(seed, int) or isinstance(seed, bool):
        raise ValueError("seed must be an integer")
    metadata = list(metadata)
    if not metadata:
        raise ValueError("BTXRD metadata is empty")
    case_map = list(case_map or [])
    mapping = {}
    for case in case_map:
        image_id = _filename(case.get("image_id"))
        if image_id in mapping:
            raise ValueError("Case map contains duplicate image_id")
        mapping[image_id] = case

    rows, seen, label_counts = [], set(), Counter()
    center_counts = defaultdict(Counter)
    missing = defaultdict(list)
    for source in metadata:
        if set(("image_id", "center", "tumor", "benign", "malignant")) - set(source):
            raise ValueError("Missing required BTXRD metadata columns")
        image_id = _filename(source["image_id"])
        if image_id in seen:
            raise ValueError("Metadata contains duplicate image_id")
        seen.add(image_id)
        tumor, benign, malignant = (_flag(source[k]) for k in ("tumor", "benign", "malignant"))
        if benign + malignant != tumor:
            raise ValueError("Contradictory BTXRD diagnostic flags for " + image_id)
        center = _text(source["center"])
        if center not in ("1", "2", "3"):
            raise ValueError("Original BTXRD center must be 1, 2, or 3")
        label = "malignant" if malignant else ("benign" if benign else "normal")
        case = mapping.get(image_id, {})
        patient = _text(case.get("patient_id"))
        reference = _text(case.get("grouping_reference"))
        digest = _text(case.get("sha256")).lower()
        if (patient.casefold() in UNRESOLVED
                or patient.casefold() in {image_id.casefold(), PurePosixPath(image_id).stem.casefold()}):
            missing["patient_group_missing_or_image_id"].append(image_id)
        if reference.casefold() in UNRESOLVED:
            missing["grouping_reference_missing"].append(image_id)
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            missing["file_digest_missing_or_invalid"].append(image_id)
        row = {"sample_id": image_id, "patient_id": patient, "grouping_reference": reference,
               "label": label, "center": center, "sha256": digest}
        if _text(case.get("file_path")):
            path = _text(case["file_path"])
            if (PurePosixPath(path).is_absolute() or PureWindowsPath(path).is_absolute()
                    or PureWindowsPath(path).drive or "\\" in path or ".." in PurePosixPath(path).parts
                    or "\x00" in path):
                raise ValueError("Sidecar file_path must be a contained relative path")
            row["file_path"] = path
        rows.append(row)
        label_counts[label] += 1
        center_counts[center][label] += 1
    if set(mapping) - seen:
        raise ValueError("Case map contains image IDs absent from metadata")

    findings = [{"level": "blocker", "code": code, "image_count": len(ids)}
                for code, ids in sorted(missing.items())]
    for label in CLASSES:
        if not label_counts[label]:
            findings.append({"level": "blocker", "code": "class_absent", "label": label})
    findings.extend([
        {"level": "warning", "code": "grouping_assertion_requires_review"},
        {"level": "warning", "code": "file_integrity_not_measured"},
        {"level": "warning", "code": "near_duplicates_not_inspected"},
        {"level": "warning", "code": "reference_labels_not_independently_reviewed"},
    ])
    report = {"dataset_id": "btxrd", "task": "bone_radiograph_three_class_classification",
              "status": "blocked", "seed": seed, "target_fractions": fractions,
              "image_count": len(rows), "class_counts": dict(label_counts),
              "counts_by_source": {c: dict(n) for c, n in sorted(center_counts.items())},
              "findings": findings, "rows": [], "submitted": False,
              "patient_independence_verified": False, "clinical_accuracy_established": False,
              "scope": "Metadata-only split draft; patient evidence, files, labels, rights, and training readiness require separate review"}
    if any(f["level"] == "blocker" for f in findings):
        return report

    digest_labels = defaultdict(set)
    for row in rows:
        digest_labels[row["sha256"]].add(row["label"])
    if any(len(labels) > 1 for labels in digest_labels.values()):
        findings.append({"level": "blocker", "code": "duplicate_label_conflict"})
        return report

    groups = _components(rows)
    report["declared_patient_count"] = len({r["patient_id"] for r in rows})
    report["linked_group_count"] = len(groups)
    class_groups = Counter(label for group in groups for label in {r["label"] for r in group})
    for label in CLASSES:
        if class_groups[label] < len(PARTITIONS):
            findings.append({"level": "blocker", "code": "too_few_independent_groups_for_class", "label": label})
    if any(f["level"] == "blocker" for f in findings):
        return report

    assigned, counts = _assign(groups, fractions, seed, label_counts)
    report["counts_by_partition"] = {p: dict(counts[p]) for p in PARTITIONS}
    report["source_counts_by_partition"] = {
        p: dict(Counter(r["center"] for r in assigned if r["split"] == p)) for p in PARTITIONS}
    for partition in PARTITIONS:
        for label in CLASSES:
            if not counts[partition][label]:
                findings.append({"level": "blocker", "code": "draft_partition_missing_class",
                                 "partition": partition, "label": label})
    if any(f["level"] == "blocker" for f in findings):
        return report
    for partition in PARTITIONS:
        observed = sum(counts[partition].values()) / len(rows)
        if abs(observed - fractions[partition]) > 0.1:
            findings.append({"level": "warning", "code": "group_size_limits_balance", "partition": partition})
    report["status"] = "split_draft_requires_review"
    report["rows"] = assigned
    report["manifest_digest"] = hashlib.sha256(json.dumps(
        assigned, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return report
