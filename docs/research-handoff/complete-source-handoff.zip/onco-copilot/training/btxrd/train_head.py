"""Train a logistic head on cached MedSigLIP embeddings (CPU, seconds).

    python3 -m training.btxrd.train_head --emb $WORK/cache/medsiglip_btxrd.npz --results results

Model selection (C) uses the validation partition only; external_test is scored once.
Writes head weights + cached test embeddings so the web app can run the specialist.
"""

import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from training.common import LABELS, read_manifest, write_outputs

MODEL_ID = "btxrd-medsiglip-head"


def bal_acc(y, p):
    pred = p.argmax(1)
    return np.mean([np.mean(pred[y == k] == k) for k in range(len(LABELS)) if np.any(y == k)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--emb", required=True)
    ap.add_argument("--results", default="results")
    a = ap.parse_args()

    z = np.load(a.emb, allow_pickle=False)
    index = {i: n for n, i in enumerate(z["ids"].tolist())}
    X_all = z["X"]
    rows = read_manifest(a.results)
    part = {}
    for split in ("train", "validation", "external_test"):
        rs = [r for r in rows if r["split"] == split and r["image_id"] in index]
        part[split] = (rs, X_all[[index[r["image_id"]] for r in rs]],
                       np.array([LABELS.index(r["label"]) for r in rs]))
    scaler = StandardScaler().fit(part["train"][1])
    tr = scaler.transform(part["train"][1])
    va = scaler.transform(part["validation"][1])
    best = None
    for C in (0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0):
        clf = LogisticRegression(C=C, max_iter=5000, class_weight="balanced").fit(tr, part["train"][2])
        score = bal_acc(part["validation"][2], clf.predict_proba(va))
        print(f"C={C}: validation balanced accuracy {score:.3f}")
        if best is None or score > best[0]:
            best = (score, C, clf)
    _, C, clf = best
    print("selected C =", C)

    def rows_for(split):
        rs, X, _ = part[split]
        P = clf.predict_proba(scaler.transform(X))
        return [{"sample_id": r["image_id"], "label": r["label"], "probabilities": [float(x) for x in p]} for r, p in zip(rs, P)]

    write_outputs(a.results, MODEL_ID, "validation", rows_for("validation"))
    write_outputs(a.results, MODEL_ID, "external_test", rows_for("external_test"),
                  {"encoder": str(z["model"]), "selected_C": C, "selection": "validation balanced accuracy"})
    out = Path(a.results)
    (out / f"{MODEL_ID}.head.json").write_text(json.dumps({
        "label_names": LABELS, "weights": clf.coef_.tolist(), "bias": clf.intercept_.tolist(),
        "mean": scaler.mean_.tolist(), "scale": scaler.scale_.tolist(), "encoder": str(z["model"])}))
    test_rs, test_X, _ = part["external_test"]
    (out / f"{MODEL_ID}.embeddings.json").write_text(json.dumps(
        {r["image_id"]: [round(float(v), 6) for v in x] for r, x in zip(test_rs, test_X)}))


if __name__ == "__main__":
    main()
