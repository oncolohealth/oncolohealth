# Cancer Research Foundation

An executable local foundation for a researcher-focused cancer-model workspace. Its core has no third-party runtime dependencies, makes no network requests, and does not submit NPS workloads. Optional EXIF tag counting uses Pillow. Run it with Python from this directory.

## What works

| Path | Implemented behavior | Still requires integration |
|---|---|---|
| 1. Reasoning coordinator and specialist tools | Explicit model compatibility checks; installed-adapter execution interface; observed-result envelopes; reviewed tool-conversation export | Verified Gemma serving, real specialist adapters/weights, full schema validation, and coordinator fine-tuning |
| 2. Transfer learning | Supervised linear softmax classifier training over precomputed encoder features; held-out feature evaluation | Actual permitted encoder features, source data, medical labels, image-backbone fine-tuning, and task-specific external validation |
| 3. Distillation | Teacher-guided classifier training over aligned feature rows with real labels; teacher identity/label-order/permission checks | An evaluated permitted teacher, real teacher outputs, full image-model distillation, and independent medical validation |
| Shared dataset research | Provenance/readiness reports; declared patient/duplicate leakage checks; class distributions; optional local SHA-256 verification; evidence and permission blockers | Internet discovery connectors, pixel inspection, near-duplicate detection, label adjudication, and independent evidence review |

This is a software foundation, not a trained cancer model or a completed web platform. The supplied registry is catalog-only. It cannot produce cancer predictions without an explicitly installed specialist. Test fixtures and example vectors are synthetic and are not medical data. Any result marked `declared_checks_passed` describes manifest checks, not proof of label truth, consent, or clinical validity.

The proposed large-machine coordinator is [Gemma 4 31B IT](https://huggingface.co/google/gemma-4-31B-it). Its reasoning behavior should be retained and measured before and after adaptation. The complete system also includes independently sized specialists; the coordinator parameter count is not a claim about their diagnostic performance. This foundation does not serve Gemma.

## Try the offline workflow

These commands only inspect fixtures or prepare records:

```sh
python3 -m cancer_workbench route examples/mri-request.json examples/registry.json
python3 -m cancer_workbench audit examples/dataset-spec.json examples/manifest.csv
python3 -m cancer_workbench curriculum examples/reviewed-traces.json
python3 -m cancer_workbench plan distillation examples/model-template.json --budget examples/budget-template.json
python3 -m unittest discover -s tests -v
```

The request intentionally lacks a required MRI channel. The manifest intentionally has unresolved label/file evidence, and the job template has unresolved access/resource requirements. Expect explicit rejection reasons rather than invented eligibility or predictions.

To verify actual local file integrity, include relative `file_path` and `sha256` columns and pass `--files-root` pointing at their parent directory. Absolute paths and references escaping that directory are rejected. Digest checks establish file identity, not medical correctness. Without a file check, a manifest's integrity attestation is explicitly reported as unmeasured.

The following commands explicitly optimize tiny local CPU classifiers on the supplied synthetic vectors. They are examples of the implemented algorithms, not cancer-model training:

```sh
python3 -m cancer_workbench train-head examples/feature-training.json > supervised-head.json
python3 -m cancer_workbench train-head examples/feature-training.json --teacher-weight 0.5 > student-head.json
python3 -m cancer_workbench evaluate-head supervised-head.json examples/feature-evaluation.json
python3 -m cancer_workbench evaluate-head student-head.json examples/feature-evaluation.json
```

The learner is a small linear head with fixed input features. Teacher targets and real reference labels are combined at temperature one. This does not fine-tune Gemma, a medical encoder, or a segmentation network. Features from a real pretrained encoder can replace the fixtures after provenance, rights, grouping, and labels are reviewed. Teacher probabilities must refer to the same sample and exactly the same ordered classes. Compare teacher-guided learning against the supervised baseline, not only teacher agreement.

## Interfaces

### BTXRD release audit

`audit_btxrd_release(archive, expected_md5=None, train_list=None, validation_list=None, inspect_exif=False)` reads an already-local ZIP without extracting it. It checks archive digests and CRCs, the actual XLSX/CSV table, image/annotation joins, exact-byte duplicate labels, annotation subtype-label sets, and optional author-supplied split lists. It rejects ambiguous IDs, unsafe paths, spreadsheet formulas and malformed structures rather than silently dropping them. Its limits are 50,000 ZIP members, 2 GB total uncompressed content, and 20 MB per table/annotation/EXIF input. It does not download or train.

```sh
python3 -B -m cancer_workbench btxrd-audit BTXRD.zip --expected-md5 59132a5036d030580ccade8add8f13df --train-list train.xlsx --validation-list val.xlsx
```

These filenames are placeholders for already-local inputs. The checksum is the [original release's published reference](https://api.figshare.com/v2/articles/27865398); select the right reference for the release being audited. The command prints JSON and never includes the input's local path or an authoring timestamp. Add `--inspect-exif` only when optional Pillow is installed: it counts tag names and nonempty raw tags without exporting their values. A successful audit does not clear embedded metadata for sharing, establish patient identity, adjudicate labels, or approve an experiment. The real-release [audit report](../BTXRD-audit.json) and [readiness record](../BTXRD-readiness.md) are separate from the synthetic software tests.

### BTXRD metadata intake and split draft

`prepare_btxrd_cohort(metadata, case_map=None, *, fractions=None, seed=17)` normalizes the source diagnostic flags and drafts partitions only when a case map declares patient groups, grouping evidence references, and file digests. Patient and digest relations are joined transitively. The greedy partitioner balances classes approximately; it does not guarantee an optimal split. Missing groups or classes block export rather than causing an image-level fallback.

Use `python3 -m cancer_workbench btxrd-prepare metadata.csv --case-map case-map.csv` with already-authorized local CSV files. These are input placeholders, not files supplied with the project. The command never downloads images, verifies patient assertions, measures image/file integrity, clears rights, or starts training. Its status is a split draft requiring review, not a training-readiness attestation. See the [source review](../BTXRD-readiness.md).

### BTXRD evidence template

`prepare_btxrd_evidence_template(archive, expected_md5=None)` audits an already-local release and returns source image IDs/flags, measured image hashes, advisory discrepancy flags, and blank patient/lesion/reference fields. The `btxrd-evidence-template` command prints those rows as CSV. It does not infer groups, adjudicate labels, assign partitions, filter flagged rows, or export image pixels, demographics, EXIF values or local input paths.

```sh
python3 -B -m cancer_workbench btxrd-evidence-template BTXRD.zip --expected-md5 59132a5036d030580ccade8add8f13df > evidence-template.csv
python3 -B -m cancer_workbench btxrd-prepare evidence-template.csv --case-map evidence-template.csv
```

The [real-release template and field guide](../BTXRD-evidence-handoff.md) are available for custodian review. All 3,746 grouping/reference fields remain unresolved, so the actual template produces a blocked report with no split rows. The split helper now rejects recognized placeholder values such as `unknown` or `pending`, and patient IDs equal to an image filename or its stem. These checks cannot authenticate a supplied mapping. The lesion/reference/review columns are handoff records, not currently enforced eligibility rules.

`check_btxrd_evidence(archive, evidence_rows, expected_md5=None)` checks a returned template against a freshly audited local archive. The `btxrd-evidence-check` command detects missing/unknown/duplicate rows and changes to source fields, hashes or advisory flags; checks declared evidence completeness and reviewed status; and flags exact-copy patient conflicts and source-label conflicts within a declared lesion. It accepts equivalent encodings for flags, source-center numbers and hashes. It returns aggregate findings and known source image-ID examples, without supplied patient IDs, reference values or local paths. Complete declarations yield only `declared_evidence_requires_review`; all medical/training-readiness flags remain false. It does not create a cohort or implement an adjudication/exclusion workflow.

```sh
python3 -B -m cancer_workbench btxrd-evidence-check BTXRD.zip evidence-template.csv --expected-md5 59132a5036d030580ccade8add8f13df
```

The [actual check report](../BTXRD-evidence-check.json) verifies that all 3,746 template rows match the archived source fields and measured hashes, while retaining the evidence and contradictory-label blockers. The existing split helper still requires a separately reviewed cohort; it does not call this checker automatically.

- `route_models(request, registry)` returns compatible candidates and per-model rejection reasons. It never silently selects a model or ranks medical quality from a model name.
- `execute_specialist(model, request, adapters)` calls an explicitly installed adapter only when metadata, reproduced status, and reviewed inference permission pass. Adapters are trusted installed Python functions, not downloaded code or a sandbox.
- `audit_dataset(spec, rows, files_root=None)` returns findings and class counts. `truth_certified` and `clinical_accuracy_established` remain false. Patient IDs must be consistent pseudonymous grouping identifiers; unknown or inconsistent grouping cannot be repaired by an automated flag.
- `export_curriculum(records)` exports conversation messages, tool schemas, and source references. It checks observed/reviewed attestations, call/result pairing, and a subset of JSON Schema (type, enum, required properties, array items, and additional properties). It does not independently verify that an attestation is true or implement all JSON Schema constraints.
- `plan_experiment(path, model, audit, budget)` returns a draft or explicit blockers. No plan is submitted automatically. Resource limits need a measured profile; the software does not invent a runtime estimate.
- `train_feature_head` and `evaluate_head` provide the local CPU baselines. Evaluation rejects training sample or patient overlap, different encoder references, and mixed validation/test partitions. Metrics are per feature row; multiple images from one patient need an appropriate patient-level evaluation procedure beyond this baseline.

The registry records `permissions.inference`, `permissions.adaptation`, and `permissions.distillation` separately. These are reviewed assertions, not automatic legal determinations. An available checkpoint is not automatically an eligible teacher. Source restrictions, required citations, and provenance survive the workflow.

## Researcher requirements across all paths

Retain general reasoning and coding ability alongside oncology tool use. Track base-versus-adapted results on a fixed general reasoning suite, held-out tool workflows, dataset-audit cases, and complete imaging pipelines. Test unknown models and missing/incorrect inputs. Brief, inspectable decision rationales are sufficient; collecting hidden model reasoning is not a requirement.

Dataset review must report what has been checked, what evidence is missing, and who or what supplied the reference labels. It should assess provenance, label quality, representativeness, acquisition differences, overlap, intended use, reliability, and resource burden. A single unexplained quality score must not substitute for that evidence.

Cancer performance must be measured per supported task and population, comparing matched baselines and current reproducible specialists on independent real labels. The system must never advertise universal best-in-class performance from parameter count, a successful software test, or a completed training run.

## Verification and boundaries

The automated suite exercises all three paths, missing MRI sequences, incompatible endpoints, catalog-only access, patient and duplicate leakage, local digest mismatches, restricted teacher use, malformed tool traces, nonfinite inputs, teacher/sample alignment, and held-out evaluation. Learning tests optimize only tiny synthetic vectors on CPU. They establish software behavior, not cancer accuracy.

Not implemented in this foundation: a live Gemma assistant, internet retrieval, a user interface, model-serving image ingestion/de-identification, real cancer-model adapters, NPS job submission, actual weight/dataset acquisition, a complete security boundary, or full clinical/scientific validation. The separate local OncoCopilot build adds a web interface and draft integrations; they have not been reconciled into this foundation. No real medical model or NPS workload has been trained by creating this foundation.

## Technical references

- [TRL tool-calling SFT](https://huggingface.co/docs/trl/en/sft_trainer#tool-calling-with-sft)
- [PyTorch knowledge distillation](https://docs.pytorch.org/tutorials/beginner/knowledge_distillation_tutorial.html)
- [MedSigLIP classification from embeddings](https://developers.google.com/health-ai-developer-foundations/medsiglip)
- [MONAI Model Zoo](https://project-monai.github.io/model-zoo.html)

Source citations, model/data identifiers, and training lineage are necessary research records. No optional author, creator, machine path, or generated-at fields are added to exported JSON.

The offline archive/evidence utilities also have a [tested shared-code integration candidate](../BTXRD-shared-integration.md). It ports them into the inspected shared repository's dataset namespace and CLI, reuses that build's existing manifest/audit boundary, and remains unpushed/unmerged. Its combined verification is separate from this foundation's suite.
