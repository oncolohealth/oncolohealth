#!/usr/bin/env bash
# Download BTXRD (CC BY 4.0, ~840 MB) from its Figshare release, verify MD5, unzip,
# then build the source-held-out split.
set -euo pipefail
source "$(dirname "$0")/env.sh"
EXPECTED_MD5=59132a5036d030580ccade8add8f13df
ZIP="$DATA/BTXRD.zip"
if [ ! -f "$ZIP" ]; then
  URL=$(curl -s https://api.figshare.com/v2/articles/27865398 | python3 -c "import sys,json; f=[x for x in json.load(sys.stdin)['files'] if x['name'].lower().endswith('.zip')][0]; print(f['download_url'])")
  echo "downloading $URL"
  curl -L --fail -o "$ZIP.part" "$URL" && mv "$ZIP.part" "$ZIP"
fi
GOT=$(md5sum "$ZIP" | cut -d' ' -f1)
if [ "$GOT" != "$EXPECTED_MD5" ]; then echo "MD5 mismatch: $GOT (expected $EXPECTED_MD5)"; exit 1; fi
echo "md5 ok"
[ -d "$DATA/BTXRD" ] || (mkdir -p "$DATA/BTXRD" && python3 - "$ZIP" "$DATA/BTXRD" <<'PY'
import shutil
import sys
import zipfile
from pathlib import Path

destination = Path(sys.argv[2]).resolve()
with zipfile.ZipFile(sys.argv[1]) as archive:
    for item in archive.infolist():
        target = (destination / item.filename).resolve()
        if target != destination and destination not in target.parents:
            raise SystemExit("Archive contains a path outside the destination")
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
PY
)
python3 -m training.btxrd.prepare --root "$DATA/BTXRD" --out "$ONCO_RESULTS_DIR"
