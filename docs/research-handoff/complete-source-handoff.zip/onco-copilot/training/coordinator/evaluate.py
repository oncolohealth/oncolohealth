"""Measure coordinator tool use on held-out tasks, plus general-reasoning retention.

    python3 -m training.coordinator.evaluate --base-url http://localhost:8000/v1 --model google/gemma-4-31B-it --tag base
    python3 -m training.coordinator.evaluate --base-url http://localhost:8000/v1 --model onco-lora --tag lora --gsm8k 300

Tool-use metrics (thinking OFF unless --thinking): required-tool recall, extra-tool rate,
invalid-call rate, needs_input rate, completion rate, unsupported-number rate, latency.
Retention: GSM8K test accuracy (needs the `datasets` package and network).
Writes results/coordinator_eval_<tag>.json
"""

import argparse
import json
import re
import statistics
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from copilot import agent
from copilot.llm import OpenAIChat
from training.coordinator.make_sft_data import unsupported_numbers
from training.coordinator.tasks import build


def run_task(llm, item):
    events = []
    t0 = time.time()
    agent.run(llm, [{"role": "user", "content": item["prompt"]}], events.append)
    dt = time.time() - t0
    calls = [e for e in events if e["type"] == "tool_call"]
    results = [e for e in events if e["type"] == "tool_result"]
    final = next((e["text"] for e in reversed(events) if e["type"] == "message"), "")
    called = {c["name"] for c in calls}
    req = set(item["required_tools"])
    allowed = req | set(item["optional_tools"]) | {"search_literature"}
    evidence = item["prompt"] + json.dumps([r["result"] for r in results], default=str)
    return {"id": item["id"], "intent": item["intent"],
            "required_recall": len(req & called) / len(req) if req else 1.0,
            "extra_tools": len(called - allowed),
            "invalid_calls": sum(not isinstance(c["arguments"], dict) for c in calls),
            "needs_input": sum(isinstance(r["result"], dict) and r["result"].get("status") == "needs_input" for r in results),
            "n_calls": len(calls), "completed": bool(final.strip()),
            "unsupported_numbers": len(unsupported_numbers(final, evidence)), "latency_s": dt}


def gsm8k(base_url, model, n, workers):
    from datasets import load_dataset
    ds = load_dataset("openai/gsm8k", "main", split="test").select(range(n))

    def one(ex):
        body = {"model": model, "temperature": 0.0, "max_tokens": 1024, "chat_template_kwargs": {"enable_thinking": False},
                "messages": [{"role": "user", "content": ex["question"] + "\nGive the final answer after '####'."}]}
        req = urllib.request.Request(base_url.rstrip("/") + "/chat/completions", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=300) as r:
            text = json.loads(r.read())["choices"][0]["message"]["content"] or ""
        gold = ex["answer"].split("####")[-1].strip().replace(",", "")
        nums = re.findall(r"-?\d[\d,]*\.?\d*", text.split("####")[-1])
        return bool(nums) and nums[-1].replace(",", "").rstrip(".") == gold

    with ThreadPoolExecutor(workers) as ex:
        ok = list(ex.map(one, ds))
    return sum(ok) / len(ok)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--thinking", action="store_true")
    ap.add_argument("--gsm8k", type=int, default=0)
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    _, held = build()
    llm = OpenAIChat(a.base_url, a.model, thinking=a.thinking)
    with ThreadPoolExecutor(a.workers) as ex:
        rows = list(ex.map(lambda it: run_task(llm, it), held))
    mean = lambda k: statistics.mean(r[k] for r in rows)
    summary = {"tag": a.tag, "model": a.model, "thinking": a.thinking, "n_tasks": len(rows),
               "required_tool_recall": mean("required_recall"),
               "full_tool_coverage_rate": statistics.mean(r["required_recall"] == 1.0 for r in rows),
               "extra_tools_per_task": mean("extra_tools"), "invalid_calls_per_task": mean("invalid_calls"),
               "needs_input_per_task": mean("needs_input"), "completion_rate": mean("completed"),
               "unsupported_numbers_per_task": mean("unsupported_numbers"),
               "median_latency_s": statistics.median(r["latency_s"] for r in rows),
               "by_intent": {}}
    for intent in sorted({r["intent"] for r in rows}):
        rs = [r for r in rows if r["intent"] == intent]
        summary["by_intent"][intent] = {"n": len(rs), "required_tool_recall": statistics.mean(r["required_recall"] for r in rs)}
    if a.gsm8k:
        summary["gsm8k_accuracy"] = gsm8k(a.base_url, a.model, a.gsm8k, a.workers)
        summary["gsm8k_n"] = a.gsm8k
    out = Path(a.results)
    out.mkdir(parents=True, exist_ok=True)
    (out / f"coordinator_eval_{a.tag}.json").write_text(json.dumps({"summary": summary, "rows": rows}, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
