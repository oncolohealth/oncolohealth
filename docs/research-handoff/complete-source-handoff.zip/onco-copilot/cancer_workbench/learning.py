"""Small CPU feature-head and distillation baselines; no model downloading.

These optimize a linear softmax head on precomputed features. They do not
fine-tune Gemma or an image encoder, or establish medical performance.
"""

import math
import hashlib


def _identifier_hash(identifier):
    return hashlib.sha256(str(identifier).encode()).hexdigest()


def _softmax(logits):
    largest = max(logits)
    values = [math.exp(x - largest) for x in logits]
    total = sum(values)
    return [x / total for x in values]


def predict(model, features):
    if len(features) != model["feature_dimension"]:
        raise ValueError("Feature dimensions do not match")
    if any(not math.isfinite(x) for x in features):
        raise ValueError("Features must be finite")
    return _softmax([b + sum(w * x for w, x in zip(weights, features))
                     for weights, b in zip(model["weights"], model["bias"])])


def train_feature_head(data, *, epochs=100, learning_rate=0.05, teacher_weight=0.0):
    """Train a supervised or teacher-target head; only called explicitly.

    Teacher targets must use the same ordered label ontology. Validation and
    test rows are forbidden; evaluation is a separate independent operation.
    """
    labels, rows = data.get("label_names", []), data.get("rows", [])
    if len(labels) < 2 or len(set(labels)) != len(labels) or not rows:
        raise ValueError("Need unique class names and nonempty training rows")
    if not data.get("encoder_reference") or not data.get("dataset_reference"):
        raise ValueError("Encoder and dataset provenance are required")
    if data.get("permissions", {}).get("training") != "allowed":
        raise ValueError("Reviewed training permission is required")
    if not isinstance(epochs, int) or isinstance(epochs, bool) or epochs < 1:
        raise ValueError("epochs must be a positive integer")
    if not math.isfinite(learning_rate) or learning_rate <= 0:
        raise ValueError("learning_rate must be positive and finite")
    if not math.isfinite(teacher_weight) or not 0 <= teacher_weight <= 1:
        raise ValueError("teacher_weight must be in [0, 1]")
    dimension = len(rows[0].get("features", []))
    if dimension < 1:
        raise ValueError("Need nonempty features")
    if teacher_weight and (data.get("teacher_label_names") != labels or not data.get("teacher_reference")):
        raise ValueError("Teacher provenance and identical ordered labels are required")
    if teacher_weight and data.get("permissions", {}).get("distillation") != "allowed":
        raise ValueError("Reviewed distillation permission is required")
    seen_samples = set()
    for row in rows:
        if row.get("split") != "train":
            raise ValueError("Only training rows can enter optimization")
        if not row.get("sample_id") or not row.get("patient_id") or row["sample_id"] in seen_samples:
            raise ValueError("Unique sample IDs and patient groups are required")
        seen_samples.add(row["sample_id"])
        features = row.get("features", [])
        if len(features) != dimension or any(not math.isfinite(x) for x in features):
            raise ValueError("Inconsistent or nonfinite features")
        if row.get("label") not in labels:
            raise ValueError("Every training row needs a real reference label")
        if teacher_weight:
            if row.get("teacher_sample_id") != row["sample_id"]:
                raise ValueError("Teacher target must refer to this sample")
            probabilities = row.get("teacher_probabilities", [])
            if (len(probabilities) != len(labels) or any(not math.isfinite(x) or x < 0 or x > 1 for x in probabilities)
                    or abs(sum(probabilities) - 1) > 1e-6):
                raise ValueError("Teacher targets must be normalized finite probabilities")
    model = {"type": "linear_softmax_feature_head", "label_names": labels[:],
             "feature_dimension": dimension, "weights": [[0.0] * dimension for _ in labels],
             "bias": [0.0] * len(labels), "encoder_reference": data["encoder_reference"],
             "dataset_reference": data["dataset_reference"], "teacher_reference": data.get("teacher_reference") if teacher_weight else None,
             "method": "distillation" if teacher_weight else "supervised_feature_transfer",
             "training_sample_hashes": sorted(_identifier_hash(r["sample_id"]) for r in rows),
             "training_group_hashes": sorted({_identifier_hash(r["patient_id"]) for r in rows}),
             "clinical_accuracy_established": False}
    for _ in range(epochs):
        for row in rows:
            probabilities = predict(model, row["features"])
            label_index = labels.index(row["label"])
            for c in range(len(labels)):
                target = float(c == label_index)
                if teacher_weight:
                    target = (1 - teacher_weight) * target + teacher_weight * row["teacher_probabilities"][c]
                gradient = probabilities[c] - target
                for j, x in enumerate(row["features"]):
                    model["weights"][c][j] -= learning_rate * gradient * x
                model["bias"][c] -= learning_rate * gradient
    return model


def evaluate_head(model, data):
    """Evaluate held-out feature rows, reporting per-class recall and log loss."""
    if data.get("label_names") != model["label_names"]:
        raise ValueError("Evaluation label order differs")
    if data.get("encoder_reference") != model["encoder_reference"]:
        raise ValueError("Evaluation encoder differs")
    rows, labels = data.get("rows", []), model["label_names"]
    if not rows or any(r.get("split") not in ("validation", "test") for r in rows):
        raise ValueError("Evaluation needs held-out rows")
    if len({r["split"] for r in rows}) != 1:
        raise ValueError("Evaluate validation and test partitions separately")
    seen_samples = set()
    for row in rows:
        if not row.get("sample_id") or not row.get("patient_id") or row["sample_id"] in seen_samples:
            raise ValueError("Unique sample IDs and patient groups are required")
        seen_samples.add(row["sample_id"])
        if (_identifier_hash(row["sample_id"]) in model["training_sample_hashes"]
                or _identifier_hash(row["patient_id"]) in model["training_group_hashes"]):
            raise ValueError("Evaluation overlaps training samples or patients")
    matrix = [[0] * len(labels) for _ in labels]
    loss = 0.0
    for row in rows:
        if row.get("label") not in labels:
            raise ValueError("Unknown evaluation label")
        actual = labels.index(row["label"])
        probabilities = predict(model, row["features"])
        selected = max(range(len(labels)), key=lambda i: probabilities[i])
        matrix[actual][selected] += 1
        loss -= math.log(max(probabilities[actual], 1e-15))
    recalls = {label: matrix[i][i] / sum(matrix[i]) if sum(matrix[i]) else None for i, label in enumerate(labels)}
    return {"label_names": labels, "confusion_matrix": matrix, "per_class_recall": recalls,
            "log_loss": loss / len(rows), "sample_count": len(rows),
            "partition": rows[0]["split"], "patient_count": len({r["patient_id"] for r in rows}),
            "scope": "Feature-row evaluation; patient independence must be audited separately",
            "clinical_accuracy_established": False}
