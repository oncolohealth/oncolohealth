#!/usr/bin/env bash
# Serve Gemma 4 with tool calling. Requires the official vLLM Gemma 4 chat template.
#   GEMMA_CHAT_TEMPLATE=/path/to/tool_chat_template_gemma4.jinja bash nps/serve_gemma.sh
#   MODEL=$WORK/models/onco-gemma-4-31b-it NAME=onco-lora GEMMA_CHAT_TEMPLATE=... bash nps/serve_gemma.sh
#   TP=4 GEMMA_CHAT_TEMPLATE=... bash nps/serve_gemma.sh
set -euo pipefail
source "$(dirname "$0")/env.sh"
MODEL="${MODEL:-$HF_HOME/gemma-4-31B-it}"
NAME="${NAME:-$GEMMA_MODEL}"
TP="${TP:-1}"
PORT="${PORT:-8000}"
if [ ! -d "$MODEL" ]; then echo "Gemma weights missing at $MODEL; acquire them explicitly before serving" >&2; exit 1; fi
if [ ! -f "${GEMMA_CHAT_TEMPLATE:-}" ]; then echo "Set GEMMA_CHAT_TEMPLATE to vLLM's official tool_chat_template_gemma4.jinja" >&2; exit 1; fi
exec vllm serve "$MODEL" \
  --served-model-name "$NAME" \
  --tensor-parallel-size "$TP" \
  --max-model-len "${MAX_LEN:-16384}" \
  --kv-cache-dtype fp8 \
  --reasoning-parser gemma4 \
  --enable-auto-tool-choice --tool-call-parser gemma4 \
  --chat-template "$GEMMA_CHAT_TEMPLATE" \
  --host 0.0.0.0 --port "$PORT"
