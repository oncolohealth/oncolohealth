"""Frozen-encoder feature extraction. Owner: Workstream E. Needs the `ml` extra (see package docstring)."""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

from .feature_identity import SCHEMA, binding_digest, measure_inputs, validate_cached_inputs


def extract_features(encoder_id: str, manifest_rows: list[dict], data_root: Path, out_path: Path,
                     *, batch_size: int = 16, device: str | None = None, quiet: bool = False, variant: str = "pad") -> Path:
    """Embed every manifest row's `file` (relative to `data_root`) and write an .npz.

    The file holds sample_ids, patient_ids, partitions, labels, features (N x D), plus
    encoder identity and measured input hashes. Consumers must use load_bound_features.
    """
    import numpy as np

    from ..adapters.encoder import FrozenEncoderAdapter, preprocessing_hash, revision

    inputs = measure_inputs(manifest_rows, data_root)
    adapter = FrozenEncoderAdapter(encoder_id, device=device, variant=variant)
    t0 = time.monotonic()

    def progress(done, total):
        if not quiet:
            rate = done / max(time.monotonic() - t0, 1e-9)
            print(f"\r  {encoder_id}: {done}/{total} images ({rate:.1f}/s)", end="", file=sys.stderr)

    feats = adapter.embed([Path(data_root) / r["file"] for r in manifest_rows], batch_size=batch_size, progress=progress)
    if inputs != measure_inputs(manifest_rows, data_root):
        raise ValueError("Source images changed during feature extraction")
    if (feats.ndim != 2 or feats.shape[0] != len(inputs) or feats.shape[1] < 1
            or not np.issubdtype(feats.dtype, np.number) or not np.isfinite(feats).all()):
        raise ValueError("Encoder returned invalid feature rows")
    if not quiet:
        print(file=sys.stderr)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    col = lambda k: np.array([r.get(k, "") for r in manifest_rows])
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=out_path.parent, suffix=".npz", delete=False) as stream:
            temporary = Path(stream.name)
            np.savez(stream, sample_ids=col("sample_id"), patient_ids=col("patient_id"), partitions=col("partition"),
                     labels=col("label"), features=feats, encoder_id=encoder_id, revision=str(revision(encoder_id)),
                     preprocessing_hash=preprocessing_hash(encoder_id, variant), variant=variant, device=str(adapter.device),
                     seconds=round(time.monotonic() - t0, 1), input_binding_schema=SCHEMA,
                     image_sha256=np.array([r["sha256"] for r in inputs]), input_content_sha256=binding_digest(inputs))
        os.replace(temporary, out_path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return out_path


def cache_path(encoder_id: str, dataset_id: str, root: Path, variant: str = "pad") -> Path:
    """Cache locator only; load_bound_features must verify image-byte bindings."""
    from ..adapters.encoder import preprocessing_hash, revision

    return Path(root) / f"{dataset_id}-{encoder_id}-{str(revision(encoder_id))[:8]}-{preprocessing_hash(encoder_id, variant)}.npz"


def load_features(path: Path) -> dict:
    import numpy as np

    with np.load(path, allow_pickle=False) as z:
        return {k: (z[k].item() if z[k].ndim == 0 else z[k]) for k in z.files}


def load_bound_features(path: Path, manifest_rows: list[dict], data_root: Path,
                        encoder_id: str, variant: str = "pad") -> dict:
    """Return NPZ features only after checking declared encoder identity and image bytes.

    Model revisions and preprocessing hashes remain assertions, not actual
    weight or implementation authentication. Legacy unbound caches fail closed.
    """
    from ..adapters.encoder import preprocessing_hash, revision

    cache = load_features(path)
    current_revision = revision(encoder_id)
    if not current_revision:
        raise ValueError("Encoder revision is unavailable for cache identity checking")
    expected = {"encoder_id": encoder_id, "revision": str(current_revision),
                "preprocessing_hash": preprocessing_hash(encoder_id, variant), "variant": variant}
    if any(not isinstance(cache.get(k), str) or cache[k] != value for k, value in expected.items()):
        raise ValueError("Feature cache encoder or preprocessing identity differs")
    validate_cached_inputs(cache, manifest_rows, data_root)
    return cache
