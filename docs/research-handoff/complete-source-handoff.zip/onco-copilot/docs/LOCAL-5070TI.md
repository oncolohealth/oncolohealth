# Gemma on an RTX 5070 Ti

NVIDIA lists the desktop RTX 5070 Ti with **16 GB GDDR7**. Google's Gemma 4 table estimates model-loading memory before context and serving overhead:

| Gemma 4 variant | Google's approximate memory | 5070 Ti conclusion |
|---|---:|---|
| 31B BF16 | 69.9 GB | Requires a larger GPU or multiple GPUs |
| 31B Q4_0 | 17.5 GB | Does not fit fully in 16 GB, even before context |
| 12B Q4_0 | 6.7 GB | Plausible local profile; validate actual context and tool calling |
| E4B Q4_0 | 4.5 GB | More memory margin; useful for local workflow development |

The **31B model is the proposed NPS coordinator**. A 5070 Ti can run the OncoCopilot app and a smaller quantized Gemma model served by a compatible local endpoint. It cannot host 31B entirely in VRAM; CPU offload may be possible in some runtimes but is not a tested or recommended training profile. Fine-tuning 31B needs substantially more memory than inference.

To use a local model, obtain a Google-published Gemma 4 QAT Q4_0 variant after reviewing its model card, serve it with software that supports its chat and tool-call format, then set `ONCO_LLM_BASE_URL` to that server's OpenAI-compatible `/v1` endpoint and `ONCO_LLM_MODEL` to the name exposed by that server. The app's offline mock works without any model. No weights were downloaded or local GPU run performed while preparing this guide. Before relying on a local server for research, verify one tool call and one tool result end to end, and measure VRAM and latency on the actual 5070 Ti.

Sources: [NVIDIA RTX 5070 Ti specifications](https://www.nvidia.com/en-us/geforce/graphics-cards/50-series/rtx-5070-family/), [Google Gemma 4 memory table](https://ai.google.dev/gemma/docs/core), [Google Gemma 4 QAT model collection](https://huggingface.co/collections/google/gemma-4-qat-q4-0), [vLLM Gemma 4 tool-calling guide](https://docs.vllm.ai/projects/recipes/en/stable/Google/Gemma4.html).
