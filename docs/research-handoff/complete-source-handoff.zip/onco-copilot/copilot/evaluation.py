"""Metrics and paired model comparison. Standard library only.

Prediction file format (written by every training script and accepted from users):
{
  "model_id": "...", "dataset_id": "btxrd", "partition": "external_test",
  "label_names": ["normal", "benign", "malignant"],
  "rows": [{"sample_id": "IMG000001", "label": "benign",
            "probabilities": [0.1, 0.8, 0.1]}, ...]
}
"""

import math
import random

POSITIVE_DEFAULT = "malignant"


def _check(pred):
    labels = pred.get("label_names") or []
    rows = pred.get("rows") or []
    if len(labels) < 2 or not rows:
        raise ValueError("Predictions need label_names and rows")
    seen = set()
    for r in rows:
        sid = r.get("sample_id")
        if not sid or sid in seen:
            raise ValueError("Unique sample_id required")
        seen.add(sid)
        if r.get("label") not in labels:
            raise ValueError("Unknown label for " + str(sid))
        p = r.get("probabilities")
        if not isinstance(p, list) or len(p) != len(labels) or any(not math.isfinite(x) for x in p):
            raise ValueError("Bad probabilities for " + str(sid))
        if abs(sum(p) - 1) > 1e-3:
            raise ValueError("Probabilities must sum to 1 for " + str(sid))
    return labels, rows


def _auc(scores, positives):
    """Mann-Whitney ROC-AUC with tie handling."""
    pairs = sorted(zip(scores, positives))
    n_pos = sum(positives)
    n_neg = len(positives) - n_pos
    if n_pos == 0 or n_neg == 0:
        return None
    rank_sum, i = 0.0, 0
    while i < len(pairs):
        j = i
        while j + 1 < len(pairs) and pairs[j + 1][0] == pairs[i][0]:
            j += 1
        avg_rank = (i + j) / 2 + 1
        rank_sum += avg_rank * sum(1 for k in range(i, j + 1) if pairs[k][1])
        i = j + 1
    return (rank_sum - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)


def _core(labels, rows):
    k = len(labels)
    cm = [[0] * k for _ in labels]
    for r in rows:
        a = labels.index(r["label"])
        p = r["probabilities"]
        cm[a][max(range(k), key=lambda i: p[i])] += 1
    n = len(rows)
    recall = [cm[i][i] / sum(cm[i]) if sum(cm[i]) else None for i in range(k)]
    col = [sum(cm[i][j] for i in range(k)) for j in range(k)]
    precision = [cm[j][j] / col[j] if col[j] else None for j in range(k)]
    f1 = [2 * p * r / (p + r) if p and r else 0.0 for p, r in zip(precision, recall)]
    valid_recalls = [x for x in recall if x is not None]
    auc = {}
    for i, lab in enumerate(labels):
        auc[lab] = _auc([r["probabilities"][i] for r in rows], [r["label"] == lab for r in rows])
    # expected calibration error (top-label, 10 bins)
    bins = [[0, 0.0, 0.0] for _ in range(10)]
    for r in rows:
        p = r["probabilities"]
        top = max(range(k), key=lambda i: p[i])
        b = min(int(p[top] * 10), 9)
        bins[b][0] += 1
        bins[b][1] += p[top]
        bins[b][2] += float(labels[top] == r["label"])
    ece = sum(abs(c / cnt - a / cnt) * cnt / n for cnt, c, a in bins if cnt)
    return {
        "n": n, "confusion_matrix": cm,
        "accuracy": sum(cm[i][i] for i in range(k)) / n,
        "balanced_accuracy": sum(valid_recalls) / len(valid_recalls),
        "macro_f1": sum(f1) / k,
        "per_class": {lab: {"recall": recall[i], "precision": precision[i], "f1": f1[i], "auc_ovr": auc[lab],
                            "support": sum(cm[i])} for i, lab in enumerate(labels)},
        "ece": ece,
    }


def _bootstrap(labels, rows, fn, iters, seed):
    rng = random.Random(seed)
    vals = []
    for _ in range(iters):
        sample = [rows[rng.randrange(len(rows))] for _ in rows]
        try:
            v = fn(labels, sample)
        except (ZeroDivisionError, ValueError):
            continue
        if v is not None:
            vals.append(v)
    vals.sort()
    if len(vals) < 20:
        return None
    return [vals[int(0.025 * len(vals))], vals[int(0.975 * len(vals)) - 1]]


def _bal_acc(labels, rows):
    return _core(labels, rows)["balanced_accuracy"]


def _pos_auc(positive):
    def fn(labels, rows):
        return _core(labels, rows)["per_class"][positive]["auc_ovr"]
    return fn


def evaluate(pred, *, positive=POSITIVE_DEFAULT, bootstrap=1000, seed=0):
    labels, rows = _check(pred)
    out = _core(labels, rows)
    out["model_id"] = pred.get("model_id")
    out["dataset_id"] = pred.get("dataset_id")
    out["partition"] = pred.get("partition")
    out["label_names"] = labels
    out["ci95"] = {"balanced_accuracy": _bootstrap(labels, rows, _bal_acc, bootstrap, seed)}
    if positive in labels:
        out["ci95"][positive + "_auc"] = _bootstrap(labels, rows, _pos_auc(positive), bootstrap, seed)
        # sensitivity at 90% specificity for the positive class
        i = labels.index(positive)
        neg = sorted((r["probabilities"][i] for r in rows if r["label"] != positive), reverse=True)
        pos = [r["probabilities"][i] for r in rows if r["label"] == positive]
        if neg and pos:
            thr = neg[max(int(0.10 * len(neg)) - 1, 0)]
            out["per_class"][positive]["sensitivity_at_90_specificity"] = sum(p > thr for p in pos) / len(pos)
    out["scope"] = "Research evaluation on the stated partition; not clinical validation"
    return out


def compare(pred_a, pred_b, *, positive=POSITIVE_DEFAULT, bootstrap=1000, seed=0):
    """Paired comparison on identical samples. Refuses mismatched test sets."""
    la, ra = _check(pred_a)
    lb, rb = _check(pred_b)
    if la != lb:
        raise ValueError("Label order differs between models")
    da = {r["sample_id"]: r for r in ra}
    db = {r["sample_id"]: r for r in rb}
    if set(da) != set(db):
        only_a, only_b = len(set(da) - set(db)), len(set(db) - set(da))
        raise ValueError(f"Models were evaluated on different samples ({only_a} only in A, {only_b} only in B)")
    for sid in da:
        if da[sid]["label"] != db[sid]["label"]:
            raise ValueError("Reference labels disagree for " + sid)
    ids = sorted(da)
    ea = evaluate(pred_a, positive=positive, bootstrap=bootstrap, seed=seed)
    eb = evaluate(pred_b, positive=positive, bootstrap=bootstrap, seed=seed)

    def correct(r):
        p = r["probabilities"]
        return la[max(range(len(la)), key=lambda i: p[i])] == r["label"]

    b = sum(1 for s in ids if correct(da[s]) and not correct(db[s]))
    c = sum(1 for s in ids if not correct(da[s]) and correct(db[s]))
    n = b + c
    if n:
        tail = sum(math.comb(n, k) for k in range(0, min(b, c) + 1)) / 2 ** n
        mcnemar_p = min(1.0, 2 * tail)
    else:
        mcnemar_p = 1.0
    rng = random.Random(seed)
    diffs = []
    for _ in range(bootstrap):
        pick = [ids[rng.randrange(len(ids))] for _ in ids]
        try:
            diffs.append(_bal_acc(la, [da[s] for s in pick]) - _bal_acc(la, [db[s] for s in pick]))
        except ZeroDivisionError:
            pass
    diffs.sort()
    ci = [diffs[int(0.025 * len(diffs))], diffs[int(0.975 * len(diffs)) - 1]] if len(diffs) >= 20 else None
    delta = ea["balanced_accuracy"] - eb["balanced_accuracy"]
    if ci and ci[0] > 0:
        verdict = "A better (95% CI excludes 0)"
    elif ci and ci[1] < 0:
        verdict = "B better (95% CI excludes 0)"
    else:
        verdict = "No significant difference in balanced accuracy"
    return {"a": ea, "b": eb, "n_paired": len(ids),
            "balanced_accuracy_delta": delta, "delta_ci95": ci,
            "mcnemar": {"a_only_correct": b, "b_only_correct": c, "p_value": mcnemar_p},
            "verdict": verdict,
            "scope": "Paired comparison on identical samples; research evidence only"}
