#!/usr/bin/env bash
# Frozen MedSigLIP embeddings + logistic head; planned one-GPU exploratory job.
set -euo pipefail
source "$(dirname "$0")/../env.sh"
[ -f "$WORK/venv/bin/activate" ] && source "$WORK/venv/bin/activate"
[ -f "$ONCO_RESULTS_DIR/btxrd_manifest.csv" ] || { echo "BTXRD manifest missing; acquire and prepare data explicitly first" >&2; exit 1; }
python3 -m training.btxrd.guard "$ONCO_RESULTS_DIR/btxrd_split.json"
MODEL_PATH="$HF_HOME/medsiglip-448"; [ -d "$MODEL_PATH" ] || MODEL_PATH="$MEDSIGLIP"
python3 -m training.btxrd.embed_medsiglip --root "$DATA/BTXRD" --results "$ONCO_RESULTS_DIR" \
  --model "$MODEL_PATH" --out "$WORK/cache/medsiglip_btxrd.npz"
python3 -m training.btxrd.train_head --emb "$WORK/cache/medsiglip_btxrd.npz" --results "$ONCO_RESULTS_DIR"
