"""Draft LoRA SFT of Gemma 4 31B on accepted tool-use trajectories (non-thinking mode).

Single node (one GB300 tray, 4 GPUs):
    torchrun --nproc_per_node 4 -m training.coordinator.train_lora \
        --data $WORK/sft/train.jsonl --model $HF_HOME/gemma-4-31B-it --out $WORK/ckpt/onco-lora

Multi-node via Run:ai distributed PyTorch: same command; torchrun reads the injected
MASTER_ADDR / WORLD_SIZE / RANK. Each GPU must hold a BF16 copy (about 70 GB for
weights alone) plus LoRA, activations and optimizer state. Verify target VRAM.

Loss is applied only to assistant turns using prefix-stable chat-template rendering,
never to system/user/tool turns. The Gemma tokenizer and weights still need a smoke test.
Requires: torch, transformers>=5.8, peft, accelerate.
"""

import argparse
import json
import os

import torch
from peft import LoraConfig, get_peft_model
from transformers import AutoTokenizer, Trainer, TrainingArguments
from .masking import render_assistant_spans


def load_model(path):
    from transformers import AutoModelForMultimodalLM
    return AutoModelForMultimodalLM.from_pretrained(
        path, dtype=torch.bfloat16, attn_implementation="sdpa")


def encode(tok, ex, max_len):
    msgs = []
    for m in ex["messages"]:
        m = dict(m)
        for c in m.get("tool_calls") or []:
            args = c["function"].get("arguments")
            if isinstance(args, str):
                try:
                    c["function"]["arguments"] = json.loads(args)
                except ValueError:
                    pass
        msgs.append(m)
    text, spans = render_assistant_spans(tok, msgs, ex.get("tools"))
    enc = tok(text, return_offsets_mapping=True, add_special_tokens=False, truncation=True, max_length=max_len)
    labels = []
    for tid, (s, e) in zip(enc["input_ids"], enc["offset_mapping"]):
        inside = e > s and any(s >= a and e <= b for a, b in spans)
        labels.append(tid if inside else -100)
    if not any(label != -100 for label in labels):
        raise ValueError("No supervised assistant tokens remain after rendering/truncation")
    return {"input_ids": enc["input_ids"], "labels": labels}


class Collate:
    def __init__(self, pad):
        self.pad = pad

    def __call__(self, batch):
        n = max(len(b["input_ids"]) for b in batch)
        ids = torch.full((len(batch), n), self.pad, dtype=torch.long)
        lab = torch.full((len(batch), n), -100, dtype=torch.long)
        att = torch.zeros((len(batch), n), dtype=torch.long)
        for i, b in enumerate(batch):
            L = len(b["input_ids"])
            ids[i, :L] = torch.tensor(b["input_ids"])
            lab[i, :L] = torch.tensor(b["labels"])
            att[i, :L] = 1
        return {"input_ids": ids, "labels": lab, "attention_mask": att}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=float, default=2)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--max-len", type=int, default=16384)
    ap.add_argument("--grad-accum", type=int, default=4)
    a = ap.parse_args()

    tok = AutoTokenizer.from_pretrained(a.model)
    rows = [json.loads(l) for l in open(a.data)]
    data = [encode(tok, r, a.max_len) for r in rows]
    data = [d for d in data if any(x != -100 for x in d["labels"])]
    if int(os.environ.get("RANK", "0")) == 0:
        n_tok = sum(len(d["input_ids"]) for d in data)
        n_train = sum(sum(x != -100 for x in d["labels"]) for d in data)
        print(f"{len(data)} conversations, {n_tok} tokens, {n_train} supervised assistant tokens", flush=True)

    model = load_model(a.model)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.enable_input_require_grads()
    cfg = LoraConfig(r=a.rank, lora_alpha=2 * a.rank, lora_dropout=0.05, target_modules="all-linear",
                     exclude_modules=r".*(visual|vision|mm_projector|merger).*", task_type="CAUSAL_LM")
    model = get_peft_model(model, cfg)
    if int(os.environ.get("RANK", "0")) == 0:
        model.print_trainable_parameters()

    args = TrainingArguments(output_dir=a.out, num_train_epochs=a.epochs, learning_rate=a.lr, lr_scheduler_type="cosine",
                             warmup_ratio=0.05, per_device_train_batch_size=1, gradient_accumulation_steps=a.grad_accum,
                             bf16=True, logging_steps=5, save_strategy="epoch", save_total_limit=2, report_to=[],
                             ddp_find_unused_parameters=False, remove_unused_columns=False, dataloader_num_workers=2)
    Trainer(model=model, args=args, train_dataset=data, data_collator=Collate(tok.pad_token_id or 0)).train()
    if int(os.environ.get("RANK", "0")) == 0:
        model.save_pretrained(a.out + "/adapter")
        tok.save_pretrained(a.out + "/adapter")
        print("saved adapter to", a.out + "/adapter")


if __name__ == "__main__":
    main()
