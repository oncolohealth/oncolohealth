"""Read BTXRD tabular metadata from its published XLSX or a CSV export."""

import csv
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile

NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
CELL_REF = re.compile(r"([A-Z]+)[0-9]+$")


def _column_index(ref):
    match = CELL_REF.fullmatch(ref or "")
    if not match:
        raise ValueError(f"Invalid XLSX cell reference: {ref!r}")
    index = 0
    for char in match.group(1):
        index = index * 26 + ord(char) - ord("A") + 1
    return index - 1


def _cell_text(cell, shared):
    kind = cell.get("t")
    if kind == "inlineStr":
        return "".join(t.text or "" for t in cell.findall(".//x:t", NS))
    value = cell.find("x:v", NS)
    raw = value.text if value is not None and value.text is not None else ""
    if kind == "s":
        return shared[int(raw)]
    return raw


def read_xlsx(path):
    """Read the first BTXRD worksheet using standard-library XLSX XML support."""
    with ZipFile(path) as archive:
        sheet_names = sorted(name for name in archive.namelist()
                             if re.fullmatch(r"xl/worksheets/sheet[0-9]+\.xml", name))
        if not sheet_names:
            raise ValueError("XLSX contains no worksheet XML")
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(t.text or "" for t in item.findall(".//x:t", NS))
                      for item in root.findall("x:si", NS)]
        sheet = ET.fromstring(archive.read(sheet_names[0]))
        grid = []
        for row in sheet.findall(".//x:sheetData/x:row", NS):
            values = {}
            for cell in row.findall("x:c", NS):
                values[_column_index(cell.get("r"))] = _cell_text(cell, shared)
            if values:
                grid.append(values)
    if not grid:
        raise ValueError("XLSX first worksheet is empty")
    width = max(grid[0]) + 1
    fields = [grid[0].get(i, "").strip() for i in range(width)]
    if not all(fields) or len(set(fields)) != len(fields):
        raise ValueError("XLSX has empty or duplicate header names")
    rows = [{field: row.get(i, "") for i, field in enumerate(fields)}
            for row in grid[1:] if any(str(v).strip() for v in row.values())]
    return fields, rows


def read_metadata(root):
    root = Path(root)
    xlsx = sorted(root.rglob("dataset.xlsx"))
    if xlsx:
        if len(xlsx) != 1:
            raise ValueError(f"Multiple dataset.xlsx files found under {root}; select one release folder")
        fields, rows = read_xlsx(xlsx[0])
        return fields, rows, xlsx[0]
    csv_files = sorted(root.rglob("dataset.csv"))
    if csv_files:
        if len(csv_files) != 1:
            raise ValueError(f"Multiple dataset.csv files found under {root}; select one release folder")
        with csv_files[0].open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            return reader.fieldnames or [], list(reader), csv_files[0]
    raise ValueError("BTXRD metadata missing: expected dataset.xlsx or dataset.csv")
