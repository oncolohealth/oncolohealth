import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from cancer_workbench.cohorts import prepare_btxrd_cohort


def fixture():
    metadata, mapping = [], []
    for label in ("normal", "benign", "malignant"):
        for patient in range(6):
            for view in range(2):
                name = f"SYNTHETIC_{label}_{patient}_{view}.jpeg"
                metadata.append({"image_id": name, "center": str(patient % 3 + 1),
                                 "tumor": int(label != "normal"),
                                 "benign": int(label == "benign"), "malignant": int(label == "malignant")})
                mapping.append({"image_id": name, "patient_id": f"synthetic-{label}-{patient}",
                                "grouping_reference": "synthetic-test-evidence",
                                "sha256": hashlib.sha256(name.encode()).hexdigest()})
    return metadata, mapping


class CohortTests(unittest.TestCase):
    def test_source_metadata_never_invents_patient_ids(self):
        report = prepare_btxrd_cohort(fixture()[0])
        self.assertEqual(report["status"], "blocked")
        self.assertEqual(report["rows"], [])
        self.assertIn("patient_group_missing_or_image_id", {f["code"] for f in report["findings"]})
        self.assertEqual(report["class_counts"], {"normal": 12, "benign": 12, "malignant": 12})

    def test_patient_and_digest_never_cross_partitions(self):
        metadata, mapping = fixture()
        # A digest joins two patients, and their other views must follow too.
        mapping[2]["sha256"] = mapping[0]["sha256"]
        report = prepare_btxrd_cohort(metadata, mapping)
        self.assertEqual(report["status"], "split_draft_requires_review")
        self.assertEqual(report["linked_group_count"], 17)
        for field in ("patient_id", "sha256"):
            keys = {r[field] for r in report["rows"]}
            for key in keys:
                self.assertEqual(len({r["split"] for r in report["rows"] if r[field] == key}), 1)
        for counts in report["counts_by_partition"].values():
            self.assertEqual(set(counts), {"normal", "benign", "malignant"})
        self.assertFalse(report["submitted"])
        self.assertFalse(report["patient_independence_verified"])
        self.assertFalse(report["clinical_accuracy_established"])

    def test_reordering_inputs_does_not_change_manifest(self):
        metadata, mapping = fixture()
        first = prepare_btxrd_cohort(metadata, mapping)
        second = prepare_btxrd_cohort(list(reversed(metadata)), list(reversed(mapping)))
        self.assertEqual(first["rows"], second["rows"])
        self.assertEqual(first["manifest_digest"], second["manifest_digest"])

    def test_seed_changes_assignment_without_changing_counts(self):
        metadata, mapping = fixture()
        first = prepare_btxrd_cohort(metadata, mapping, seed=17)
        second = prepare_btxrd_cohort(metadata, mapping, seed=18)
        self.assertNotEqual(first["manifest_digest"], second["manifest_digest"])
        self.assertEqual(first["class_counts"], second["class_counts"])

    def test_diagnostic_flag_contradictions_rejected(self):
        metadata, mapping = fixture()
        for update in ({"tumor": 1}, {"benign": 1}, {"malignant": 1}, {"tumor": "maybe"}):
            rows = copy.deepcopy(metadata)
            rows[0].update(update)
            with self.assertRaises(ValueError):
                prepare_btxrd_cohort(rows, mapping)

    def test_duplicate_image_ids_rejected_on_both_sides(self):
        metadata, mapping = fixture()
        for rows, cases in ((metadata + [metadata[0]], mapping), (metadata, mapping + [mapping[0]])):
            with self.assertRaises(ValueError): prepare_btxrd_cohort(rows, cases)

    def test_unmatched_case_map_rejected(self):
        metadata, mapping = fixture()
        mapping[0]["image_id"] = "absent.jpeg"
        with self.assertRaises(ValueError): prepare_btxrd_cohort(metadata, mapping)

    def test_patient_equals_image_id_is_not_grouping_evidence(self):
        metadata, mapping = fixture()
        mapping[0]["patient_id"] = metadata[0]["image_id"]
        self.assertEqual(prepare_btxrd_cohort(metadata, mapping)["status"], "blocked")

    def test_grouping_reference_and_digest_required(self):
        for key in ("patient_id", "grouping_reference", "sha256"):
            metadata, mapping = fixture()
            mapping[0].pop(key)
            report = prepare_btxrd_cohort(metadata, mapping)
            self.assertEqual(report["status"], "blocked")
            self.assertEqual(report["rows"], [])

    def test_conflicting_labels_for_same_digest_block(self):
        metadata, mapping = fixture()
        mapping[12]["sha256"] = mapping[0]["sha256"]
        report = prepare_btxrd_cohort(metadata, mapping)
        self.assertIn("duplicate_label_conflict", {f["code"] for f in report["findings"]})
        self.assertEqual(report["status"], "blocked")

    def test_too_few_groups_never_falls_back_to_image_split(self):
        metadata, mapping = fixture()
        for case in mapping:
            if "malignant" in case["image_id"]: case["patient_id"] = "one-synthetic-patient"
        report = prepare_btxrd_cohort(metadata, mapping)
        self.assertEqual(report["status"], "blocked")
        self.assertIn("too_few_independent_groups_for_class", {f["code"] for f in report["findings"]})

    def test_unsafe_filename_and_file_path_rejected(self):
        for path in ("../outside.jpeg", "/outside.jpeg", "C:\\outside.jpeg"):
            metadata, mapping = fixture()
            metadata[0]["image_id"] = path
            with self.assertRaises(ValueError): prepare_btxrd_cohort(metadata, mapping)
        metadata, mapping = fixture()
        mapping[0]["file_path"] = "../outside.jpeg"
        with self.assertRaises(ValueError): prepare_btxrd_cohort(metadata, mapping)

    def test_bad_fractions_or_seed_rejected(self):
        metadata, mapping = fixture()
        for fractions in ({"train": 1}, {"train": 0.7, "validation": 0.2, "test": 0.2},
                          {"train": 0.7, "validation": float("nan"), "test": 0.3}):
            with self.assertRaises(ValueError): prepare_btxrd_cohort(metadata, mapping, fractions=fractions)
        with self.assertRaises(ValueError): prepare_btxrd_cohort(metadata, mapping, seed=True)

    def test_cli_emits_report_and_rejects_duplicate_headers(self):
        environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder, "metadata.csv")
            source.write_text("image_id,center,tumor,benign,malignant\nfixture.jpeg,1,0,0,0\n")
            command = [sys.executable, "-m", "cancer_workbench", "btxrd-prepare", str(source)]
            first = subprocess.run(command, capture_output=True, text=True, env=environment)
            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertEqual(json.loads(first.stdout)["status"], "blocked")
            source.write_text("image_id,center,tumor,benign,malignant,malignant\nfixture.jpeg,1,0,0,0,1\n")
            second = subprocess.run(command, capture_output=True, text=True, env=environment)
            self.assertEqual(second.returncode, 2)
            self.assertIn("unique column names", second.stderr)


if __name__ == "__main__":
    unittest.main()
