#!/usr/bin/env bash
# Start OncoCopilot. Set ONCO_LLM_BASE_URL to use Gemma; otherwise the offline planner is used.
cd "$(dirname "$0")"
PORT="${PORT:-7860}"
( sleep 1; command -v open >/dev/null && open "http://127.0.0.1:$PORT" ) &
exec python3 -m copilot.server --port "$PORT"
