const $ = (s) => document.querySelector(s);
const log = $("#log");
const history = [];
let busy = false;

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Small, safe markdown: escape first, then format.
function md(src) {
  const lines = esc(src || "").split("\n");
  let html = "", inList = false;
  const inline = (t) => t
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  for (const raw of lines) {
    const line = raw.trimEnd();
    const li = line.match(/^\s*[-*]\s+(.*)/) || line.match(/^\s*\d+\.\s+(.*)/);
    if (li) { if (!inList) { html += "<ul>"; inList = true; } html += `<li>${inline(li[1])}</li>`; continue; }
    if (inList) { html += "</ul>"; inList = false; }
    const h = line.match(/^#{1,4}\s+(.*)/);
    if (h) html += `<h3>${inline(h[1])}</h3>`;
    else if (line.trim()) html += `<p>${inline(line)}</p>`;
  }
  if (inList) html += "</ul>";
  return html;
}

function scroll() { log.scrollTop = log.scrollHeight; }

function addMsg(role, text) {
  log.querySelector(".empty")?.remove();
  const d = document.createElement("div");
  d.className = "msg " + role;
  d.innerHTML = role === "user" ? esc(text) : md(text);
  log.appendChild(d);
  scroll();
  return d;
}

function argSummary(a) {
  if (!a || typeof a !== "object") return String(a ?? "");
  return Object.entries(a).map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : v}`).join(", ");
}

function statusOf(result) {
  const s = result && (result.status || (result.error ? "error" : null));
  if (["blocked", "needs_input", "failed", "error"].includes(s)) return ["blocked", s.replace("_", " ")];
  return ["ok", "observed"];
}

async function send(text) {
  if (busy || !text.trim()) return;
  busy = true; $("#send").disabled = true;
  history.push({ role: "user", content: text });
  addMsg("user", text);
  const trace = document.createElement("div");
  trace.className = "trace";
  log.appendChild(trace);
  const slips = {};
  let finalText = "";
  try {
    const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: history }) });
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
        if (!chunk.startsWith("data: ")) continue;
        const ev = JSON.parse(chunk.slice(6));
        if (ev.type === "tool_call") {
          const el = document.createElement("details");
          el.className = "slip pending";
          el.innerHTML = `<summary><span class="tool">${esc(ev.name)}</span><span class="args">${esc(argSummary(ev.arguments))}</span><span class="state"><span class="spin"></span> running</span></summary>`;
          trace.appendChild(el); slips[ev.id] = el; scroll();
        } else if (ev.type === "tool_result") {
          const el = slips[ev.id];
          if (el) {
            const [cls, label] = statusOf(ev.result);
            el.className = "slip " + cls;
            el.querySelector(".state").textContent = `${label} · ${ev.latency_s}s`;
            const pre = document.createElement("pre");
            pre.textContent = JSON.stringify(ev.result, null, 2);
            el.appendChild(pre);
          }
          if (["compare_models", "evaluate_model", "audit_dataset", "list_results"].includes(ev.name)) refreshPanels();
        } else if (ev.type === "reasoning") {
          const r = document.createElement("details");
          r.className = "reasoning";
          r.innerHTML = `<summary>Model reasoning</summary><pre>${esc(ev.text)}</pre>`;
          trace.appendChild(r);
        } else if (ev.type === "note") {
          addMsg("assistant", ev.text);
        } else if (ev.type === "message") {
          finalText = ev.text; addMsg("assistant", ev.text);
        } else if (ev.type === "error") {
          addMsg("error", ev.message);
        }
      }
    }
  } catch (e) {
    addMsg("error", "Connection to the server failed: " + e.message);
  }
  if (finalText) history.push({ role: "assistant", content: finalText });
  busy = false; $("#send").disabled = false; $("#input").focus();
}

$("#composer").addEventListener("submit", (e) => { e.preventDefault(); const v = $("#input").value; $("#input").value = ""; send(v); });
$("#input").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#composer").requestSubmit(); } });
document.querySelectorAll(".prompt").forEach((b) => b.addEventListener("click", () => send(b.dataset.q)));

document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => {
  document.querySelectorAll(".tabs button").forEach((x) => x.setAttribute("aria-selected", x === b));
  document.querySelectorAll(".tabbody").forEach((x) => (x.hidden = x.id !== "tab-" + b.dataset.tab));
}));

const fmt = (x, d = 3) => (x == null ? "–" : Number(x).toFixed(d));
const ciTxt = (c) => (c ? `[${fmt(c[0])}, ${fmt(c[1])}]` : "");

function cmGrid(m) {
  const labels = m.label_names, cm = m.confusion_matrix;
  const max = Math.max(...cm.flat(), 1);
  let h = `<div class="cm" style="grid-template-columns: 70px repeat(${labels.length}, 1fr)"><div class="h">true \\ pred</div>`;
  labels.forEach((l) => (h += `<div class="h">${esc(l)}</div>`));
  cm.forEach((row, i) => {
    h += `<div class="h" style="text-align:left">${esc(labels[i])}</div>`;
    row.forEach((v, j) => {
      const a = (v / max) * 0.85 + 0.05;
      const color = i === j ? `rgba(62,49,137,${a})` : `rgba(201,60,114,${a})`;
      h += `<div style="background:${color};color:${a > .5 ? "#fff" : "inherit"}">${v}</div>`;
    });
  });
  return h + "</div>";
}

async function refreshPanels() {
  const [res, reg] = await Promise.all([fetch("/api/results").then((r) => r.json()), fetch("/api/registry").then((r) => r.json())]);
  // Results
  let h = "";
  if (res.comparison) {
    const c = res.comparison;
    h += `<div class="card"><h3>${esc(c.a.model_id)} vs ${esc(c.b.model_id)}</h3>
      <p class="verdict">${esc(c.verdict)}</p>
      <div class="metric"><span>Balanced-accuracy difference</span><b>${fmt(c.balanced_accuracy_delta)}</b></div>
      <div class="ci">95% CI ${ciTxt(c.delta_ci95)} · McNemar p = ${fmt(c.mcnemar.p_value, 4)} · ${c.n_paired} paired images</div></div>`;
  }
  for (const m of res.metrics || []) {
    const mal = (m.per_class || {}).malignant || {};
    h += `<div class="card"><h3>${esc(m.model_id)}</h3><p class="hint">${esc(m.partition || "")} · n = ${m.n}</p>
      <div class="metric"><span>Balanced accuracy</span><b>${fmt(m.balanced_accuracy)}</b></div><div class="ci">${ciTxt(m.ci95?.balanced_accuracy)}</div>
      <div class="metric malig"><span>Malignant recall</span><b>${fmt(mal.recall)}</b></div>
      <div class="metric malig"><span>Malignant AUC</span><b>${fmt(mal.auc_ovr)}</b></div><div class="ci">${ciTxt(m.ci95?.malignant_auc)}</div>
      <div class="metric"><span>Calibration error (ECE)</span><b>${fmt(m.ece)}</b></div>
      ${cmGrid(m)}</div>`;
  }
  if (!h) h = `<p class="hint">No experiment results yet. After the baselines run on NPS, copy <code>results/</code> here and they appear automatically.</p>`;
  $("#tab-results").innerHTML = h;
  // Data
  const s = res.split;
  if (s && s.counts) {
    let t = `<div class="card"><h3>BTXRD split</h3><p class="hint">${esc(s.strategy || "")}</p><table class="t"><tr><th>partition</th>`;
    const labels = s.label_names || ["normal", "benign", "malignant"];
    labels.forEach((l) => (t += `<th>${esc(l)}</th>`));
    t += "<th>total</th></tr>";
    for (const [part, c] of Object.entries(s.counts)) {
      t += `<tr><td>${esc(part)}</td>${labels.map((l) => `<td>${c[l] ?? 0}</td>`).join("")}<td>${Object.values(c).reduce((a, b) => a + b, 0)}</td></tr>`;
    }
    t += "</table>";
    if (s.warnings?.length) t += `<ul class="hint">${s.warnings.map((w) => `<li>${esc(w)}</li>`).join("")}</ul>`;
    $("#tab-data").innerHTML = t + "</div>";
  } else {
    $("#tab-data").innerHTML = `<p class="hint">BTXRD isn't prepared yet. On NPS run <code>bash nps/fetch_data.sh</code>, then <code>python3 -m training.btxrd.prepare</code>.</p>`;
  }
  // Models
  $("#tab-models").innerHTML = reg.map((m) => `<div class="model"><div class="row"><span class="id">${esc(m.id)}</span><span class="badge ${esc(m.state)}">${esc(m.state.replace("_", " "))}</span></div>
    <p>${esc(m.notes || "")}</p>
    ${m.state === "locally_reproduced" && m.adapter_id ? `<button class="authorize" data-id="${esc(m.id)}">Authorize demo runs</button>` : ""}</div>`).join("");
  document.querySelectorAll(".authorize").forEach((b) => b.addEventListener("click", async () => {
    const r = await fetch("/api/authorize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ref: "demo-" + b.dataset.id, model_id: b.dataset.id }) }).then((x) => x.json());
    b.textContent = r.ok ? `Authorized as ${r.ref}` : r.error;
    b.disabled = true;
  }));
}

fetch("/api/status").then((r) => r.json()).then((s) => {
  const p = $("#model-pill");
  p.textContent = s.mock ? "Offline mock · connect Gemma to reason" : s.llm;
  p.classList.toggle("mock", s.mock);
});
refreshPanels();
