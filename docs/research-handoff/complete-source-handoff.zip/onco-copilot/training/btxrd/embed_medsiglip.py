"""Cache frozen MedSigLIP image embeddings for every BTXRD image (1 GPU, minutes).

    python3 -m training.btxrd.embed_medsiglip --root $DATA/BTXRD --results results \
        --model google/medsiglip-448 --out $WORK/cache/medsiglip_btxrd.npz

Requires: torch, transformers (with SigLIP support), pillow, numpy.
MedSigLIP is gated: accept the Health AI Developer Foundations terms on Hugging Face
with the account whose HF_TOKEN is set.
"""

import argparse
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from transformers import AutoModel, AutoProcessor

from training.common import read_manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--results", default="results")
    ap.add_argument("--model", default="google/medsiglip-448")
    ap.add_argument("--out", required=True)
    ap.add_argument("--batch", type=int, default=64)
    a = ap.parse_args()

    rows = read_manifest(a.results)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model = AutoModel.from_pretrained(a.model, torch_dtype=torch.bfloat16 if dev == "cuda" else torch.float32).to(dev).eval()
    proc = AutoProcessor.from_pretrained(a.model)
    ids, feats = [], []
    for start in range(0, len(rows), a.batch):
        chunk = rows[start:start + a.batch]
        images = [Image.open(Path(a.root) / r["path"]).convert("RGB") for r in chunk]
        inputs = proc(images=images, return_tensors="pt").to(dev)
        with torch.no_grad():
            emb = model.get_image_features(**{k: v.to(model.dtype) if v.is_floating_point() else v for k, v in inputs.items()})
            emb = torch.nn.functional.normalize(emb.float(), dim=-1)
        feats.append(emb.cpu().numpy())
        ids += [r["image_id"] for r in chunk]
        print(f"{start + len(chunk)}/{len(rows)}", flush=True)
    X = np.concatenate(feats).astype(np.float32)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(a.out, ids=np.array(ids), X=X, model=a.model)
    print("saved", X.shape, "to", a.out)


if __name__ == "__main__":
    main()
