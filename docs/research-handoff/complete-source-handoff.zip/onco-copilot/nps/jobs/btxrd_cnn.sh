#!/usr/bin/env bash
# Matched ConvNeXt-Tiny baseline on identical splits; planned one-GPU exploratory job.
set -euo pipefail
source "$(dirname "$0")/../env.sh"
[ -f "$WORK/venv/bin/activate" ] && source "$WORK/venv/bin/activate"
[ -f "$ONCO_RESULTS_DIR/btxrd_manifest.csv" ] || { echo "BTXRD manifest missing; acquire and prepare data explicitly first" >&2; exit 1; }
python3 -m training.btxrd.guard "$ONCO_RESULTS_DIR/btxrd_split.json"
python3 -m training.btxrd.train_cnn --root "$DATA/BTXRD" --results "$ONCO_RESULTS_DIR" \
  --epochs "${EPOCHS:-15}" --ckpt "$WORK/ckpt/btxrd_cnn.pt"
if [ -f "$ONCO_RESULTS_DIR/btxrd-medsiglip-head.external_test.predictions.json" ]; then
  python3 -m training.btxrd.compare --results "$ONCO_RESULTS_DIR"
fi
