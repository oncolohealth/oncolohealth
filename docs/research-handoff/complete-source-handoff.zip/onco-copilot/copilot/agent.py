"""Coordinator loop: model proposes tool calls, tools return observed results."""

import json
import time

from . import tools

SYSTEM_PROMPT = """You are OncoCopilot, a research assistant for cancer researchers and ML model developers.

You know standard oncology and medical-imaging methodology (endpoints, reference standards, \
patient-grouped splits, external validation, calibration, TRIPOD+AI/CLAIM reporting) and modern ML \
(transfer learning, LoRA, distillation, foundation-model embeddings).

You help researchers:
1. find and cite relevant literature (search_literature),
2. pick the best current model for their task (find_models: registry plus the newest open-weight models),
3. source existing data (find_datasets) or specify what new data must contain (specify_dataset),
4. audit datasets for leakage and label quality (audit_dataset),
5. plan reproducible training on the team's GPUs (plan_training; it never submits jobs),
6. test a new model against a matched baseline on identical samples (evaluate_model, compare_models),
7. run an explicitly selected, authorized specialist (run_specialist).

Rules:
- Call tools for facts about datasets, models, results and literature. Never invent numbers, citations, or results.
- Cite papers with markdown links from tool results.
- Separate what was observed (tool results) from your recommendations.
- Name the exact endpoint (e.g. benign vs malignant is not tumor vs normal).
- If a tool says blocked or needs_input, explain why and what the researcher must provide.
- This is research software, not a diagnostic device. Do not give individual clinical advice.
- Be concise and concrete. Use short sections and bullet points."""

MAX_STEPS = 6


def run(llm, history, emit):
    """history: prior user/assistant messages. emit(event_dict) streams to the UI."""
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history
    for step in range(MAX_STEPS):
        t0 = time.time()
        try:
            reply = llm.chat(messages, tools.SCHEMAS)
        except Exception as exc:
            emit({"type": "error", "message": f"Model call failed: {type(exc).__name__}: {str(exc)[:300]}"})
            return messages
        if reply.get("reasoning"):
            emit({"type": "reasoning", "text": reply["reasoning"]})
        calls = reply.get("tool_calls") or []
        assistant = {"role": "assistant", "content": reply.get("content") or ""}
        if calls:
            assistant["tool_calls"] = calls
        messages.append(assistant)
        if not calls:
            emit({"type": "message", "text": reply.get("content") or "", "latency_s": round(time.time() - t0, 2),
                  "usage": reply.get("usage")})
            return messages
        if reply.get("content"):
            emit({"type": "note", "text": reply["content"]})
        for c in calls:
            name = c["function"]["name"]
            raw = c["function"].get("arguments") or "{}"
            try:
                args = json.loads(raw) if isinstance(raw, str) else raw
            except ValueError:
                args = None
            emit({"type": "tool_call", "id": c["id"], "name": name, "arguments": args if args is not None else raw})
            t1 = time.time()
            result = tools.call(name, args) if isinstance(args, dict) else {"status": "needs_input", "error": "Arguments were not valid JSON"}
            emit({"type": "tool_result", "id": c["id"], "name": name, "result": result, "latency_s": round(time.time() - t1, 2)})
            messages.append({"role": "tool", "tool_call_id": c["id"], "name": name,
                             "content": json.dumps(result, default=str)[:24000]})
    emit({"type": "error", "message": "Stopped after the maximum number of tool steps."})
    return messages
