"""SYNTHETIC files and mocked embeddings only; no cancer data or model loading."""

import copy
import hashlib
import importlib.util
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from cancer_workbench.learning.feature_identity import SCHEMA, binding_digest, measure_inputs, validate_cached_inputs


class BindingFixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.rows = []
        for i, body in enumerate((b"synthetic first image bytes", b"synthetic second image bytes")):
            name = f"image-{i}.bin"
            (self.root / name).write_bytes(body)
            self.rows.append({"sample_id": f"s{i}", "file": name, "sha256": hashlib.sha256(body).hexdigest()})

    def cache(self):
        measured = measure_inputs(self.rows, self.root)
        return {"sample_ids": [r["sample_id"] for r in measured], "image_sha256": [r["sha256"] for r in measured],
                "input_binding_schema": SCHEMA, "input_content_sha256": binding_digest(measured),
                "features": SimpleNamespace(shape=(len(measured), 2))}


class InputBindingTests(BindingFixture):
    def test_measured_roundtrip_and_no_optional_identity_metadata(self):
        measured = measure_inputs(self.rows, self.root)
        self.assertEqual(set(measured[0]), {"sample_id", "sha256"})
        self.assertIsNone(validate_cached_inputs(self.cache(), self.rows, self.root))

    def test_replaced_file_rejects_old_cache_even_with_updated_manifest_hash(self):
        cached = self.cache()
        body = b"synthetic replacement"
        (self.root / self.rows[0]["file"]).write_bytes(body)
        self.rows[0]["sha256"] = hashlib.sha256(body).hexdigest()
        with self.assertRaisesRegex(ValueError, "current image IDs and bytes"):
            validate_cached_inputs(cached, self.rows, self.root)

    def test_no_declared_hash_still_binds_measured_bytes(self):
        self.rows = [dict(r, sha256="") for r in self.rows]
        cached = self.cache()
        (self.root / self.rows[0]["file"]).write_bytes(b"replacement without a declaration")
        with self.assertRaises(ValueError):
            validate_cached_inputs(cached, self.rows, self.root)

    def test_declared_hash_drift_and_malformed_hash_fail(self):
        for value in ("0" * 64, "invalid", 5, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                measure_inputs([dict(self.rows[0], sha256=value)], self.root)

    def test_duplicate_or_blank_source_ids_fail(self):
        for rows in ([], [self.rows[0], self.rows[0]], [dict(self.rows[0], sample_id="")],
                     [dict(self.rows[0], sample_id=" s0")], [dict(self.rows[0], sample_id=1)]):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                measure_inputs(rows, self.root)

    def test_missing_file_is_explicit_without_exporting_path(self):
        secret = "synthetic-private-file-name.bin"
        with self.assertRaises(ValueError) as caught:
            measure_inputs([dict(self.rows[0], file=secret)], self.root)
        self.assertNotIn(secret, str(caught.exception))
        self.assertNotIn(str(self.root), str(caught.exception))

    def test_absolute_parent_windows_and_symlink_escape_fail(self):
        with tempfile.TemporaryDirectory() as outside:
            external = Path(outside) / "external.bin"
            external.write_bytes(b"synthetic external bytes")
            (self.root / "escape.bin").symlink_to(external)
            for name in (str(external), "../external.bin", "C:external.bin", "folder\\external.bin", "escape.bin"):
                with self.subTest(path_kind=name), self.assertRaises(ValueError):
                    measure_inputs([dict(self.rows[0], file=name, sha256="")], self.root)

    def test_legacy_cache_or_unknown_schema_fails(self):
        cache = self.cache()
        for missing in ("image_sha256", "input_content_sha256", "input_binding_schema"):
            old = {k: v for k, v in cache.items() if k != missing}
            with self.subTest(missing=missing), self.assertRaisesRegex(ValueError, "supported image binding"):
                validate_cached_inputs(old, self.rows, self.root)
        with self.assertRaises(ValueError):
            validate_cached_inputs(dict(cache, input_binding_schema="other"), self.rows, self.root)

    def test_duplicate_cached_ids_fail(self):
        with self.assertRaisesRegex(ValueError, "unique"):
            validate_cached_inputs(dict(self.cache(), sample_ids=["s0", "s0"]), self.rows, self.root)

    def test_omitted_extra_or_renamed_source_rows_fail(self):
        cached = self.cache()
        for rows in (self.rows[:1], [*self.rows, dict(self.rows[0], sample_id="extra")],
                     [dict(self.rows[0], sample_id="renamed"), self.rows[1]]):
            with self.subTest(row_count=len(rows)), self.assertRaises(ValueError):
                validate_cached_inputs(cached, rows, self.root)

    def test_mapping_digest_tampering_and_bad_hash_rows_fail(self):
        cached = self.cache()
        cases = (dict(cached, input_content_sha256="0" * 64), dict(cached, image_sha256=["bad"] * 2),
                 dict(cached, image_sha256=cached["image_sha256"][:1]), dict(cached, sample_ids="s0"),
                 dict(cached, image_sha256="0" * 64), dict(cached, input_content_sha256=None))
        for bad in cases:
            with self.subTest(fields=list(bad)), self.assertRaises(ValueError):
                validate_cached_inputs(bad, self.rows, self.root)

    def test_feature_row_shape_must_match_cached_ids(self):
        for shape in ((1, 2), (2,), (2, 0), (2, 2, 1)):
            with self.subTest(shape=shape), self.assertRaises(ValueError):
                validate_cached_inputs(dict(self.cache(), features=SimpleNamespace(shape=shape)), self.rows, self.root)

    def test_manifest_and_cache_order_may_differ_without_losing_id_binding(self):
        cached = self.cache()
        self.assertIsNone(validate_cached_inputs(cached, list(reversed(self.rows)), self.root))
        self.assertEqual(binding_digest(measure_inputs(self.rows, self.root)),
                         binding_digest(measure_inputs(list(reversed(self.rows)), self.root)))

    def test_label_patient_and_partition_edits_do_not_invalidate_unchanged_pixels(self):
        updated = [dict(r, patient_id="synthetic-private-patient", label="synthetic-new-label", partition="val")
                   for r in self.rows]
        self.assertIsNone(validate_cached_inputs(self.cache(), updated, self.root))


@unittest.skipUnless(importlib.util.find_spec("numpy"), "Optional numpy unavailable")
class CacheIOTests(BindingFixture):
    def extract(self, path, *, side_effect=None, values=None):
        import numpy as np
        from cancer_workbench.adapters import encoder
        from cancer_workbench.learning import features

        adapter = SimpleNamespace(device="synthetic", embed=unittest.mock.Mock(
            side_effect=side_effect, return_value=np.array([[1., 2.], [3., 4.]]) if values is None else values))
        with patch.object(encoder, "FrozenEncoderAdapter", return_value=adapter), \
                patch.object(encoder, "revision", return_value="a" * 40):
            return features.extract_features("rad-dino", self.rows, self.root, path, quiet=True)

    def legacy(self, path):
        import numpy as np
        from cancer_workbench.adapters import encoder

        np.savez(path, sample_ids=np.array([r["sample_id"] for r in self.rows]), features=np.zeros((2, 2)),
                 encoder_id="rad-dino", revision="a" * 40, variant="pad",
                 preprocessing_hash=encoder.preprocessing_hash("rad-dino"))

    def test_npz_roundtrip_is_bound_and_changed_source_is_rejected(self):
        from cancer_workbench.adapters import encoder
        from cancer_workbench.learning.features import load_bound_features

        target = self.root / "bound.npz"
        self.extract(target)
        with patch.object(encoder, "revision", return_value="a" * 40):
            result = load_bound_features(target, self.rows, self.root, "rad-dino")
            self.assertEqual(result["input_binding_schema"], SCHEMA)
            self.assertEqual(result["features"].shape, (2, 2))
            body = b"synthetic replacement after cache write"
            (self.root / self.rows[0]["file"]).write_bytes(body)
            self.rows[0]["sha256"] = hashlib.sha256(body).hexdigest()
            with self.assertRaises(ValueError):
                load_bound_features(target, self.rows, self.root, "rad-dino")

    def test_changed_source_during_embedding_preserves_existing_output(self):
        import numpy as np

        self.rows = [dict(r, sha256="") for r in self.rows]
        target = self.root / "existing.npz"
        target.write_bytes(b"synthetic old artifact")

        def changed(*args, **kwargs):
            (self.root / self.rows[0]["file"]).write_bytes(b"synthetic mutation during mocked embedding")
            return np.zeros((2, 2))

        with self.assertRaisesRegex(ValueError, "changed during feature extraction"):
            self.extract(target, side_effect=changed)
        self.assertEqual(target.read_bytes(), b"synthetic old artifact")

    def test_failed_embedding_and_failed_npz_write_preserve_existing_output(self):
        import numpy as np

        target = self.root / "existing.npz"
        target.write_bytes(b"synthetic old artifact")
        with self.assertRaises(RuntimeError):
            self.extract(target, side_effect=RuntimeError("Synthetic embedding failure"))
        before = set(self.root.iterdir())
        with patch.object(np, "savez", side_effect=OSError("Synthetic disk failure")), self.assertRaises(OSError):
            self.extract(target)
        self.assertEqual(target.read_bytes(), b"synthetic old artifact")
        self.assertEqual(set(self.root.iterdir()), before)

    def test_invalid_encoder_arrays_never_publish_a_cache(self):
        import numpy as np

        target = self.root / "invalid.npz"
        for values in (np.zeros((1, 2)), np.zeros(2), np.full((2, 2), np.nan), np.array([["x", "y"], ["a", "b"]])):
            with self.subTest(shape=values.shape), self.assertRaises(ValueError):
                self.extract(target, values=values)
            self.assertFalse(target.exists())

    def test_wrong_encoder_revision_variant_and_nonscalar_identity_fail(self):
        import numpy as np
        from cancer_workbench.adapters import encoder
        from cancer_workbench.learning.features import load_bound_features, load_features

        target = self.root / "bound.npz"
        self.extract(target)
        original = load_features(target)
        changes = ({"encoder_id": "other"}, {"revision": "b" * 40}, {"variant": "native_crop"},
                   {"preprocessing_hash": "other"}, {"encoder_id": np.array(["rad-dino"])},
                   {"input_binding_schema": np.array([SCHEMA])})
        with patch.object(encoder, "revision", return_value="a" * 40):
            for change in changes:
                np.savez(target, **{**original, **change})
                with self.subTest(fields=list(change)), self.assertRaises(ValueError):
                    load_bound_features(target, self.rows, self.root, "rad-dino")
        np.savez(target, **original)
        with patch.object(encoder, "revision", return_value=None), self.assertRaisesRegex(ValueError, "revision is unavailable"):
            load_bound_features(target, self.rows, self.root, "rad-dino")

    def test_all_four_cache_readers_refuse_legacy_and_stale_before_work(self):
        from contextlib import ExitStack
        from cancer_workbench.adapters import encoder
        from cancer_workbench.experiments import btxrd_baseline, btxrd_source_shift, btxrd_near_duplicates, explore
        from cancer_workbench.learning import features, heads

        target = self.root / "legacy.npz"
        self.legacy(target)
        stale = self.root / "stale.npz"
        self.extract(stale)
        changed = b"synthetic source changed before consumer entry"
        (self.root / self.rows[0]["file"]).write_bytes(changed)
        self.rows[0]["sha256"] = hashlib.sha256(changed).hexdigest()
        manifest = self.root / "manifest.csv"
        manifest.write_text("synthetic manifest bytes")
        for kind, cache_file, expected_error in (("legacy", target, "supported image binding"),
                                                  ("stale", stale, "current image IDs and bytes")):
            for module in (btxrd_baseline, btxrd_source_shift, btxrd_near_duplicates, explore):
                with self.subTest(reader=module.__name__, cache_kind=kind), ExitStack() as stack:
                    stack.enter_context(patch.object(module, "read_manifest", return_value=copy.deepcopy(self.rows)))
                    stack.enter_context(patch.object(module, "RAW_DIR", self.root))
                    stack.enter_context(patch.object(encoder, "revision", return_value="a" * 40))
                    stack.enter_context(patch.object(features, "cache_path", return_value=cache_file))
                    extract = stack.enter_context(patch.object(features, "extract_features"))
                    fit = stack.enter_context(patch.object(heads, "train_feature_head"))
                    rank = stack.enter_context(patch.object(btxrd_near_duplicates, "pair_scores"))
                    if module is explore:
                        call = lambda: module._refit(self.root, {"encoder": "rad-dino", "endpoint": "three_class", "protocol": "synthetic"})
                    else:
                        stack.enter_context(patch.object(module, "MANIFEST_PATH", manifest))
                        if module is not btxrd_near_duplicates:
                            stack.enter_context(patch.object(module, "_git_revision", return_value="synthetic"))
                        kwargs = {"out_dir": self.root / module.__name__.split(".")[-1]}
                        if module is not btxrd_near_duplicates:
                            kwargs["encoders"] = ("rad-dino",)
                        if module is btxrd_source_shift:
                            kwargs["variants"] = ("pad",)
                        call = lambda: module.run(**kwargs)
                    with self.assertRaisesRegex(ValueError, expected_error):
                        call()
                    extract.assert_not_called()
                    fit.assert_not_called()
                    rank.assert_not_called()


if __name__ == "__main__":
    unittest.main()
