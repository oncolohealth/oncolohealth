# OncoCopilot

A research copilot for cancer researchers and ML model developers. Ask a question in plain language and it:

- **searches the literature** with citations (Europe PMC, live)
- **recommends the best current local model** for a task: registry compatibility checks plus the newest and most-used open-weight models on Hugging Face (live)
- **sources existing datasets**, or **specifies what new data must contain**, including the minimum independent test-set size (Buderer sample-size formula)
- **audits datasets** for declared patient/duplicate grouping, exact-byte duplicates, visual-overlap candidates, and site-label confounding
- **plans reproducible training** on the team's GPUs (never auto-submits)
- **tests a new model against a matched baseline** on identical samples: bootstrap 95% CIs, McNemar test, calibration
- **runs specialist models** only through a gated contract: explicit selection, reviewed permission, and a human-granted authorization

Every claim in a response comes from a tool call that you can expand and inspect in the UI.

The proposed large-machine coordinator is **Google Gemma 4 31B IT** served through an OpenAI-compatible endpoint. The repo contains draft LoRA and evaluation code; no Gemma weights have been acquired here, and no fine-tuning or before/after result has been verified. Specialist encoders remain independent of the main LLM's origin.

## Run the local app (standard library, Python 3.10+)

```sh
python3 -B -m copilot.server            # http://127.0.0.1:7860, offline mock planner
ONCO_LLM_BASE_URL=http://localhost:8000/v1 ONCO_LLM_MODEL=google/gemma-4-31B-it python3 -B -m copilot.server
```

Without `ONCO_LLM_BASE_URL`, the app uses a deterministic offline planner clearly labeled in the UI. Point it at an OpenAI-compatible server to use a real Gemma model. The [5070 Ti guide](docs/LOCAL-5070TI.md) explains which sizes fit locally and what still needs testing. The 31B NPS serving script requires a compatible vLLM build and Gemma 4 tool chat template; it has not been run.

Run synthetic software tests (84 passed with Pillow installed; two visual-image checks skip if Pillow is absent):

```sh
python3 -B -m unittest discover -s tests
```

## Layout

| Path | What |
|---|---|
| `copilot/` | Agent loop, tools, gated execution contract, evaluation stats, live research connectors, web server |
| `web/` | Single-page UI: chat, inspectable tool trace, results/data/models panels |
| `data/` | Curated dataset catalog and model registry |
| `cancer_workbench/` | Original foundation: routing, dataset audits, BTXRD cohort prep, feature heads |
| `training/btxrd/` | Exploratory source-held-out BTXRD split, MedSigLIP embeddings + head, ConvNeXt baseline, paired comparison |
| `training/coordinator/` | Task bank, draft self-distilled SFT data generation, Gemma LoRA trainer, merge, held-out evaluation |
| `nps/` | GB300 scripts (written, **not yet run**; no automatic dataset/model acquisition inside jobs) |
| `docs/` | Integration-contract proposal and foundation verification notes |

## First experiment: BTXRD bone tumor X-rays

The proposed task is three-class classification: normal / benign / malignant. BTXRD publishes no patient IDs, so this is an **exploratory source-held-out design**, not patient-independent validation:

- **Train/validation:** center 1, the three hospitals (2,938 release images; four contradictory exact copies excluded from the current draft).
- **External test:** Radiopaedia + MedPix (808 images, 107 malignant).
- **Duplicates:** exact-byte families stay within one partition. Contradictory-label and cross-source exact families are excluded. dHash visual matches are review candidates only, not inferred patient groups.

The preparation script reads the release's `dataset.xlsx` or a CSV export and marks the split `exploratory_only` with `ready_for_training: false`. An offline audit of the original release found 21 exact duplicate pairs, including two contradictory normal/benign pairs. The corrected draft has 2,494 training, 440 validation, and 808 external-source images. A coarse dHash generated 10,372 visual-overlap candidates, including 3,483 development-versus-external matches; those matches have not been adjudicated. Its training jobs require an explicit exploratory opt-in after separate authorization. MedSigLIP and ConvNeXt baselines are scripted but have not been run in this local build. Their reported performance must not be treated as known. Resolve patient grouping, label/reference evidence and evaluation design before any medical-performance claim.

## Scope

This is research software, not a diagnostic device. Metrics describe the stated partition only. Cancer-detection claims require independent patients, confirmed reference labels, and expert review.
