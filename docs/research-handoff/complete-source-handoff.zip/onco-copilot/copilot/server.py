"""Zero-dependency web server: static UI + streaming chat API.

    python3 -m copilot.server --port 7860
    ONCO_LLM_BASE_URL=http://localhost:8000/v1 python3 -m copilot.server
"""

import argparse
import json
import mimetypes
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import agent, llm as llm_mod, tools

WEB = Path(__file__).resolve().parent.parent / "web"
LLM = None
LOCK = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    server_version = "OncoCopilot/0.1"

    def log_message(self, fmt, *args):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/api/status":
            return self._json({"llm": LLM.name, "mock": isinstance(LLM, llm_mod.MockChat),
                               "tools": [s["function"]["name"] for s in tools.SCHEMAS]})
        if path == "/api/registry":
            return self._json(tools.registry())
        if path == "/api/datasets":
            return self._json(tools.datasets())
        if path == "/api/results":
            res = tools.t_list_results()
            full = []
            for f in sorted(tools.RESULTS.glob("*.metrics.json")):
                full.append(json.loads(f.read_text()))
            res["metrics"] = full
            comp = tools.RESULTS / "comparison.json"
            res["comparison"] = json.loads(comp.read_text()) if comp.exists() else None
            split = tools.RESULTS / "btxrd_split.json"
            res["split"] = json.loads(split.read_text()) if split.exists() else None
            return self._json(res)
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        target = (WEB / rel).resolve()
        if not str(target).startswith(str(WEB.resolve())) or not target.is_file():
            return self._json({"error": "not found"}, 404)
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if self.path == "/api/chat":
            req = self._body()
            history = [m for m in req.get("messages", []) if m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str)]
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()

            def emit(ev):
                try:
                    self.wfile.write(b"data: " + json.dumps(ev, default=str).encode() + b"\n\n")
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    pass

            agent.run(LLM, history[-20:], emit)
            emit({"type": "done"})
            return
        if self.path == "/api/authorize":
            if self.client_address[0] not in ("127.0.0.1", "::1"):
                return self._json({"error": "Authorizations can only be granted from the local machine"}, 403)
            req = self._body()
            ref, model_id = req.get("ref"), req.get("model_id")
            if not ref or not model_id:
                return self._json({"error": "ref and model_id required"}, 400)
            with LOCK:
                p = tools.RESULTS / "authorizations.json"
                data = json.loads(p.read_text()) if p.exists() else {}
                data[ref] = {"granted": True, "scope": [model_id], "by": req.get("by", "local user")}
                tools.RESULTS.mkdir(parents=True, exist_ok=True)
                p.write_text(json.dumps(data, indent=2))
            return self._json({"ok": True, "ref": ref})
        if self.path == "/api/tool":  # direct tool calls from UI panels
            req = self._body()
            return self._json(tools.call(req.get("name"), req.get("arguments") or {}))
        self._json({"error": "not found"}, 404)


def main():
    global LLM
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=7860)
    a = ap.parse_args()
    LLM = llm_mod.from_env()
    print(f"OncoCopilot on http://{a.host}:{a.port}  (model: {LLM.name})", flush=True)
    ThreadingHTTPServer((a.host, a.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
