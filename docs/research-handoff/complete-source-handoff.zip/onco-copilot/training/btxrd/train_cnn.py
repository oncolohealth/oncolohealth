"""Matched CNN baseline: fine-tune an ImageNet ConvNeXt on identical splits (1 GPU).

    python3 -m training.btxrd.train_cnn --root $DATA/BTXRD --results results --epochs 15

Early stopping and checkpoint selection use validation balanced accuracy only.
Requires torch, torchvision, pillow. ImageNet weights download from download.pytorch.org.
"""

import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms

from training.common import LABELS, read_manifest, write_outputs

MODEL_ID = "btxrd-cnn-baseline"
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


class DS(Dataset):
    def __init__(self, root, rows, tf):
        self.root, self.rows, self.tf = Path(root), rows, tf

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        img = Image.open(self.root / r["path"]).convert("RGB")
        return self.tf(img), LABELS.index(r["label"]), i


def run_eval(model, loader, dev):
    model.eval()
    probs, idx = [], []
    with torch.no_grad(), torch.autocast(dev, dtype=torch.bfloat16, enabled=dev == "cuda"):
        for x, _, i in loader:
            probs.append(torch.softmax(model(x.to(dev)).float(), 1).cpu())
            idx.append(i)
    return torch.cat(probs).numpy(), torch.cat(idx).numpy()


def bal_acc(rows, P, idx):
    y = np.array([LABELS.index(rows[i]["label"]) for i in idx])
    pred = P.argmax(1)
    return np.mean([np.mean(pred[y == k] == k) for k in range(3) if np.any(y == k)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--results", default="results")
    ap.add_argument("--arch", default="convnext_tiny", choices=["convnext_tiny", "resnet50"])
    ap.add_argument("--size", type=int, default=448)
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--ckpt", default="checkpoints/btxrd_cnn.pt")
    a = ap.parse_args()
    torch.manual_seed(0)
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    rows = read_manifest(a.results)
    split = {s: [r for r in rows if r["split"] == s] for s in ("train", "validation", "external_test")}
    train_tf = transforms.Compose([transforms.RandomResizedCrop(a.size, scale=(0.7, 1.0)), transforms.RandomHorizontalFlip(),
                                   transforms.RandomRotation(10), transforms.ColorJitter(0.2, 0.2),
                                   transforms.ToTensor(), transforms.Normalize(MEAN, STD)])
    eval_tf = transforms.Compose([transforms.Resize((a.size, a.size)), transforms.ToTensor(), transforms.Normalize(MEAN, STD)])
    dl = lambda s, tf, sh: DataLoader(DS(a.root, split[s], tf), batch_size=a.batch, shuffle=sh, num_workers=a.workers, pin_memory=True)
    train_dl, val_dl, test_dl = dl("train", train_tf, True), dl("validation", eval_tf, False), dl("external_test", eval_tf, False)

    if a.arch == "convnext_tiny":
        model = models.convnext_tiny(weights=models.ConvNeXt_Tiny_Weights.IMAGENET1K_V1)
        model.classifier[2] = nn.Linear(model.classifier[2].in_features, 3)
    else:
        model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
        model.fc = nn.Linear(model.fc.in_features, 3)
    model.to(dev)
    counts = np.bincount([LABELS.index(r["label"]) for r in split["train"]], minlength=3)
    weights = torch.tensor(counts.sum() / (3 * np.maximum(counts, 1)), dtype=torch.float32, device=dev)
    loss_fn = nn.CrossEntropyLoss(weight=weights)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.05)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs)
    best, patience = -1.0, 0
    Path(a.ckpt).parent.mkdir(parents=True, exist_ok=True)
    for epoch in range(a.epochs):
        model.train()
        for x, y, _ in train_dl:
            x, y = x.to(dev), y.to(dev)
            with torch.autocast(dev, dtype=torch.bfloat16, enabled=dev == "cuda"):
                loss = loss_fn(model(x).float(), y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
        sched.step()
        P, idx = run_eval(model, val_dl, dev)
        score = bal_acc(split["validation"], P, idx)
        print(f"epoch {epoch + 1}: validation balanced accuracy {score:.3f}", flush=True)
        if score > best:
            best, patience = score, 0
            torch.save(model.state_dict(), a.ckpt)
        else:
            patience += 1
            if patience >= 4:
                break
    model.load_state_dict(torch.load(a.ckpt, map_location=dev))
    for name, loader in (("validation", val_dl), ("external_test", test_dl)):
        P, idx = run_eval(model, loader, dev)
        rs = split[name]
        out = [{"sample_id": rs[i]["image_id"], "label": rs[i]["label"], "probabilities": [float(v) for v in p]} for p, i in zip(P, idx)]
        write_outputs(a.results, MODEL_ID, name, out, {"arch": a.arch, "input_size": a.size, "best_validation_balanced_accuracy": best})


if __name__ == "__main__":
    main()
