"""Generate tool-use SFT data by rejection-sampling the base model in thinking mode.

The teacher is Gemma 4 31B itself with thinking ON (slow, careful). Real tools are
executed, so every tool result in the data is observed, not invented. A trajectory is
kept only if it passes automatic checks; the student is trained to reproduce the
accepted trajectories with thinking OFF (fast). This is self-distillation of tool use.

    python3 -m training.coordinator.make_sft_data --base-url http://localhost:8000/v1 \
        --out $WORK/sft/train.jsonl --samples 3 --paraphrases 4

Checks: every call parses and passes the tool schema; required tools for the intent were
called; no tool returned needs_input; the final answer is non-empty; numbers with 3+
significant characters in the answer appear in the prompt or an observed tool result.
"""

import argparse
import json
import re
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from copilot import agent, tools
from copilot.llm import OpenAIChat
from training.coordinator.tasks import build

NUM = re.compile(r"(?<![\w.])\d[\d,]*\.?\d*%?")


def unsupported_numbers(answer, evidence):
    bad = []
    flat = evidence.replace(",", "")
    for m in NUM.findall(answer):
        tok = m.rstrip("%").replace(",", "").rstrip(".")
        if len(tok.replace(".", "")) < 3 or re.fullmatch(r"(19|20)\d\d", tok):
            continue  # skip small numbers and years
        if tok not in flat:
            bad.append(m)
    return bad


def run_one(llm, item):
    events = []
    msgs = agent.run(llm, [{"role": "user", "content": item["prompt"]}], events.append)
    calls = [e for e in events if e["type"] == "tool_call"]
    results = [e for e in events if e["type"] == "tool_result"]
    final = next((e["text"] for e in reversed(events) if e["type"] == "message"), "")
    called = {c["name"] for c in calls}
    evidence = item["prompt"] + json.dumps([r["result"] for r in results], default=str)
    problems = []
    if any(not isinstance(c["arguments"], dict) for c in calls):
        problems.append("unparseable_arguments")
    if any(isinstance(r["result"], dict) and r["result"].get("status") == "needs_input" for r in results):
        problems.append("tool_needs_input")
    missing = set(item["required_tools"]) - called
    if missing:
        problems.append("missing_tools:" + ",".join(sorted(missing)))
    if not final.strip():
        problems.append("no_final_answer")
    bad = unsupported_numbers(final, evidence)
    if bad:
        problems.append("unsupported_numbers:" + ",".join(bad[:5]))
    return msgs, problems


def paraphrase(base_url, model, prompt, n):
    body = {"model": model, "temperature": 0.9, "max_tokens": 800, "chat_template_kwargs": {"enable_thinking": False},
            "messages": [{"role": "user", "content":
                          f"Rewrite this request from a cancer researcher in {n} different ways (different wording, same meaning and "
                          f"same technical details). Output a JSON list of strings only.\n\n{prompt}"}]}
    req = urllib.request.Request(base_url.rstrip("/") + "/chat/completions", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        text = json.loads(r.read())["choices"][0]["message"]["content"]
    try:
        out = json.loads(text[text.index("["): text.rindex("]") + 1])
        return [s for s in out if isinstance(s, str) and len(s) > 15][:n]
    except ValueError:
        return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--model", default="google/gemma-4-31B-it")
    ap.add_argument("--out", required=True)
    ap.add_argument("--samples", type=int, default=3, help="teacher samples per prompt")
    ap.add_argument("--paraphrases", type=int, default=4)
    ap.add_argument("--workers", type=int, default=16)
    a = ap.parse_args()

    train, _ = build()
    items = list(train)
    if a.paraphrases:
        with ThreadPoolExecutor(a.workers) as ex:
            for item, paras in zip(train, ex.map(lambda it: paraphrase(a.base_url, a.model, it["prompt"], a.paraphrases), train)):
                for k, p in enumerate(paras):
                    items.append({**item, "id": f"{item['id']}-p{k}", "prompt": p})
    print(f"{len(items)} training prompts", flush=True)
    teacher = OpenAIChat(a.base_url, a.model, thinking=True)
    jobs = [it for it in items for _ in range(a.samples)]
    accepted, rejected, seen = [], {}, set()
    with ThreadPoolExecutor(a.workers) as ex:
        for item, (msgs, problems) in zip(jobs, ex.map(lambda it: run_one(teacher, it), jobs)):
            if problems:
                for p in problems:
                    rejected[p.split(":")[0]] = rejected.get(p.split(":")[0], 0) + 1
                continue
            key = item["id"]
            if key in seen:
                continue  # keep one accepted trajectory per prompt
            seen.add(key)
            convo = [m for m in msgs if m["role"] != "system"]
            accepted.append({"messages": [{"role": "system", "content": agent.SYSTEM_PROMPT}] + convo,
                             "tools": tools.SCHEMAS, "source_refs": ["self-distilled; tools executed; auto-checked"],
                             "task_id": item["id"]})
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w") as f:
        for ex_ in accepted:
            f.write(json.dumps(ex_) + "\n")
    stats = {"prompts": len(items), "attempts": len(jobs), "accepted": len(accepted), "rejections": rejected}
    Path(a.out).with_suffix(".stats.json").write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
