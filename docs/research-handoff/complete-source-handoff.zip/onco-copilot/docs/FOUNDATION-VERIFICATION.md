# Verification record

The local foundation passed 46 automated tests using synthetic fixtures and temporary local files. The suite includes 14 BTXRD cohort-preparation tests covering metadata contradictions, missing grouping evidence, exact-digest linkage, deterministic partitions, inadequate groups, malformed joins, unsafe paths, and command-line behavior. Earlier command-line workflow checks cover routing, manifest audits, curriculum export, experiment planning, supervised feature-head training, teacher-guided feature-head training, and held-out synthetic evaluation.

The test command is:

```sh
python3 -m unittest discover -s tests -v
```

Coverage includes missing MRI sequences, endpoint mismatch, catalog-only access, installed-adapter result envelopes, patient and duplicate leakage, actual local file digests, paths escaping the allowed root, unresolved label evidence, separate teacher permissions, completed tool-call/result sequences, argument types and enumerations, teacher label order, teacher/sample alignment, nonfinite targets, and held-out sample/patient separation.

Classifier optimization during verification used only tiny synthetic feature vectors on the local CPU. No clinical data, downloaded pretrained weights, or NPS workloads were used. These checks establish behavior of the software building blocks; they do not establish cancer-detection accuracy, retained Gemma reasoning, medical label truth, or readiness for clinical use.

Optional identifying authoring metadata and generated Python bytecode caches were removed from the delivered project. Model/data references and source citations remain as required scientific and functional content.
