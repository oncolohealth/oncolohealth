# Source this inside every NPS workspace/job:  source nps/env.sh
# Edit WORK to the verified persistent mount (check with `df -h` inside a workspace).
export WORK="${WORK:-/workspace}"              # PVC mount, e.g. temp-1tb mounted at /workspace
export REPO="${REPO:-$WORK/onco-copilot}"
export DATA="${DATA:-$WORK/data}"
export HF_HOME="${HF_HOME:-$WORK/hf}"          # model cache on the PVC, never the container disk
export ONCO_RESULTS_DIR="${ONCO_RESULTS_DIR:-$REPO/results}"
export PYTHONPATH="$REPO:${PYTHONPATH:-}"
export GEMMA_MODEL="${GEMMA_MODEL:-google/gemma-4-31B-it}"
export MEDSIGLIP="${MEDSIGLIP:-google/medsiglip-448}"
mkdir -p "$DATA" "$HF_HOME" "$WORK/cache" "$WORK/ckpt" "$WORK/sft" "$WORK/models" "$ONCO_RESULTS_DIR"
cd "$REPO"
