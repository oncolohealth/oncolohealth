#!/usr/bin/env bash
# Run first inside a fresh workspace. Prints everything we still need to verify.
source "$(dirname "$0")/env.sh"
echo "== storage";        df -h "$WORK" | tail -1
echo "== gpus";           nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv 2>/dev/null || echo "no nvidia-smi"
echo "== arch";           uname -m
echo "== python";         python3 --version
for m in torch transformers peft accelerate vllm datasets sklearn PIL torchvision; do
  python3 - <<EOF 2>/dev/null || echo "$m: MISSING"
import importlib; mod = importlib.import_module("$m"); print("$m:", getattr(mod, "__version__", "ok"))
EOF
done
python3 -c "import torch; print('cuda:', torch.cuda.is_available(), torch.cuda.device_count(), 'bf16:', torch.cuda.is_bf16_supported() if torch.cuda.is_available() else None)" 2>/dev/null
echo "== network"
for u in https://huggingface.co https://api.figshare.com https://pypi.org/simple/ https://download.pytorch.org; do
  printf "%-36s " "$u"; curl -s -o /dev/null -w "%{http_code}\n" --max-time 10 "$u"
done
echo "== HF token set: $([ -n "$HF_TOKEN" ] && echo yes || echo NO — export HF_TOKEN for gated MedSigLIP)"
