"""SYNTHETIC provenance fixtures and mocked embeddings; no model or image load."""

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from cancer_workbench.adapters import encoder


class SyntheticVector:
    shape = (768,)

    def tolist(self):
        return [0.0] * 768


class EncoderProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.default = Path(self.temp.name) / "default"
        self.custom = Path(self.temp.name) / "custom"
        self.write(self.default, "rad-dino", "a" * 40)
        self.write(self.custom, "rad-dino", "b" * 40)
        self.patch = patch.object(encoder, "MODELS_DIR", self.default)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def write(self, root, model, revision):
        folder = root / model
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / "PROVENANCE.json"
        path.write_text(json.dumps({"source": {"revision": revision}}))
        return path

    def run_synthetic(self, root):
        adapter = encoder.FrozenEncoderAdapter("rad-dino", models_dir=root)
        with patch.object(adapter, "embed", return_value=[SyntheticVector()]):
            result = adapter.run({"image_path": "synthetic-unused.jpeg"})
        self.assertEqual(adapter.root, Path(root) / "rad-dino")
        self.assertEqual(result["type"], "embedding")
        self.assertEqual(result["dim"], 768)
        return result

    def test_default_revision_helper_remains_compatible(self):
        self.assertEqual(encoder.revision("rad-dino"), "a" * 40)

    def test_explicit_root_revision_uses_custom_folder(self):
        self.assertEqual(encoder.revision("rad-dino", models_dir=self.custom), "b" * 40)

    def test_string_root_revision_uses_custom_folder(self):
        self.assertEqual(encoder.revision("rad-dino", str(self.custom)), "b" * 40)

    def test_absent_custom_provenance_never_borrows_default(self):
        (self.custom / "rad-dino/PROVENANCE.json").unlink()
        self.assertIsNone(encoder.revision("rad-dino", self.custom))

    def test_malformed_custom_provenance_fails_without_fallback(self):
        (self.custom / "rad-dino/PROVENANCE.json").write_text("not json")
        with self.assertRaises(json.JSONDecodeError):
            encoder.revision("rad-dino", self.custom)

    def test_result_revision_matches_adapter_loading_root(self):
        self.assertEqual(self.run_synthetic(self.custom)["revision"], "b" * 40)

    def test_result_does_not_borrow_default_when_custom_provenance_missing(self):
        (self.custom / "rad-dino/PROVENANCE.json").unlink()
        self.assertIsNone(self.run_synthetic(self.custom)["revision"])

    def test_result_fails_on_malformed_custom_provenance(self):
        (self.custom / "rad-dino/PROVENANCE.json").write_text("not json")
        adapter = encoder.FrozenEncoderAdapter("rad-dino", models_dir=self.custom)
        with patch.object(adapter, "embed", return_value=[SyntheticVector()]) as embed:
            with self.assertRaises(json.JSONDecodeError):
                adapter.run({"image_path": "synthetic-unused.jpeg"})
            embed.assert_not_called()

    def test_revision_is_scoped_to_requested_encoder_subdirectory(self):
        self.write(self.custom, "resnet50-a1-in1k", "c" * 40)
        self.assertEqual(encoder.revision("rad-dino", self.custom), "b" * 40)
        self.assertEqual(encoder.revision("resnet50-a1-in1k", self.custom), "c" * 40)


if __name__ == "__main__":
    unittest.main()
