"""Shared helpers: read the split manifest, write predictions/metrics/model cards."""

import csv
import json
import time
from pathlib import Path

from copilot import evaluation

LABELS = ["normal", "benign", "malignant"]


def read_manifest(results_dir):
    with open(Path(results_dir) / "btxrd_manifest.csv", newline="") as f:
        return list(csv.DictReader(f))


def write_outputs(results_dir, model_id, partition, rows, extra_card=None):
    """rows: [{"sample_id", "label", "probabilities": [..3..]}]. Writes predictions + metrics."""
    out = Path(results_dir)
    out.mkdir(parents=True, exist_ok=True)
    pred = {"model_id": model_id, "dataset_id": "btxrd", "partition": partition, "label_names": LABELS, "rows": rows}
    (out / f"{model_id}.{partition}.predictions.json").write_text(json.dumps(pred))
    metrics = evaluation.evaluate(pred, positive="malignant", bootstrap=1000)
    (out / f"{model_id}.{partition}.metrics.json").write_text(json.dumps(metrics, indent=2))
    if partition == "external_test":
        card = {"model_id": model_id, "version": time.strftime("%Y%m%d-%H%M"),
                "metrics": {"external_test_balanced_accuracy": metrics["balanced_accuracy"],
                            "external_test_malignant_auc": metrics["per_class"]["malignant"]["auc_ovr"]},
                "scope": "Research baseline; source-held-out evaluation; not clinically validated"}
        card.update(extra_card or {})
        (out / f"{model_id}.card.json").write_text(json.dumps(card, indent=2))
    print(f"[{model_id}] {partition}: balanced_acc={metrics['balanced_accuracy']:.3f} "
          f"malignant_recall={metrics['per_class']['malignant']['recall']} "
          f"malignant_auc={metrics['per_class']['malignant']['auc_ovr']}", flush=True)
    return metrics
