"""Live research connectors. Standard library only; every call fails soft.

- Europe PMC: peer-reviewed literature and preprints (no API key)
- Hugging Face Hub: current open-weight models for a task
- NCI GDC: cancer genomics projects and case counts
"""

import json
import os
import time
import urllib.parse
import urllib.request

TIMEOUT = float(os.environ.get("ONCO_HTTP_TIMEOUT", "12"))
_CACHE = {}


def _get(url, ttl=900):
    hit = _CACHE.get(url)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    req = urllib.request.Request(url, headers={"User-Agent": "onco-copilot/0.1 (research tool)"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    _CACHE[url] = (time.time(), data)
    return data


def _soft(fn):
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:  # network, parse, timeout
            return {"error": "unavailable", "detail": type(exc).__name__ + ": " + str(exc)[:200],
                    "note": "Live source unreachable; answer from the local catalog and say so."}
    return wrapper


@_soft
def search_literature(query, max_results=8, since_year=None, reviews_only=False):
    q = query
    if since_year:
        q += f" AND PUB_YEAR:[{int(since_year)} TO 3000]"
    if reviews_only:
        q += ' AND PUB_TYPE:"review"'
    params = urllib.parse.urlencode({"query": q, "format": "json", "pageSize": max(1, min(int(max_results), 25)),
                                     "resultType": "core", "sort": "RELEVANCE"})
    data = _get("https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + params)
    out = []
    for r in data.get("resultList", {}).get("result", []):
        abstract = (r.get("abstractText") or "").replace("<h4>", " ").replace("</h4>", ": ")
        for tag in ("<i>", "</i>", "<b>", "</b>", "<sup>", "</sup>", "<sub>", "</sub>"):
            abstract = abstract.replace(tag, "")
        doi = r.get("doi")
        out.append({
            "title": r.get("title"),
            "authors": (r.get("authorString") or "")[:160],
            "journal": r.get("journalTitle") or r.get("bookOrReportDetails", {}).get("publisher"),
            "year": r.get("pubYear"),
            "doi": doi,
            "url": f"https://doi.org/{doi}" if doi else f"https://europepmc.org/article/{r.get('source')}/{r.get('id')}",
            "cited_by": r.get("citedByCount"),
            "is_preprint": r.get("source") == "PPR",
            "abstract": abstract[:900],
        })
    return {"query": query, "total_hits": data.get("hitCount"), "results": out, "source": "Europe PMC"}


@_soft
def search_hf_models(query, task=None, max_results=10, sort="downloads"):
    params = {"search": query, "limit": max(1, min(int(max_results), 30)), "sort": sort, "direction": -1, "full": "false"}
    if task:
        params["pipeline_tag"] = task
    data = _get("https://huggingface.co/api/models?" + urllib.parse.urlencode(params))
    out = []
    for m in data:
        out.append({"id": m.get("id") or m.get("modelId"), "task": m.get("pipeline_tag"),
                    "downloads": m.get("downloads"), "likes": m.get("likes"),
                    "updated": m.get("lastModified"), "gated": m.get("gated"),
                    "tags": [t for t in (m.get("tags") or []) if t.startswith(("license:", "base_model:"))][:4],
                    "url": "https://huggingface.co/" + str(m.get("id") or m.get("modelId"))})
    return {"query": query, "results": out, "source": "Hugging Face Hub",
            "note": "Popularity is not validation; check model cards for training data, license, and evaluation."}


@_soft
def search_gdc_projects(primary_site=None, max_results=15):
    params = {"size": max(1, min(int(max_results), 50)),
              "fields": "project_id,name,primary_site,disease_type,summary.case_count,summary.file_count",
              "sort": "summary.case_count:desc", "format": "json"}
    if primary_site:
        params["filters"] = json.dumps({"op": "in", "content": {"field": "primary_site", "value": [primary_site]}})
    data = _get("https://api.gdc.cancer.gov/projects?" + urllib.parse.urlencode(params))
    hits = data.get("data", {}).get("hits", [])
    return {"results": [{"project_id": h.get("project_id"), "name": h.get("name"),
                         "primary_site": h.get("primary_site"), "disease_type": h.get("disease_type"),
                         "cases": (h.get("summary") or {}).get("case_count"),
                         "files": (h.get("summary") or {}).get("file_count")} for h in hits],
            "source": "NCI Genomic Data Commons",
            "note": "Some files are controlled-access (dbGaP authorization required)."}
