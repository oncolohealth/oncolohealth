"""Command-line entry point. No remote execution or network access."""

import argparse
import csv
import json
import sys
from pathlib import Path

from .core import audit_dataset, export_curriculum, plan_experiment, route_models, PATHS
from .learning import train_feature_head, evaluate_head
from .cohorts import prepare_btxrd_cohort
from .release_audit import audit_btxrd_release, prepare_btxrd_evidence_template, EVIDENCE_COLUMNS
from .evidence import check_btxrd_evidence


def read_json(path):
    return json.loads(Path(path).read_text())


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("CSV requires unique column names")
        return list(reader)


def main():
    parser = argparse.ArgumentParser(description="Local cancer research foundation")
    sub = parser.add_subparsers(dest="command", required=True)
    route = sub.add_parser("route")
    route.add_argument("request")
    route.add_argument("registry")
    audit = sub.add_parser("audit")
    audit.add_argument("spec")
    audit.add_argument("rows")
    audit.add_argument("--files-root", help="Optionally hash files referenced relative to this directory")
    plan = sub.add_parser("plan")
    plan.add_argument("path", choices=PATHS)
    plan.add_argument("model")
    plan.add_argument("--audit")
    plan.add_argument("--budget")
    curriculum = sub.add_parser("curriculum")
    curriculum.add_argument("traces")
    train = sub.add_parser("train-head", help="Explicit local CPU optimization on supplied feature vectors")
    train.add_argument("data")
    train.add_argument("--teacher-weight", type=float, default=0.0)
    train.add_argument("--epochs", type=int, default=100)
    evaluate = sub.add_parser("evaluate-head")
    evaluate.add_argument("model")
    evaluate.add_argument("data")
    cohort = sub.add_parser("btxrd-prepare", help="Inspect local metadata and draft grouped partitions; never downloads or trains")
    cohort.add_argument("metadata")
    cohort.add_argument("--case-map", help="Local CSV of declared patient groups, evidence references, and digests")
    cohort.add_argument("--seed", type=int, default=17)
    release = sub.add_parser("btxrd-audit", help="Read a local release ZIP; never downloads, extracts or trains")
    release.add_argument("archive")
    release.add_argument("--expected-md5", help="Reference digest from the selected release record")
    release.add_argument("--train-list", help="Optional local CSV/XLSX image_id list")
    release.add_argument("--validation-list", help="Paired local CSV/XLSX image_id list")
    release.add_argument("--inspect-exif", action="store_true", help="Count tag presence only; optional Pillow")
    evidence = sub.add_parser("btxrd-evidence-template", help="Local CSV with measured hashes and blank patient/reference evidence")
    evidence.add_argument("archive")
    evidence.add_argument("--expected-md5", help="Reference digest from the selected release record")
    evidence_check = sub.add_parser("btxrd-evidence-check", help="Check a returned CSV against source bytes; never certifies a medical cohort")
    evidence_check.add_argument("archive")
    evidence_check.add_argument("evidence")
    evidence_check.add_argument("--expected-md5", help="Reference digest from the selected release record")
    args = parser.parse_args()
    try:
        if args.command == "route":
            result = route_models(read_json(args.request), read_json(args.registry))
        elif args.command == "audit":
            result = audit_dataset(read_json(args.spec), read_csv(args.rows), args.files_root)
        elif args.command == "plan":
            result = plan_experiment(args.path, read_json(args.model),
                                     read_json(args.audit) if args.audit else None,
                                     read_json(args.budget) if args.budget else None)
        elif args.command == "curriculum":
            result = export_curriculum(read_json(args.traces))
        elif args.command == "train-head":
            result = train_feature_head(read_json(args.data), epochs=args.epochs, teacher_weight=args.teacher_weight)
        elif args.command == "btxrd-prepare":
            result = prepare_btxrd_cohort(read_csv(args.metadata),
                                         read_csv(args.case_map) if args.case_map else None, seed=args.seed)
        elif args.command == "btxrd-audit":
            result = audit_btxrd_release(args.archive, expected_md5=args.expected_md5,
                                         train_list=args.train_list, validation_list=args.validation_list,
                                         inspect_exif=args.inspect_exif)
        elif args.command == "btxrd-evidence-template":
            result = prepare_btxrd_evidence_template(args.archive, expected_md5=args.expected_md5)
        elif args.command == "btxrd-evidence-check":
            result = check_btxrd_evidence(args.archive, read_csv(args.evidence), expected_md5=args.expected_md5)
        else:
            result = evaluate_head(read_json(args.model), read_json(args.data))
    except (ValueError, TypeError, KeyError, OSError) as error:
        parser.exit(2, "Input rejected: " + str(error) + "\n")
    if args.command == "btxrd-evidence-template":
        writer = csv.DictWriter(sys.stdout, fieldnames=EVIDENCE_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(result)
    else:
        print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
