import copy
import unittest
import tempfile
import hashlib
from pathlib import Path

from cancer_workbench.core import audit_dataset, execute_specialist, export_curriculum, plan_experiment, route_models
from cancer_workbench.learning import evaluate_head, predict, train_feature_head


def model_fixture():
    return {"id": "fixture-mri", "version": "fixture-only", "tasks": ["tumor_segmentation"],
            "modalities": ["MRI"], "anatomies": ["brain"],
            "required_channels": ["T1", "T1c", "T2", "FLAIR"],
            "state": "locally_reproduced", "adapter_id": "synthetic_fixture",
            "permissions": {"inference": "allowed", "adaptation": "allowed", "distillation": "allowed"},
            "teacher_evaluation": "synthetic-test-reference"}


def request_fixture():
    return {"task": "tumor_segmentation", "modality": "MRI", "anatomy": "brain",
            "channels": ["T1", "T1c", "T2", "FLAIR"]}


def spec_fixture():
    return {"id": "synthetic", "version": "fixture", "source_url": "https://example.org/fixture",
            "task": "tumor_segmentation", "modality": "MRI", "anatomy": "brain",
            "label_definitions": {"negative": "fixture negative", "positive": "fixture positive"},
            "reference_standard": "synthetic test fixture, not medical evidence", "labels_reviewed": True,
            "file_hashes_verified": True, "permissions": {"training": "allowed"}}


def rows_fixture():
    return [{"sample_id": str(i), "patient_id": "group" + str(i), "split": split, "label": label,
             "sha256": format(i + 1, "064x")}
            for i, (split, label) in enumerate((s, l) for s in ("train", "validation", "test") for l in ("negative", "positive"))]


def trace_fixture():
    return {"reviewed": True, "observed_tool_results": True, "source_refs": ["synthetic fixture"],
            "tools": [{"type": "function", "function": {"name": "registry_lookup", "parameters": {
                "type": "object", "properties": {"modality": {"type": "string", "enum": ["MRI", "CT"]}},
                "required": ["modality"], "additionalProperties": False}}}],
            "messages": [{"role": "user", "content": "Find an MRI specialist"},
                         {"role": "assistant", "tool_calls": [{"id": "call1", "type": "function", "function": {
                             "name": "registry_lookup", "arguments": '{"modality":"MRI"}'}}]},
                         {"role": "tool", "tool_call_id": "call1", "content": '{"matches":[]}'},
                         {"role": "assistant", "content": "No eligible specialist was found."}]}


def features_fixture():
    return {"label_names": ["negative", "positive"], "encoder_reference": "synthetic-encoder",
            "dataset_reference": "synthetic-training-vectors", "teacher_reference": "synthetic-teacher",
            "teacher_label_names": ["negative", "positive"],
            "permissions": {"training": "allowed", "distillation": "allowed"},
            "rows": [{"sample_id": str(i), "teacher_sample_id": str(i), "patient_id": "train" + str(i),
                      "split": "train", "features": [x], "label": label, "teacher_probabilities": probs}
                     for i, (x, label, probs) in enumerate([(-2., "negative", [.9, .1]), (-1., "negative", [.8, .2]),
                                                          (1., "positive", [.2, .8]), (2., "positive", [.1, .9])])]}


class RoutingTests(unittest.TestCase):
    def test_requires_metadata(self):
        with self.assertRaises(ValueError): route_models({}, [model_fixture()])

    def test_requires_complete_mri_sequences(self):
        request = request_fixture(); request["channels"].remove("T1c")
        result = route_models(request, [model_fixture()])
        self.assertEqual(result["decision"], "abstain_no_compatible_model")

    def test_rejects_different_endpoint(self):
        request = request_fixture(); request["task"] = "malignancy_classification"
        self.assertFalse(route_models(request, [model_fixture()])["compatible"])

    def test_catalog_does_not_imply_runnable(self):
        model = model_fixture(); model["state"] = "cataloged"
        self.assertFalse(route_models(request_fixture(), [model])["compatible"][0]["runnable"])
        with self.assertRaises(ValueError): execute_specialist(model, request_fixture(), {})

    def test_installed_adapter_observed_result(self):
        result = execute_specialist(model_fixture(), request_fixture(), {
            "synthetic_fixture": lambda r: {"task": r["task"], "outputs": {"fixture": True}}})
        self.assertTrue(result["observed"])
        self.assertEqual(result["model_version"], "fixture-only")

    def test_adapter_cannot_return_another_task(self):
        with self.assertRaises(ValueError):
            execute_specialist(model_fixture(), request_fixture(), {
                "synthetic_fixture": lambda r: {"task": "different", "outputs": {}}})


class AuditTests(unittest.TestCase):
    def test_never_certifies_truth(self):
        report = audit_dataset(spec_fixture(), rows_fixture())
        self.assertEqual(report["status"], "declared_checks_passed")
        self.assertFalse(report["truth_certified"])

    def test_patient_leakage(self):
        rows = rows_fixture(); rows[2]["patient_id"] = rows[0]["patient_id"]
        self.assertIn("patient_leakage", [f["code"] for f in audit_dataset(spec_fixture(), rows)["findings"]])

    def test_duplicate_leakage(self):
        rows = rows_fixture(); rows[4]["sha256"] = rows[0]["sha256"]
        self.assertEqual(audit_dataset(spec_fixture(), rows)["status"], "blocked")

    def test_unknown_group_blocks(self):
        rows = rows_fixture(); rows[0]["patient_id"] = ""
        self.assertEqual(audit_dataset(spec_fixture(), rows)["status"], "blocked")

    def test_labels_and_file_checks_are_not_inferred(self):
        spec = spec_fixture(); spec.pop("labels_reviewed"); spec.pop("file_hashes_verified")
        self.assertEqual(audit_dataset(spec, rows_fixture())["status"], "blocked")

    def test_unreviewed_rights_block(self):
        spec = spec_fixture(); spec["permissions"] = {}
        self.assertEqual(audit_dataset(spec, rows_fixture())["status"], "blocked")

    def test_local_file_digests_measured(self):
        with tempfile.TemporaryDirectory() as folder:
            rows = rows_fixture()
            for i, row in enumerate(rows):
                content = str(i).encode()
                row["file_path"] = str(i) + ".bin"
                Path(folder, row["file_path"]).write_bytes(content)
                row["sha256"] = hashlib.sha256(content).hexdigest()
            spec = spec_fixture(); spec["file_hashes_verified"] = False
            self.assertEqual(audit_dataset(spec, rows, folder)["file_integrity"], "measured_pass")
            rows[0]["sha256"] = "0" * 64
            self.assertEqual(audit_dataset(spec, rows, folder)["status"], "blocked")

    def test_file_paths_cannot_escape_root(self):
        with tempfile.TemporaryDirectory() as folder:
            rows = rows_fixture(); rows[0]["file_path"] = "../outside.bin"
            report = audit_dataset(spec_fixture(), rows, folder)
            self.assertIn("unsafe_file_reference", [x["code"] for x in report["findings"]])


class PlanningTests(unittest.TestCase):
    def test_distillation_rights_not_implied_by_inference(self):
        model = model_fixture(); model["permissions"]["distillation"] = "unknown"
        self.assertEqual(plan_experiment("distillation", model)["status"], "blocked")

    def test_all_three_paths_remain_unsubmitted(self):
        audit = audit_dataset(spec_fixture(), rows_fixture())
        for path in ("specialist_tools", "transfer_learning", "distillation"):
            plan = plan_experiment(path, model_fixture(), audit,
                                   {"gpu_count": 0, "max_hours": 1, "max_storage_gb": 1, "profile_reference": "synthetic"})
            self.assertEqual(plan["status"], "draft_ready_for_review")
            self.assertFalse(plan["submitted"])

    def test_nan_budget_rejected(self):
        result = plan_experiment("specialist_tools", model_fixture(), budget={"max_hours": float("nan")})
        self.assertEqual(result["status"], "blocked")

    def test_incompatible_training_modality(self):
        audit = audit_dataset(spec_fixture(), rows_fixture()); audit["modality"] = "CT"
        self.assertEqual(plan_experiment("transfer_learning", model_fixture(), audit)["status"], "blocked")


class CurriculumTests(unittest.TestCase):
    def test_export_preserves_observed_conversation(self):
        trace = trace_fixture(); out = export_curriculum([trace])
        self.assertEqual(out[0]["messages"], trace["messages"])

    def test_unreviewed_trace_rejected(self):
        trace = trace_fixture(); trace["reviewed"] = False
        with self.assertRaises(ValueError): export_curriculum([trace])

    def test_missing_result_rejected(self):
        trace = trace_fixture(); trace["messages"].pop(2)
        with self.assertRaises(ValueError): export_curriculum([trace])

    def test_invalid_argument_enum(self):
        trace = trace_fixture(); trace["messages"][1]["tool_calls"][0]["function"]["arguments"] = '{"modality":"X-ray"}'
        with self.assertRaises(ValueError): export_curriculum([trace])

    def test_argument_type_checked(self):
        trace = trace_fixture(); trace["messages"][1]["tool_calls"][0]["function"]["arguments"] = '{"modality":12}'
        with self.assertRaises(ValueError): export_curriculum([trace])


class LearningTests(unittest.TestCase):
    def test_supervised_head_on_synthetic_vectors(self):
        model = train_feature_head(features_fixture(), epochs=30)
        self.assertGreater(predict(model, [2.])[1], .8)
        self.assertGreater(predict(model, [-2.])[0], .8)

    def test_distillation_path_on_synthetic_vectors(self):
        model = train_feature_head(features_fixture(), epochs=30, teacher_weight=.5)
        self.assertEqual(model["method"], "distillation")
        self.assertGreater(predict(model, [2.])[1], .7)

    def test_teacher_label_order_must_match(self):
        data = features_fixture(); data["teacher_label_names"].reverse()
        with self.assertRaises(ValueError): train_feature_head(data, teacher_weight=.5)

    def test_teacher_target_must_be_same_sample(self):
        data = features_fixture(); data["rows"][0]["teacher_sample_id"] = "another"
        with self.assertRaises(ValueError): train_feature_head(data, teacher_weight=.5)

    def test_held_out_rows_cannot_train(self):
        data = features_fixture(); data["rows"][0]["split"] = "test"
        with self.assertRaises(ValueError): train_feature_head(data)

    def test_teacher_permissions_required(self):
        data = features_fixture(); data["permissions"].pop("distillation")
        with self.assertRaises(ValueError): train_feature_head(data, teacher_weight=.5)

    def test_teacher_nan_rejected(self):
        data = features_fixture(); data["rows"][0]["teacher_probabilities"] = [float("nan"), .5]
        with self.assertRaises(ValueError): train_feature_head(data, teacher_weight=.5)

    def test_evaluation_rejects_training_patient_overlap(self):
        data = features_fixture(); model = train_feature_head(data, epochs=1)
        data["rows"][0]["split"] = "test"
        with self.assertRaises(ValueError): evaluate_head(model, {**data, "rows": data["rows"][:1]})

    def test_evaluation_reports_held_out_results(self):
        data = features_fixture(); model = train_feature_head(data, epochs=30)
        heldout = {**data, "rows": [{"sample_id": "heldout", "patient_id": "independent", "split": "test",
                                     "features": [1.5], "label": "positive"}]}
        report = evaluate_head(model, heldout)
        self.assertEqual(report["per_class_recall"]["positive"], 1.)
        self.assertIsNone(report["per_class_recall"]["negative"])
        self.assertFalse(report["clinical_accuracy_established"])


if __name__ == "__main__":
    unittest.main()
