"""Paired comparison of the two baselines on the identical external test images.

    python3 -m training.btxrd.compare --results results
"""

import argparse
import json
from pathlib import Path

from copilot import evaluation


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--a", default="btxrd-medsiglip-head.external_test.predictions.json")
    ap.add_argument("--b", default="btxrd-cnn-baseline.external_test.predictions.json")
    a = ap.parse_args()
    r = Path(a.results)
    res = evaluation.compare(json.loads((r / a.a).read_text()), json.loads((r / a.b).read_text()), positive="malignant", bootstrap=2000)
    (r / "comparison.json").write_text(json.dumps(res, indent=2))
    print(res["verdict"], "| delta", round(res["balanced_accuracy_delta"], 4), "CI", res["delta_ci95"], "| McNemar p", res["mcnemar"]["p_value"])


if __name__ == "__main__":
    main()
