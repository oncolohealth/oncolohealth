"""Build an exploratory BTXRD source-held-out split with duplicate-leakage checks.

    python3 -m training.btxrd.prepare --root $DATA/BTXRD --out results

Strategy (BTXRD publishes no patient ids):
- external_test = centers 2+3 (Radiopaedia, MedPix): a different source than training
- train / validation = center 1 (three hospitals), stratified by class
- exact duplicates (SHA-256) are grouped; contradictory labels and cross-source
  exact duplicates are excluded from every partition.
- similar-looking images (64-bit dHash, Hamming <= 4, needs Pillow) are exported
  as candidates for review, never assumed to be the same patient or lesion.
Outputs: results/btxrd_manifest.csv, results/btxrd_split.json, and
results/btxrd_near_duplicate_candidates.csv
No patient identifiers are published, so the output is never marked training-ready.
"""

import argparse
import csv
import hashlib
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

from .metadata import read_metadata

LABELS = ["normal", "benign", "malignant"]


def _col(fieldnames, name):
    for f in fieldnames:
        if f.strip().lower() == name:
            return f
    raise SystemExit(f"BTXRD metadata has no '{name}' column; found: {fieldnames[:12]}...")


def _flag(v):
    return str(v).strip() in ("1", "1.0", "True", "true")


def _sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _dhash(p):
    try:
        from PIL import Image
    except ImportError:
        return None
    try:
        with Image.open(p) as im:
            g = im.convert("L").resize((9, 8))
            px = list(g.get_flattened_data()) if hasattr(g, "get_flattened_data") else list(g.getdata())
    except Exception:
        return "unreadable"
    bits = 0
    for r in range(8):
        for c in range(8):
            bits = (bits << 1) | (px[r * 9 + c] > px[r * 9 + c + 1])
    return bits


def find_images(root):
    imgs = {}
    for p in Path(root).rglob("*"):
        if p.suffix.lower() in (".jpg", ".jpeg") and p.is_file():
            if p.name in imgs:
                raise ValueError(f"Ambiguous BTXRD image name {p.name!r}: {imgs[p.name]} and {p}")
            imgs[p.name] = p
    return imgs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="Unzipped BTXRD folder (dataset.xlsx or dataset.csv plus images)")
    ap.add_argument("--out", default="results")
    ap.add_argument("--val-fraction", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--near-dup-hamming", type=int, default=4)
    a = ap.parse_args()

    root = Path(a.root)
    try:
        fields, rows, meta = read_metadata(root)
    except (ValueError, OSError) as exc:
        raise SystemExit(str(exc)) from exc
    c_id, c_center = _col(fields, "image_id"), _col(fields, "center")
    c_tumor, c_ben, c_mal = _col(fields, "tumor"), _col(fields, "benign"), _col(fields, "malignant")
    try:
        imgs = find_images(root)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc

    records, problems, seen_names = [], Counter(), set()
    for r in rows:
        name = r[c_id].strip()
        if not name.lower().endswith((".jpg", ".jpeg")):
            name += ".jpeg"
        if name in seen_names:
            raise SystemExit(f"BTXRD metadata repeats image_id {name!r}")
        seen_names.add(name)
        center = str(r[c_center]).strip().split(".")[0]
        if center not in {"1", "2", "3"}:
            raise SystemExit(f"BTXRD image {name!r} has unknown center {center!r}")
        tumor, ben, mal = _flag(r[c_tumor]), _flag(r[c_ben]), _flag(r[c_mal])
        if not tumor and not ben and not mal:
            label = "normal"
        elif tumor and ben and not mal:
            label = "benign"
        elif tumor and mal and not ben:
            label = "malignant"
        else:
            problems["conflicting_flags"] += 1
            continue
        p = imgs.get(name)
        if not p:
            problems["missing_image"] += 1
            continue
        records.append({"image_id": name, "path": str(p.relative_to(root)), "label": label,
                        "center": center})

    print(f"{len(records)} usable images; hashing…", flush=True)
    kept = []
    for rec in records:
        p = root / rec["path"]
        rec["sha256"] = _sha256(p)
        kept.append(rec)
    records = kept

    by_sha = defaultdict(list)
    for rec in records:
        by_sha[rec["sha256"]].append(rec)
    exact_pairs = sum(len(group) * (len(group) - 1) // 2 for group in by_sha.values())
    conflicts = {sha for sha, group in by_sha.items() if len({r["label"] for r in group}) > 1}
    cross_source_exact = {sha for sha, group in by_sha.items()
                          if "1" in {r["center"] for r in group}
                          and len({r["center"] for r in group}) > 1}
    problems["conflicting_exact_label"] = sum(len(by_sha[sha]) for sha in conflicts)
    problems["cross_source_exact_duplicate"] = sum(len(by_sha[sha]) for sha in cross_source_exact - conflicts)
    records = [r for r in records if r["sha256"] not in conflicts | cross_source_exact]
    kept = []
    for rec in records:
        rec["_dh"] = _dhash(root / rec["path"])
        if rec["_dh"] == "unreadable":
            problems["unreadable_image"] += 1
            continue
        kept.append(rec)
    records = kept

    # Only exact duplicates establish a family. dHash is too coarse to identify
    # patients; transitive chaining of visual matches can create huge false groups.
    parent = list(range(len(records)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        parent[find(i)] = find(j)

    by_sha = defaultdict(list)
    for i, rec in enumerate(records):
        by_sha[rec["sha256"]].append(i)
    for ids in by_sha.values():
        for j in ids[1:]:
            union(ids[0], j)
    candidates = []
    hashes = [(i, r["_dh"]) for i, r in enumerate(records) if r["_dh"] is not None]
    if hashes:
        for x in range(len(hashes)):
            i, hi = hashes[x]
            for y in range(x + 1, len(hashes)):
                j, hj = hashes[y]
                distance = (hi ^ hj).bit_count()
                if distance <= a.near_dup_hamming and records[i]["sha256"] != records[j]["sha256"]:
                    candidates.append((records[i]["image_id"], records[j]["image_id"], distance,
                                       records[i]["center"], records[j]["center"]))
    groups = defaultdict(list)
    for i in range(len(records)):
        groups[find(i)].append(i)

    # Exact duplicate groups were checked for conflicting labels and source overlap.
    rng = random.Random(a.seed)
    dev_groups, test_groups = [], []
    for g in groups.values():
        centers = {records[i]["center"] for i in g}
        if centers == {"1"}:
            dev_groups.append(g)
        else:
            test_groups.append(g)
    # stratified validation draw over dev groups by majority label
    by_label = defaultdict(list)
    for g in dev_groups:
        by_label[Counter(records[i]["label"] for i in g).most_common(1)[0][0]].append(g)
    for lab, gs in by_label.items():
        rng.shuffle(gs)
        target = round(a.val_fraction * sum(len(g) for g in gs))
        taken = 0
        for g in gs:
            split = "validation" if taken < target else "train"
            taken += len(g) if split == "validation" else 0
            for i in g:
                records[i]["split"] = split
    for g in test_groups:
        for i in g:
            records[i]["split"] = "external_test"
    for g in groups.values():
        gid = "g" + hashlib.sha256(",".join(sorted(records[i]["image_id"] for i in g)).encode()).hexdigest()[:10]
        for i in g:
            records[i]["group"] = gid

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "btxrd_manifest.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["image_id", "path", "label", "center", "split", "group", "sha256"])
        w.writeheader()
        for rec in records:
            w.writerow({k: rec[k] for k in w.fieldnames})
    with open(out / "btxrd_near_duplicate_candidates.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["image_id_a", "image_id_b", "dhash_hamming", "center_a", "center_b"])
        w.writerows(candidates)
    counts = defaultdict(Counter)
    for rec in records:
        counts[rec["split"]][rec["label"]] += 1
    warnings = ["No patient identifiers are published; train/validation are separated by duplicate family, not by patient.",
                "External test is a different source (Radiopaedia + MedPix); its case mix differs from the hospitals."]
    if problems["conflicting_exact_label"]:
        warnings.append("Exact duplicate images with conflicting labels were excluded from every partition.")
    if problems["cross_source_exact_duplicate"]:
        warnings.append("Exact duplicate images spanning development and external sources were excluded from every partition.")
    if candidates:
        warnings.append("dHash matches are unverified candidates, not patient groups; cross-partition visual matches require manual review before evaluation.")
    if hashes == []:
        warnings.append("Pillow unavailable: near-duplicate check skipped (exact duplicates only).")
    split = {"dataset_id": "btxrd", "release": "10.6084/m9.figshare.27865398.v1", "modality": "X-ray", "anatomy": "bone",
             "metadata_file": str(meta.relative_to(root)), "label_names": LABELS,
             "status": "exploratory_only", "ready_for_training": False,
             "patient_grouping": "unavailable", "reference_standard": "unverified",
             "strategy": "Source-held-out: train/validation from center 1 (hospitals); external test from centers 2+3",
             "counts": {k: dict(v) for k, v in counts.items()}, "excluded": dict(problems),
             "duplicates": {"exact_pairs_in_release": exact_pairs, "near_candidate_pairs": len(candidates),
                            "exact_families_kept": sum(len(g) > 1 for g in groups.values())},
             "warnings": warnings, "seed": a.seed}
    (out / "btxrd_split.json").write_text(json.dumps(split, indent=2))
    print(json.dumps(split, indent=2))


if __name__ == "__main__":
    main()
