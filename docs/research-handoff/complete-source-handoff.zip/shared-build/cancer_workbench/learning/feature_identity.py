"""Read-only image-byte binding for local feature caches; no model execution."""

import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath


SCHEMA = "sample-image-sha256-v1"


def _digest(value):
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdefABCDEF" for c in value):
        raise ValueError("Image SHA-256 must contain 64 hexadecimal characters")
    return value.lower()


def _ids(values):
    if isinstance(values, (str, bytes)):
        raise ValueError("Sample IDs must be a sequence")
    try:
        ids = list(values)
    except TypeError:
        raise ValueError("Sample IDs must be a sequence") from None
    if not ids or any(not isinstance(v, str) or not v or v != v.strip() or "\x00" in v for v in ids):
        raise ValueError("Sample IDs must be nonempty strings without surrounding whitespace")
    if len(set(ids)) != len(ids):
        raise ValueError("Sample IDs must be unique")
    return ids


def binding_digest(records):
    """Canonical mapping digest, independent of row order and label/group edits."""
    encoded = json.dumps(sorted(records, key=lambda r: r["sample_id"]), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode()).hexdigest()


def measure_inputs(rows, data_root):
    """Measure contained files and check any declared hashes. Do not decode pixels.

    Missing declared hashes do not establish curated source provenance; the
    measured hashes still bind a future cache to the bytes present here.
    """
    rows = list(rows)
    if any(not isinstance(r, dict) for r in rows):
        raise ValueError("Manifest rows must be mappings")
    ids = _ids([r.get("sample_id") for r in rows])
    try:
        root = Path(data_root).resolve(strict=True)
    except OSError:
        raise ValueError("Image root is unavailable") from None
    if not root.is_dir():
        raise ValueError("Image root must be a directory")
    records = []
    for sid, row in zip(ids, rows):
        name = row.get("file")
        if (not isinstance(name, str) or not name or "\x00" in name or "\\" in name
                or PurePosixPath(name).is_absolute() or PureWindowsPath(name).drive
                or ".." in PurePosixPath(name).parts):
            raise ValueError("Image file must be a contained relative path")
        declared = row.get("sha256")
        if declared is not None and declared != "":
            declared = _digest(declared)
        try:
            image = (root / name).resolve(strict=True)
            if not image.is_relative_to(root) or not image.is_file():
                raise ValueError("Image file must stay inside the image root")
            measured = hashlib.sha256()
            with image.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    measured.update(chunk)
        except OSError:
            raise ValueError("Source image is unavailable or unreadable") from None
        actual = measured.hexdigest()
        if declared and declared != actual:
            raise ValueError("Source image bytes differ from the declared hash")
        records.append({"sample_id": sid, "sha256": actual})
    return records


def validate_cached_inputs(cache, rows, data_root):
    """Reject legacy, inconsistent or changed inputs before a cache is consumed.

    This detects persistent input changes. It is not an authenticated cache,
    a filesystem lock, a model-artifact verifier or a scientific eligibility gate.
    """
    required = {"sample_ids", "image_sha256", "input_content_sha256", "input_binding_schema", "features"}
    if (not required <= cache.keys() or not isinstance(cache["input_binding_schema"], str)
            or cache["input_binding_schema"] != SCHEMA):
        raise ValueError("Feature cache lacks supported image binding; explicit recomputation is required")
    ids = _ids(cache["sample_ids"])
    values = cache["image_sha256"]
    if isinstance(values, (str, bytes)):
        raise ValueError("Cached image hashes must be a sequence")
    try:
        hashes = [_digest(v) for v in values]
    except TypeError:
        raise ValueError("Cached image hashes must be a sequence") from None
    if len(ids) != len(hashes):
        raise ValueError("Cached sample/hash rows are misaligned")
    shape = getattr(cache["features"], "shape", ())
    if len(shape) != 2 or shape[0] != len(ids) or shape[1] < 1:
        raise ValueError("Cached feature rows must align with sample IDs")
    cached = [{"sample_id": sid, "sha256": sha} for sid, sha in zip(ids, hashes)]
    if _digest(cache["input_content_sha256"]) != binding_digest(cached):
        raise ValueError("Cached input mapping digest is inconsistent")
    current = measure_inputs(rows, data_root)
    if binding_digest(current) != binding_digest(cached):
        raise ValueError("Feature cache does not match the current image IDs and bytes")
