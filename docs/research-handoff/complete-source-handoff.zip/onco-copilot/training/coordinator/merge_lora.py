"""Merge the LoRA adapter into full BF16 weights so vLLM serves it like the base model.

    python3 -m training.coordinator.merge_lora --base $HF_HOME/gemma-4-31B-it \
        --adapter $WORK/ckpt/onco-lora/adapter --out $WORK/models/onco-gemma-4-31b-it

Copies the base model's processor/tokenizer files so the vision path and chat template survive.
"""

import argparse
import shutil
from pathlib import Path

import torch
from peft import PeftModel

from training.coordinator.train_lora import load_model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--adapter", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    model = load_model(a.base)
    model = PeftModel.from_pretrained(model, a.adapter).merge_and_unload()
    model.save_pretrained(a.out, safe_serialization=True, max_shard_size="5GB")
    for f in Path(a.base).iterdir():
        if f.suffix in (".json", ".jinja", ".txt", ".model") and not f.name.startswith(("model", "config")) or f.name in (
                "tokenizer.json", "tokenizer_config.json", "preprocessor_config.json", "chat_template.jinja",
                "generation_config.json", "video_preprocessor_config.json"):
            if not (Path(a.out) / f.name).exists():
                shutil.copy(f, a.out)
    print("merged model at", a.out)


if __name__ == "__main__":
    main()
