"""Researcher task bank with gold tool expectations.

Held-out split is by anatomy AND phrasing template, so evaluation measures
generalization to unseen combinations, not memorized prompts.
"""

import itertools
import random

SETTINGS = [
    ("X-ray", "bone", "bone tumor radiographs", ["normal", "benign", "malignant"]),
    ("CT", "lung", "lung nodule CT", ["benign nodule", "malignant nodule"]),
    ("MRI", "brain", "brain tumor MRI", ["glioma", "meningioma", "no tumor"]),
    ("pathology", "prostate", "prostate biopsy slides", ["ISUP 0-1", "ISUP 2-3", "ISUP 4-5"]),
    ("pathology", "breast", "breast lymph-node slides", ["metastasis", "no metastasis"]),
    ("MRI", "prostate", "prostate MRI", ["clinically significant cancer", "not significant"]),
    ("X-ray", "chest", "chest radiographs", ["lung cancer", "no cancer"]),
    ("CT", "liver", "liver CT", ["hepatocellular carcinoma", "benign lesion"]),
    ("dermatology", "skin", "dermoscopy images", ["melanoma", "nevus"]),
    ("genomics", "multiple", "tumor RNA-seq", ["subtype A", "subtype B"]),
]
HELDOUT_ANATOMY = {"liver", "skin"}

INTENTS = [
    # (intent id, templates, gold required tools, gold optional tools)
    ("literature", ["What methods work best right now for {desc} classification? Cite recent papers.",
                    "Summarize the last few years of deep learning research on {desc}, with citations.",
                    "I need related work for a paper on {desc}. Find the key studies."],
     {"search_literature"}, set()),
    ("model_pick", ["What's the best current open model to start a {task} model on {desc}?",
                    "Recommend a local backbone for {desc} {task}, and tell me what to check on its model card.",
                    "Which pretrained model should I fine-tune for {desc}?"],
     {"find_models"}, {"search_literature"}),
    ("data_find", ["What existing datasets can I use for {desc}? Flag leakage risks.",
                   "Find public data for {desc} {task} and tell me the license terms.",
                   "Where can I get labeled {desc}?"],
     {"find_datasets"}, {"search_literature"}),
    ("data_spec", ["I'm collecting new {desc} for {task} with classes {classes}. What must the dataset contain and how big must my test set be?",
                   "Write the data specification for a {desc} {task} study, including minimum test-set size.",
                   "How many patients do I need to validate a {desc} model with sensitivity around 0.85?"],
     {"specify_dataset"}, {"find_datasets"}),
    ("audit_plan", ["Audit the BTXRD dataset and draft a training plan for the MedSigLIP head on 1 GPU.",
                    "Is BTXRD ready for training? If so, plan the transfer-learning run.",
                    "Check BTXRD for leakage, then plan training of btxrd-medsiglip-head."],
     {"audit_dataset", "plan_training"}, set()),
    ("compare", ["Compare our MedSigLIP head with the CNN baseline on the external test set. Is the difference significant?",
                 "Which bone model is better on external data, and how confident are we?",
                 "Evaluate both BTXRD baselines and tell me if one beats the other."],
     {"list_results", "compare_models"}, {"evaluate_model"}),
    ("full_project", ["I want to build a new {desc} model end to end: literature, best starting model, data, and an evaluation plan.",
                      "Plan a {desc} {task} project from scratch using local models.",
                      "Help me start a research project on {desc}: what's been done, what model, what data?"],
     {"search_literature", "find_models", "find_datasets"}, {"specify_dataset"}),
]
TEMPLATE_HELDOUT_INDEX = 2  # third phrasing of every intent is held out


def build(seed=0):
    rng = random.Random(seed)
    train, held = [], []
    for (intent, templates, req, opt), (mod, anat, desc, classes) in itertools.product(INTENTS, SETTINGS):
        if intent in ("audit_plan", "compare") and anat != "bone":
            continue
        for ti, t in enumerate(templates):
            task = "segmentation" if (mod == "MRI" and anat == "brain" and ti == 1) else "classification"
            prompt = t.format(desc=desc, task=task, classes=", ".join(classes))
            item = {"id": f"{intent}-{anat}-{mod}-{ti}", "intent": intent, "prompt": prompt,
                    "modality": mod, "anatomy": anat, "required_tools": sorted(req), "optional_tools": sorted(opt)}
            if anat in HELDOUT_ANATOMY or ti == TEMPLATE_HELDOUT_INDEX:
                held.append(item)
            else:
                train.append(item)
    rng.shuffle(train)
    return train, held
