"""Tests for the contract, evaluation, tools, agent loop, and BTXRD prep. Synthetic data only."""

import csv
import io
import json
import os
import random
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp()
os.environ["ONCO_RESULTS_DIR"] = TMP
os.environ["ONCO_HTTP_TIMEOUT"] = "2"

from copilot import agent, contract, evaluation, llm, tools  # noqa: E402
from training.coordinator import tasks  # noqa: E402

LABELS = ["normal", "benign", "malignant"]


def model(**kw):
    m = {"id": "m1", "version": "v1", "tasks": ["classification"], "modalities": ["X-ray"], "anatomies": ["bone"],
         "state": "locally_reproduced", "permissions": {"inference": "allowed"}, "adapter_id": "a1",
         "output_kind": "classification", "label_names": LABELS}
    m.update(kw)
    return m


def req(**kw):
    r = {"request_id": "r1", "task": "classification", "modality": "X-ray", "anatomy": "bone",
         "model_id": "m1", "input_refs": ["btxrd:IMG1.jpeg"], "execution_authorization_ref": "auth1"}
    r.update(kw)
    return r


AUTH = {"auth1": {"granted": True, "scope": ["m1"]}}


def good_adapter(r):
    return {"task": r["task"], "outputs": {"probabilities": {"normal": 0.2, "benign": 0.5, "malignant": 0.3}}}


class ContractAcceptance(unittest.TestCase):
    """The acceptance table from the integration-contract proposal."""

    def run_(self, request, registry=None, adapters=None, auth=AUTH):
        calls = []

        def spy(r):
            calls.append(r)
            return (adapters or {}).get("impl", good_adapter)(r)
        ads = {"a1": spy}
        out = contract.execute(request, registry or [model()], ads, auth, contract.DEFAULT_SCHEMAS)
        return out, calls

    def test_missing_modality(self):
        out, calls = self.run_(req(modality=None))
        self.assertEqual(out["status"], "needs_input"); self.assertFalse(calls)

    def test_unknown_model(self):
        out, calls = self.run_(req(model_id="nope"))
        self.assertEqual(out["status"], "blocked"); self.assertEqual(out["error"]["code"], "unknown_model"); self.assertFalse(calls)

    def test_catalog_only(self):
        out, calls = self.run_(req(), [model(state="cataloged")])
        self.assertEqual(out["status"], "blocked"); self.assertFalse(calls)

    def test_permission_missing(self):
        out, calls = self.run_(req(), [model(permissions={"inference": "unknown"})])
        self.assertEqual(out["status"], "blocked"); self.assertFalse(calls)

    def test_authorization_unresolved(self):
        for ref in (None, True, "missing"):
            out, calls = self.run_(req(execution_authorization_ref=ref))
            self.assertEqual(out["error"]["code"], "authorization_unresolved"); self.assertFalse(calls)

    def test_authorization_wrong_scope(self):
        out, calls = self.run_(req(), auth={"auth1": {"granted": True, "scope": ["other"]}})
        self.assertEqual(out["status"], "blocked"); self.assertFalse(calls)

    def test_incompatible_input(self):
        out, calls = self.run_(req(anatomy="brain"))
        self.assertEqual(out["error"]["code"], "incompatible_input"); self.assertFalse(calls)

    def test_adapter_exception(self):
        def boom(r):
            raise RuntimeError("gpu fell over")
        out, _ = self.run_(req(), adapters={"impl": boom})
        self.assertEqual(out["status"], "failed"); self.assertIsNone(out["native_output"])

    def test_malformed_output(self):
        out, _ = self.run_(req(), adapters={"impl": lambda r: {"task": r["task"], "outputs": {"probabilities": {"normal": 2}}}})
        self.assertEqual(out["status"], "failed"); self.assertEqual(out["error"]["code"], "malformed_output")

    def test_success_preserves_output(self):
        out, calls = self.run_(req())
        self.assertEqual(out["status"], "succeeded"); self.assertEqual(len(calls), 1)
        self.assertEqual(out["native_output"]["probabilities"]["benign"], 0.5)
        self.assertTrue(out["started_at"] and out["finished_at"])

    def test_discovery_never_selects(self):
        d = contract.discover({"task": "classification", "modality": "X-ray", "anatomy": "bone"}, [model(), model(id="m2")])
        self.assertEqual(len(d["candidates"]), 2)
        self.assertNotIn("selected", d)


def preds(model_id, n=120, skill=0.8, seed=0):
    rng = random.Random(seed)
    rows = []
    for i in range(n):
        y = i % 3
        p = [rng.random() * 0.3 for _ in range(3)]
        if rng.random() < skill:
            p[y] += 1.0
        else:
            p[rng.randrange(3)] += 1.0
        s = sum(p)
        rows.append({"sample_id": f"s{i}", "label": LABELS[y], "probabilities": [x / s for x in p]})
    return {"model_id": model_id, "partition": "external_test", "label_names": LABELS, "rows": rows}


class Evaluation(unittest.TestCase):
    def test_perfect(self):
        p = preds("a", skill=1.0)
        m = evaluation.evaluate(p, bootstrap=50)
        self.assertAlmostEqual(m["balanced_accuracy"], 1.0)
        self.assertAlmostEqual(m["per_class"]["malignant"]["auc_ovr"], 1.0)

    def test_auc_ties(self):
        self.assertAlmostEqual(evaluation._auc([0.5, 0.5, 0.5, 0.5], [True, False, True, False]), 0.5)
        self.assertAlmostEqual(evaluation._auc([0.1, 0.4, 0.35, 0.8], [False, False, True, True]), 0.75)

    def test_compare_detects_better(self):
        r = evaluation.compare(preds("a", 600, 0.95, 1), preds("b", 600, 0.5, 2), bootstrap=200)
        self.assertGreater(r["balanced_accuracy_delta"], 0.2)
        self.assertTrue(r["verdict"].startswith("A better"))
        self.assertLess(r["mcnemar"]["p_value"], 0.001)

    def test_compare_refuses_different_samples(self):
        b = preds("b"); b["rows"] = b["rows"][:-1]
        with self.assertRaises(ValueError):
            evaluation.compare(preds("a"), b, bootstrap=10)

    def test_rejects_bad_probabilities(self):
        p = preds("a"); p["rows"][0]["probabilities"] = [0.9, 0.9, 0.9]
        with self.assertRaises(ValueError):
            evaluation.evaluate(p)


class Tools(unittest.TestCase):
    def test_schemas_match_impl(self):
        names = {s["function"]["name"] for s in tools.SCHEMAS}
        self.assertEqual(names, set(tools.IMPL))

    def test_specify_dataset_sample_size(self):
        s = tools.call("specify_dataset", {"task": "classification", "modality": "x-ray", "anatomy": "bone",
                                           "expected_sensitivity": 0.85, "ci_half_width": 0.07})
        self.assertEqual(s["independent_test_set"]["min_positive_cases"], 100)  # 1.96^2*.85*.15/.07^2 = 99.96
        self.assertEqual(s["modality"], "X-ray")

    def test_find_datasets_filters(self):
        d = tools.call("find_datasets", {"modality": "CT", "anatomy": "lung"})
        ids = {x["id"] for x in d["catalog_matches"]}
        self.assertEqual(ids, {"lidc-idri", "luna16"})

    def test_bad_arguments_rejected(self):
        r = tools.call("specify_dataset", {"task": "classification"})
        self.assertEqual(r["status"], "needs_input")
        r = tools.call("plan_training", {"path": "yolo", "model_id": "x", "dataset_id": "y"})
        self.assertEqual(r["status"], "needs_input")

    def test_plan_never_submits(self):
        r = tools.call("plan_training", {"path": "transfer_learning", "model_id": "btxrd-medsiglip-head", "dataset_id": "btxrd"})
        self.assertFalse(r["submitted"]); self.assertEqual(r["status"], "blocked")

    def test_result_paths_confined(self):
        r = tools.call("evaluate_model", {"predictions": "../../etc/passwd"})
        self.assertEqual(r["status"], "blocked")

    def test_run_specialist_blocked_until_trained(self):
        r = tools.call("run_specialist", {"model_id": "btxrd-medsiglip-head", "task": "classification", "modality": "X-ray",
                                          "anatomy": "bone", "input_ref": "btxrd:IMG000001.jpeg"})
        self.assertEqual(r["status"], "blocked"); self.assertEqual(r["error"]["code"], "catalog_only")

    def test_literature_fails_soft_offline(self):
        r = tools.call("search_literature", {"query": "osteosarcoma radiograph deep learning"})
        self.assertTrue("results" in r or r.get("error") == "unavailable")


class EndToEndSpecialist(unittest.TestCase):
    """Trained-head adapter: blocked -> authorized -> succeeded with a real computation."""

    def test_flow(self):
        out = Path(TMP)
        (out / "btxrd-medsiglip-head.card.json").write_text(json.dumps({"version": "test"}))
        (out / "btxrd-medsiglip-head.head.json").write_text(json.dumps({
            "label_names": LABELS, "weights": [[1, 0], [0, 1], [-1, -1]], "bias": [0, 0, 0], "mean": [0, 0], "scale": [1, 1]}))
        (out / "btxrd-medsiglip-head.embeddings.json").write_text(json.dumps({"IMG7.jpeg": [0.0, 3.0]}))
        args = {"model_id": "btxrd-medsiglip-head", "task": "classification", "modality": "X-ray", "anatomy": "bone",
                "input_ref": "btxrd:IMG7.jpeg", "execution_authorization_ref": "demo"}
        self.assertEqual(tools.call("run_specialist", args)["error"]["code"], "authorization_unresolved")
        (out / "authorizations.json").write_text(json.dumps({"demo": {"granted": True, "scope": ["btxrd-medsiglip-head"]}}))
        r = tools.call("run_specialist", args)
        self.assertEqual(r["status"], "succeeded")
        probs = r["native_output"]["probabilities"]
        self.assertEqual(max(probs, key=probs.get), "benign")
        missing = tools.call("run_specialist", {**args, "input_ref": "btxrd:NOPE.jpeg"})
        self.assertEqual(missing["status"], "failed")
        for f in out.glob("btxrd-medsiglip-head.*"):
            f.unlink()
        (out / "authorizations.json").unlink()


class Agent(unittest.TestCase):
    def test_mock_loop_calls_tools_and_finishes(self):
        events = []
        agent.run(llm.MockChat(), [{"role": "user", "content": "What data do I need for a bone x-ray model and which model should I use?"}], events.append)
        names = [e["name"] for e in events if e["type"] == "tool_call"]
        self.assertIn("specify_dataset", names); self.assertIn("find_models", names)
        self.assertEqual(events[-1]["type"], "message")

    def test_tool_errors_do_not_crash(self):
        class Bad:
            name = "bad"
            n = 0
            def chat(self, messages, tools_):
                self.n += 1
                if self.n == 1:
                    return {"content": "", "tool_calls": [{"id": "c1", "function": {"name": "nope", "arguments": "{oops"}}]}
                return {"content": "done", "tool_calls": []}
        events = []
        agent.run(Bad(), [{"role": "user", "content": "x"}], events.append)
        res = next(e for e in events if e["type"] == "tool_result")
        self.assertEqual(res["result"]["status"], "needs_input")
        self.assertEqual(events[-1]["text"], "done")


class Server(unittest.TestCase):
    def test_http(self):
        port = 7900 + random.randrange(90)
        proc = subprocess.Popen([sys.executable, "-B", "-m", "copilot.server", "--port", str(port)], cwd=ROOT,
                                env={**os.environ, "ONCO_LLM_BASE_URL": ""}, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            base = f"http://127.0.0.1:{port}"
            for _ in range(50):
                try:
                    urllib.request.urlopen(base + "/api/status", timeout=1); break
                except OSError:
                    time.sleep(0.1)
            st = json.loads(urllib.request.urlopen(base + "/api/status").read())
            self.assertTrue(st["mock"])
            self.assertIn(b"OncoCopilot", urllib.request.urlopen(base + "/").read())
            body = json.dumps({"messages": [{"role": "user", "content": "find datasets for lung CT"}]}).encode()
            r = urllib.request.urlopen(urllib.request.Request(base + "/api/chat", data=body, headers={"Content-Type": "application/json"}), timeout=30)
            evs = [json.loads(l[6:]) for l in r.read().decode().split("\n\n") if l.startswith("data: ")]
            self.assertEqual(evs[-1]["type"], "done")
            self.assertTrue(any(e["type"] == "tool_result" and e["name"] == "find_datasets" for e in evs))
            with self.assertRaises(urllib.error.HTTPError):
                urllib.request.urlopen(base + "/../copilot/server.py")
        finally:
            proc.terminate(); proc.wait(5)
            if proc.stdout:
                proc.stdout.close()
            if proc.stderr:
                proc.stderr.close()


class BTXRDPrepare(unittest.TestCase):
    def test_source_held_out_and_duplicates(self):
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow is needed for the optional near-duplicate image test")
        root = Path(tempfile.mkdtemp())
        (root / "images").mkdir()
        rows = []
        rng = random.Random(3)
        for i in range(61):
            center = 1 if i < 40 else (2 if i < 50 else 3)
            lab = i % 3
            name = f"IMG{i:06d}.jpeg"
            path = root / "images" / name
            if i == 45:    # exact byte copy of a center-1 image
                path.write_bytes((root / "images" / "IMG000003.jpeg").read_bytes())
            elif i == 46:  # re-encoded (near-duplicate) copy of a center-1 image
                Image.open(root / "images" / "IMG000004.jpeg").save(path, quality=60)
            elif i == 60:  # corrupt file
                path.write_bytes(b"not a jpeg")
            else:
                img = Image.new("L", (32, 32))
                img.putdata([rng.randrange(256) for _ in range(32 * 32)])
                img.resize((128, 128)).save(path, quality=95)
            rows.append({"image_id": name, "center": center, "tumor": int(lab > 0), "benign": int(lab == 1), "malignant": int(lab == 2)})
        with open(root / "dataset.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
        out = Path(tempfile.mkdtemp())
        subprocess.run([sys.executable, "-m", "training.btxrd.prepare", "--root", str(root), "--out", str(out)],
                       cwd=ROOT, check=True, capture_output=True)
        split = json.loads((out / "btxrd_split.json").read_text())
        self.assertEqual(split["status"], "exploratory_only")
        self.assertIs(split["ready_for_training"], False)
        with (out / "btxrd_manifest.csv").open(newline="") as stream:
            man = list(csv.DictReader(stream))
        by = {r["image_id"]: r for r in man}
        self.assertNotIn("IMG000045.jpeg", by)  # cross-source exact pair quarantined
        self.assertNotIn("IMG000003.jpeg", by)
        self.assertTrue(all(r["split"] == "external_test" for r in man if r["center"] != "1"))
        self.assertTrue(all(r["split"] in ("train", "validation") for r in man if r["center"] == "1"))
        self.assertEqual(by["IMG000046.jpeg"]["split"], "external_test")  # visual match needs review
        self.assertGreaterEqual(split["duplicates"]["exact_pairs_in_release"], 1)
        self.assertGreaterEqual(split["duplicates"]["near_candidate_pairs"], 1)
        self.assertEqual(split["excluded"].get("cross_source_exact_duplicate"), 2)
        self.assertEqual(split["excluded"].get("unreadable_image"), 1)
        self.assertEqual(sum(split["counts"]["external_test"].values()), 19)


class TaskBank(unittest.TestCase):
    def test_heldout_is_disjoint(self):
        train, held = tasks.build()
        self.assertTrue(train and held)
        self.assertFalse({t["prompt"] for t in train} & {t["prompt"] for t in held})
        self.assertFalse({t["anatomy"] for t in train} & tasks.HELDOUT_ANATOMY)
        names = {s["function"]["name"] for s in tools.SCHEMAS}
        for t in train + held:
            self.assertTrue(set(t["required_tools"]) <= names)


if __name__ == "__main__":
    unittest.main()
