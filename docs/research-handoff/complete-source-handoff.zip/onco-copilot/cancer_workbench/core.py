"""Offline registry, evidence checks, curriculum preparation, and job plans.

This module does not fetch weights, call a remote model, or submit compute.
"""

from collections import Counter, defaultdict
import copy
import json
import math
import hashlib
from pathlib import Path


PATHS = {
    "specialist_tools": ["validate adapter", "evaluate specialist", "export reviewed tool-use examples", "compare coordinator with unchanged base"],
    "transfer_learning": ["audit data", "extract permitted frozen features", "train task head", "evaluate on held-out real labels"],
    "distillation": ["audit teacher rights and provenance", "evaluate teacher", "generate training-only teacher targets", "train student", "compare student, teacher, and supervised baseline"],
}


def _finite_positive(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def _validate_arguments(value, schema):
    kinds = {"object": dict, "array": list, "string": str, "boolean": bool,
             "integer": int, "number": (int, float), "null": type(None)}
    kind = schema.get("type")
    if kind and (kind not in kinds or not isinstance(value, kinds[kind])):
        raise ValueError("Tool argument type mismatch")
    if kind in ("number", "integer") and (isinstance(value, bool) or not math.isfinite(value)):
        raise ValueError("Tool numeric argument must be finite")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError("Tool argument is outside its enum")
    if isinstance(value, dict):
        if set(schema.get("required", [])) - set(value):
            raise ValueError("Missing required tool arguments")
        properties = schema.get("properties", {})
        if schema.get("additionalProperties") is False and set(value) - set(properties):
            raise ValueError("Unknown tool arguments")
        for key in value.keys() & properties.keys():
            _validate_arguments(value[key], properties[key])
    if isinstance(value, list) and "items" in schema:
        for item in value:
            _validate_arguments(item, schema["items"])


def route_models(request, registry):
    """Return compatibility reasons; never infer compatibility from model prose."""
    required = ("task", "modality", "anatomy")
    if any(not request.get(k) for k in required):
        raise ValueError("Request needs task, modality, and anatomy")
    matches, rejected = [], []
    for model in registry:
        reasons = []
        keys = {"task": "tasks", "modality": "modalities", "anatomy": "anatomies"}
        for field in required:
            if request[field] not in model.get(keys[field], []):
                reasons.append("unsupported " + field)
        missing = sorted(set(model.get("required_channels", [])) - set(request.get("channels", [])))
        if missing:
            reasons.append("missing channels: " + ", ".join(missing))
        for field in model.get("required_fields", []):
            if not request.get(field):
                reasons.append("missing required input: " + field)
        if reasons:
            rejected.append({"model_id": model["id"], "reasons": reasons})
        else:
            runnable = (model.get("state") == "locally_reproduced"
                        and model.get("permissions", {}).get("inference") == "allowed"
                        and bool(model.get("adapter_id")))
            matches.append({"model_id": model["id"], "version": model.get("version"),
                            "runnable": runnable, "state": model.get("state", "cataloged"),
                            "evidence": model.get("evidence", []),
                            "note": "Compatibility match is not a clinical validation claim"})
    return {"compatible": matches, "rejected": rejected, "selected": None,
            "decision": "review_candidates" if matches else "abstain_no_compatible_model"}


def execute_specialist(model, request, adapters):
    """Call an explicitly installed adapter; the default registry has none."""
    decision = route_models(request, [model])
    if not decision["compatible"] or not decision["compatible"][0]["runnable"]:
        raise ValueError("Model is incompatible, not reproduced, or not permitted for inference")
    adapter_id = model["adapter_id"]
    if adapter_id not in adapters:
        raise ValueError("No installed adapter for this model")
    result = adapters[adapter_id](copy.deepcopy(request))
    if not isinstance(result, dict) or result.get("task") != request["task"]:
        raise ValueError("Adapter returned an invalid task envelope")
    if not isinstance(result.get("outputs"), dict):
        raise ValueError("Adapter must return observed outputs")
    return {"model_id": model["id"], "model_version": model["version"],
            "task": request["task"], "observed": True, "result": result}


def audit_dataset(spec, rows, files_root=None):
    """Audit declared records, not image truth, consent, or label correctness.

    Checks group/split and declared digest overlap. With files_root, hashes
    referenced local files beneath that directory; never follows outside paths.
    """
    findings = []
    def add(level, code, detail):
        findings.append({"level": level, "code": code, "detail": detail})
    for key in ("id", "version", "source_url", "task", "modality", "anatomy", "label_definitions", "reference_standard"):
        if not spec.get(key):
            add("blocker", "missing_evidence", key)
    if spec.get("permissions", {}).get("training") != "allowed":
        add("blocker", "training_rights_unresolved", "Record reviewed source terms before training")
    if spec.get("labels_reviewed") is not True:
        add("blocker", "labels_not_reviewed", "Human reference-standard and label review is required")
    if not rows:
        add("blocker", "empty_dataset", "No sample records")
    seen_ids, groups, hashes = set(), defaultdict(set), defaultdict(set)
    counts, by_split = Counter(), defaultdict(Counter)
    file_checks_passed = files_root is not None
    root = Path(files_root).resolve() if files_root is not None else None
    allowed_labels = set(spec.get("label_definitions", {}))
    for i, row in enumerate(rows):
        sample_id = row.get("sample_id")
        split = row.get("split")
        label = row.get("label")
        if not sample_id or sample_id in seen_ids:
            add("blocker", "invalid_sample_id", f"row {i}")
        seen_ids.add(sample_id)
        if split not in ("train", "validation", "test"):
            add("blocker", "invalid_split", f"row {i}")
        if label not in allowed_labels:
            add("blocker", "unknown_label", f"row {i}")
        group = row.get("patient_id")
        if group:
            groups[group].add(split)
        else:
            add("blocker", "patient_group_unknown", f"row {i}: patient independence cannot be verified")
        digest = row.get("sha256", "")
        if len(digest) != 64 or any(c not in "0123456789abcdefABCDEF" for c in digest):
            add("blocker", "invalid_declared_digest", f"row {i}")
        else:
            hashes[digest.lower()].add(split)
        if root is not None:
            file_path = Path(str(row.get("file_path", "")))
            resolved = (root / file_path).resolve()
            if not str(row.get("file_path", "")) or file_path.is_absolute() or not resolved.is_relative_to(root):
                add("blocker", "unsafe_file_reference", f"row {i}")
                file_checks_passed = False
            else:
                try:
                    hasher = hashlib.sha256()
                    with resolved.open("rb") as stream:
                        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                            hasher.update(chunk)
                    if hasher.hexdigest() != digest.lower():
                        add("blocker", "file_digest_mismatch", f"row {i}")
                        file_checks_passed = False
                except OSError:
                    add("blocker", "file_unreadable", f"row {i}")
                    file_checks_passed = False
        counts[label] += 1
        by_split[split][label] += 1
    if any(len(splits) > 1 for splits in groups.values()):
        add("blocker", "patient_leakage", "A patient occurs in multiple partitions")
    if any(len(splits) > 1 for splits in hashes.values()):
        add("blocker", "duplicate_leakage", "A declared image digest occurs in multiple partitions")
    for split in ("train", "validation", "test"):
        if not by_split[split]:
            add("blocker", "missing_partition", split)
        for label in sorted(allowed_labels):
            if not by_split[split][label]:
                add("warning", "class_missing_from_partition", split + ": " + label)
    if counts and min(counts.values()) * 5 < max(counts.values()):
        add("warning", "class_imbalance", "Review minority-class performance and training sampling")
    if root is None and spec.get("file_hashes_verified") is True:
        add("warning", "integrity_attestation_only", "File integrity was asserted by the manifest, not measured in this audit")
    if not file_checks_passed and spec.get("file_hashes_verified") is not True:
        add("blocker", "file_integrity_unverified", "Declared digests have not been independently checked against files")
    if not spec.get("external_validation_source"):
        add("warning", "external_validation_missing", "Internal split checks do not establish external generalization")
    if not spec.get("pretraining_overlap_review"):
        add("warning", "pretraining_overlap_unknown", "Inspect overlap with teacher/backbone pretraining")
    return {"dataset_id": spec.get("id"), "dataset_version": spec.get("version"),
            "task": spec.get("task"), "modality": spec.get("modality"), "anatomy": spec.get("anatomy"),
            "status": "blocked" if any(x["level"] == "blocker" for x in findings) else "declared_checks_passed",
            "findings": findings, "class_counts": dict(counts),
            "counts_by_split": {k: dict(v) for k, v in by_split.items()},
            "scope": "Declared manifest audit; no image or label-truth inspection",
            "file_integrity": "measured_pass" if file_checks_passed else ("measured_fail" if root is not None else "not_measured"),
            "truth_certified": False, "clinical_accuracy_established": False}


def plan_experiment(path, model, dataset_audit=None, budget=None):
    """Produce a draft plan; never submit it or silently grant execution."""
    if path not in PATHS:
        raise ValueError("Unknown reuse path")
    blockers = []
    permissions = model.get("permissions", {})
    permission = {"specialist_tools": "inference", "transfer_learning": "adaptation", "distillation": "distillation"}[path]
    if permissions.get(permission) != "allowed":
        blockers.append("Reviewed permission required for " + permission)
    if model.get("state") != "locally_reproduced":
        blockers.append("Reproduce model and preprocessing before this experiment")
    if path != "specialist_tools" and (not dataset_audit or dataset_audit.get("status") != "declared_checks_passed"):
        blockers.append("Dataset audit must pass before training")
    if path != "specialist_tools" and dataset_audit:
        if dataset_audit.get("modality") not in model.get("modalities", []):
            blockers.append("Training dataset modality does not match the model")
        if dataset_audit.get("anatomy") not in model.get("anatomies", []):
            blockers.append("Training dataset anatomy does not match the model")
    if path == "distillation" and not model.get("teacher_evaluation"):
        blockers.append("Teacher requires a task-specific evaluation record")
    budget = budget or {}
    for name in ("max_hours", "max_storage_gb"):
        if not _finite_positive(budget.get(name)):
            blockers.append("Explicit positive " + name + " required")
    gpu_count = budget.get("gpu_count")
    if not isinstance(gpu_count, int) or isinstance(gpu_count, bool) or gpu_count < 0:
        blockers.append("Explicit nonnegative integer gpu_count required")
    if not budget.get("profile_reference"):
        blockers.append("Measured resource profile required; runtime is not estimated from model name")
    return {"path": path, "model_id": model.get("id"), "model_version": model.get("version"),
            "dataset_id": (dataset_audit or {}).get("dataset_id"),
            "dataset_version": (dataset_audit or {}).get("dataset_version"),
            "status": "blocked" if blockers else "draft_ready_for_review", "blockers": blockers,
            "steps": PATHS[path], "budget": budget, "submitted": False,
            "quality_requirements": ["held-out real-label evaluation", "retain general-reasoning regression suite",
                                     "patient and duplicate grouping", "measure specialist and complete pipeline",
                                     "do not promote a model based only on teacher agreement"]}


def export_curriculum(records):
    """Return TRL-style tool conversations only from reviewed, observed traces."""
    examples = []
    for record in records:
        if record.get("reviewed") is not True or record.get("observed_tool_results") is not True:
            raise ValueError("Curriculum requires reviewed traces with observed tool results")
        if not record.get("source_refs"):
            raise ValueError("Curriculum needs source/provenance references")
        tools = record.get("tools", [])
        schemas = {}
        for tool in tools:
            function = tool.get("function", {})
            name = function.get("name")
            if not name or name in schemas:
                raise ValueError("Tool names must be present and unique")
            schemas[name] = function.get("parameters", {})
        pending, used_ids = {}, set()
        messages = record.get("messages", [])
        observed_count = 0
        for message in messages:
            if message.get("role") not in ("system", "user", "assistant", "tool"):
                raise ValueError("Invalid conversation role")
            if pending and message.get("role") != "tool":
                raise ValueError("Every pending call needs a tool response before conversation continues")
            for call in message.get("tool_calls", []):
                if message.get("role") != "assistant":
                    raise ValueError("Only assistant messages can call tools")
                call_id, function = call.get("id"), call.get("function", {})
                name = function.get("name")
                if not call_id or call_id in used_ids or name not in schemas:
                    raise ValueError("Invalid tool call identity")
                args = function.get("arguments", {})
                args = json.loads(args) if isinstance(args, str) else args
                if not isinstance(args, dict):
                    raise ValueError("Tool arguments must be an object")
                schema = schemas[name]
                _validate_arguments(args, schema)
                pending[call_id] = name
                used_ids.add(call_id)
            if message.get("role") == "tool":
                call_id = message.get("tool_call_id")
                if call_id not in pending or not message.get("content"):
                    raise ValueError("Orphaned or empty tool result")
                pending.pop(call_id)
                observed_count += 1
        if pending or not observed_count or not messages or messages[-1].get("role") != "assistant":
            raise ValueError("Trace needs completed tool calls and a final assistant response")
        examples.append({"messages": copy.deepcopy(messages), "tools": copy.deepcopy(tools),
                         "source_refs": copy.deepcopy(record["source_refs"])})
    return examples
