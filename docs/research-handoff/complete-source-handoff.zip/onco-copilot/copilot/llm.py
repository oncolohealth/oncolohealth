"""Chat-completions clients.

OpenAIChat talks to any OpenAI-compatible server: vLLM serving Gemma 4 31B on
NPS (through an SSH tunnel), SGLang, or a hosted endpoint.

Environment:
  ONCO_LLM_BASE_URL   e.g. http://localhost:8000/v1   (unset -> offline mock)
  ONCO_LLM_MODEL      e.g. google/gemma-4-31B-it
  ONCO_LLM_API_KEY    optional
  ONCO_LLM_THINKING   "1" to enable Gemma reasoning (default off for snappy tool use)
"""

import json
import os
import re
import urllib.request
import uuid


class OpenAIChat:
    def __init__(self, base_url, model, api_key=None, thinking=False, timeout=180):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.thinking = thinking
        self.timeout = timeout
        self.name = f"{model} @ {self.base_url}"

    def chat(self, messages, tools):
        body = {"model": self.model, "messages": messages, "tools": tools, "tool_choice": "auto",
                "temperature": 1.0 if self.thinking else 0.7, "top_p": 0.95 if self.thinking else 0.8,
                "max_tokens": 4096, "chat_template_kwargs": {"enable_thinking": self.thinking}}
        if not self.thinking:
            body["presence_penalty"] = 1.5
        req = urllib.request.Request(self.base_url + "/chat/completions", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json",
                                              **({"Authorization": "Bearer " + self.api_key} if self.api_key else {})})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = json.loads(resp.read().decode())
        msg = data["choices"][0]["message"]
        return {"content": msg.get("content") or "", "reasoning": msg.get("reasoning_content") or msg.get("reasoning"),
                "tool_calls": msg.get("tool_calls") or [], "usage": data.get("usage")}


def _call(name, args):
    return {"id": "call_" + uuid.uuid4().hex[:8], "type": "function",
            "function": {"name": name, "arguments": json.dumps(args)}}


class MockChat:
    """Deterministic offline planner so the UI and tools can be demoed without a GPU.

    It picks tools by keywords, then summarizes their observed outputs. It is
    clearly labeled as a mock in the UI.
    """

    name = "offline mock (set ONCO_LLM_BASE_URL to use Gemma)"

    MODS = {"x-ray": "X-ray", "xray": "X-ray", "radiograph": "X-ray", " ct": "CT", "mri": "MRI",
            "histolog": "pathology", "patholog": "pathology", "slide": "pathology", "genom": "genomics"}
    ANAT = ["bone", "lung", "brain", "prostate", "breast", "skin", "chest", "liver", "colon"]

    def _parse(self, text):
        t = " " + text.lower()
        mod = next((v for k, v in self.MODS.items() if k in t), None)
        anat = next((a for a in self.ANAT if a in t), None)
        if "osteosarcoma" in t or "bone tumor" in t or "btxrd" in t:
            anat, mod = anat or "bone", mod or "X-ray"
        return mod, anat

    def chat(self, messages, tools):
        user = next(m["content"] for m in reversed(messages) if m["role"] == "user")
        tool_msgs = []
        for m in reversed(messages):
            if m["role"] == "user":
                break
            if m["role"] == "tool":
                tool_msgs.append(m)
        mod, anat = self._parse(user)
        t = user.lower()
        task = "segmentation" if "segment" in t else ("detection" if "detect" in t else "classification")
        if not tool_msgs:
            calls = []
            if any(k in t for k in ("compare", "versus", " vs ", "test my", "against")):
                calls.append(_call("list_results", {}))
            if any(k in t for k in ("dataset", "data ", "source")):
                calls.append(_call("find_datasets", {k: v for k, v in (("modality", mod), ("anatomy", anat)) if v}))
            if any(k in t for k in ("what data", "need", "requirement", "spec", "how many")):
                calls.append(_call("specify_dataset", {"task": task, "modality": mod or "X-ray", "anatomy": anat or "bone"}))
            if any(k in t for k in ("model", "best", "recommend", "baseline")):
                calls.append(_call("find_models", {"task": task, **{k: v for k, v in (("modality", mod), ("anatomy", anat)) if v}}))
            if any(k in t for k in ("train", "plan", "gpu", "nps")):
                calls.append(_call("plan_training", {"path": "transfer_learning", "model_id": "btxrd-medsiglip-head", "dataset_id": "btxrd", "gpu_count": 1}))
            if any(k in t for k in ("audit", "leak", "split")):
                calls.append(_call("audit_dataset", {"dataset_id": "btxrd"}))
            if any(k in t for k in ("paper", "literature", "research", "method", "state of the art", "sota", "cite")) or not calls:
                q = re.sub(r"[^a-z0-9 ]", " ", t)
                q = " ".join(w for w in q.split() if len(w) > 3)[:120] or "cancer deep learning"
                calls.append(_call("search_literature", {"query": q, "max_results": 5, "since_year": 2021}))
            return {"content": "", "reasoning": None, "tool_calls": calls[:4]}
        lines = ["**Offline mock summary** (connect Gemma for real reasoning). Observed tool results:"]
        for m in reversed(tool_msgs):
            try:
                d = json.loads(m["content"])
            except ValueError:
                continue
            name = m.get("name", "tool")
            if name == "search_literature":
                for r in (d.get("results") or [])[:5]:
                    lines.append(f"- [{r['title']}]({r['url']}) ({r.get('year')})")
                if d.get("error"):
                    lines.append("- Literature search unavailable here: " + d["detail"])
            elif name == "find_datasets":
                for x in d.get("catalog_matches", []):
                    lines.append(f"- Dataset **{x['name']}**: {x['size']}; access: {x.get('license') or x.get('access')}")
            elif name == "find_models":
                rm = d.get("registry_match", {})
                for c in rm.get("candidates", []):
                    lines.append(f"- Registry candidate **{c['model_id']}** (state {c['state']})")
                for g in d.get("general_backbones", []):
                    lines.append(f"- Backbone **{g['model_id']}** ({g.get('params')})")
            elif name == "specify_dataset":
                ts = d.get("independent_test_set", {})
                lines.append(f"- Test set needs at least {ts.get('min_positive_cases')} positive and {ts.get('min_negative_cases')} negative independent patients (CI half-width {ts.get('target_ci_half_width')}).")
            elif name == "plan_training":
                lines.append(f"- Training plan status **{d.get('status')}**; blockers: {', '.join(d.get('blockers', [])) or 'none'}")
            elif name == "audit_dataset":
                lines.append(f"- Audit status **{d.get('status')}**; cautions: {'; '.join(d.get('cautions', []))}")
            elif name == "list_results":
                for r in d.get("results", []):
                    lines.append(f"- {r['model_id']}: balanced accuracy {r['balanced_accuracy']:.3f} on {r['partition']}")
                if not d.get("results"):
                    lines.append("- No experiment results yet.")
        return {"content": "\n".join(lines), "reasoning": None, "tool_calls": []}


def from_env():
    base = os.environ.get("ONCO_LLM_BASE_URL")
    if not base:
        return MockChat()
    return OpenAIChat(base, os.environ.get("ONCO_LLM_MODEL", "google/gemma-4-31B-it"),
                      os.environ.get("ONCO_LLM_API_KEY"), os.environ.get("ONCO_LLM_THINKING") == "1")
