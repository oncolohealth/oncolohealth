"""Execution contract between the coordinator and specialist models.

Implements the integration-contract proposal: explicit request fields,
gated execution, and a result envelope that never invents a prediction.
Discovery (which models *could* run) is kept separate from execution
(running one explicitly selected model).
"""

import copy
import time
import uuid

from cancer_workbench.core import route_models

STATUSES = ("needs_input", "blocked", "failed", "succeeded")
OUTPUT_KINDS = ("classification", "detection", "segmentation", "embedding")


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _envelope(request, status, *, model=None, adapter_id=None, output_kind=None,
              native_output=None, error=None, started_at=None):
    return {
        "request_id": request.get("request_id"),
        "run_id": uuid.uuid4().hex,
        "model_id": (model or {}).get("id") or request.get("model_id"),
        "model_revision": (model or {}).get("version") or request.get("model_revision"),
        "adapter_id": adapter_id,
        "status": status,
        "output_kind": output_kind,
        "native_output": native_output,
        "input_refs": copy.deepcopy(request.get("input_refs", [])),
        "preprocessing_revision": (model or {}).get("preprocessing_revision"),
        "evidence_refs": copy.deepcopy((model or {}).get("evidence", [])),
        "error": error,
        "started_at": started_at,
        "finished_at": _now() if started_at else None,
    }


def _err(code, detail):
    return {"code": code, "detail": detail}


def discover(request, registry):
    """Return candidate models for a task. Never selects one silently."""
    missing = [k for k in ("task", "modality", "anatomy") if not request.get(k)]
    if missing:
        return {"status": "needs_input", "missing": missing, "candidates": [], "rejected": []}
    decision = route_models(request, registry)
    return {"status": "candidates" if decision["compatible"] else "no_compatible_model",
            "missing": [], "candidates": decision["compatible"], "rejected": decision["rejected"]}


def execute(request, registry, adapters, authorizations, output_schemas=None):
    """Run one explicitly selected specialist through every gate.

    authorizations: mapping of authorization reference -> record dict with
    {"granted": True, "scope": [model_id, ...]}. A boolean in the request is
    never accepted as authorization.
    """
    output_schemas = output_schemas or {}
    # Gate 1: required fields
    missing = [k for k in ("request_id", "task", "modality", "anatomy", "model_id") if not request.get(k)]
    if missing:
        return _envelope(request, "needs_input", error=_err("missing_fields", ", ".join(missing)))
    # Gate 2: exact registry record (no fallback)
    model = next((m for m in registry if m.get("id") == request["model_id"]), None)
    if model is None:
        return _envelope(request, "blocked", error=_err("unknown_model", "No registry record; no fallback is selected"))
    if request.get("model_revision") and request["model_revision"] != model.get("version"):
        return _envelope(request, "blocked", model=model, error=_err("revision_mismatch", "Requested revision differs from registry"))
    # Gate 3: compatibility, reproduced state, permission
    decision = route_models(request, [model])
    if not decision["compatible"]:
        reasons = decision["rejected"][0]["reasons"]
        return _envelope(request, "blocked", model=model, error=_err("incompatible_input", "; ".join(reasons)))
    if model.get("state") != "locally_reproduced":
        return _envelope(request, "blocked", model=model, error=_err("catalog_only", "Model has not been reproduced locally"))
    if model.get("permissions", {}).get("inference") != "allowed":
        return _envelope(request, "blocked", model=model, error=_err("permission_missing", "Inference permission not reviewed as allowed"))
    # Gate 4: authorization reference resolved independently
    ref = request.get("execution_authorization_ref")
    record = authorizations.get(ref) if isinstance(ref, str) else None
    if not record or record.get("granted") is not True or model["id"] not in record.get("scope", []):
        return _envelope(request, "blocked", model=model, error=_err("authorization_unresolved", "Execution authorization reference did not resolve"))
    adapter_id = model.get("adapter_id")
    adapter = adapters.get(adapter_id)
    if adapter is None:
        return _envelope(request, "blocked", model=model, error=_err("adapter_missing", "No installed adapter"))
    # Gate 5: adapter-specific input validation
    validator = getattr(adapter, "validate", None)
    if callable(validator):
        problem = validator(copy.deepcopy(request))
        if problem:
            return _envelope(request, "blocked", model=model, adapter_id=adapter_id, error=_err("adapter_input_invalid", str(problem)))
    # Gate 6: invoke once
    started = _now()
    try:
        result = adapter(copy.deepcopy(request))
    except Exception as exc:  # preserve failure, never invent output
        return _envelope(request, "failed", model=model, adapter_id=adapter_id, started_at=started,
                         error=_err("adapter_exception", type(exc).__name__ + ": " + str(exc)[:300]))
    # Gate 7: validate output
    kind = model.get("output_kind")
    schema_check = output_schemas.get(kind)
    ok = isinstance(result, dict) and isinstance(result.get("outputs"), dict) and kind in OUTPUT_KINDS
    if ok and schema_check:
        ok = bool(schema_check(result["outputs"], model))
    if not ok:
        return _envelope(request, "failed", model=model, adapter_id=adapter_id, started_at=started,
                         error=_err("malformed_output", "Adapter output failed schema validation"))
    # Gate 8: provenance recorded -> succeeded
    return _envelope(request, "succeeded", model=model, adapter_id=adapter_id, output_kind=kind,
                     native_output=copy.deepcopy(result["outputs"]), started_at=started)


def classification_schema(outputs, model):
    labels = model.get("label_names", [])
    probs = outputs.get("probabilities")
    return (isinstance(probs, dict) and list(probs) == labels
            and all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in probs.values())
            and abs(sum(probs.values()) - 1) < 1e-4)


DEFAULT_SCHEMAS = {"classification": classification_schema}
