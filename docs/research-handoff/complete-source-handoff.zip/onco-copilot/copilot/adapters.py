"""Installed specialist adapters.

An adapter receives a request whose input_refs look like "btxrd:IMG000123".
If the trained head and that image's cached embedding exist, it computes the
prediction for real. Otherwise it raises, and the contract reports `failed`
rather than inventing an output.

Authorizations are human-written records in results/authorizations.json:
{"researcher-demo": {"granted": true, "scope": ["btxrd-medsiglip-head"], "by": "reviewer"}}
"""

import json
import math
import os
from pathlib import Path

RESULTS = Path(os.environ.get("ONCO_RESULTS_DIR", Path(__file__).resolve().parent.parent / "results"))


def _load(name):
    p = RESULTS / name
    return json.loads(p.read_text()) if p.exists() else None


class EmbeddingHeadAdapter:
    """Logistic head over cached image embeddings (written by training/btxrd)."""

    def __init__(self, model_id):
        self.model_id = model_id

    def validate(self, request):
        refs = request.get("input_refs") or []
        if len(refs) != 1 or not str(refs[0]).startswith("btxrd:"):
            return "Expected exactly one input_ref of the form btxrd:<image_id>"
        return None

    def __call__(self, request):
        image_id = request["input_refs"][0].split(":", 1)[1]
        head = _load(f"{self.model_id}.head.json")
        if head is None:
            raise RuntimeError("Trained head not found; run the training job first")
        emb = _load(f"{self.model_id}.embeddings.json") or {}
        x = emb.get(image_id)
        if x is None:
            raise LookupError("No cached embedding for " + image_id)
        mean, scale = head.get("mean"), head.get("scale")
        if mean:
            x = [(v - m) / (s or 1.0) for v, m, s in zip(x, mean, scale)]
        logits = [b + sum(w * v for w, v in zip(ws, x)) for ws, b in zip(head["weights"], head["bias"])]
        top = max(logits)
        exps = [math.exp(z - top) for z in logits]
        tot = sum(exps)
        probs = {lab: e / tot for lab, e in zip(head["label_names"], exps)}
        return {"task": request["task"], "outputs": {"probabilities": probs, "image_id": image_id,
                                                     "computed_from": "cached embedding + trained head"}}


class PredictionLookupAdapter:
    """Returns a stored batch-inference output for a test image (e.g. the CNN)."""

    def __init__(self, model_id):
        self.model_id = model_id

    def validate(self, request):
        return EmbeddingHeadAdapter.validate(self, request)

    def __call__(self, request):
        image_id = request["input_refs"][0].split(":", 1)[1]
        pred = None
        for f in sorted(RESULTS.glob(f"{self.model_id}*.predictions.json")):
            data = json.loads(f.read_text())
            row = next((r for r in data["rows"] if r["sample_id"] == image_id), None)
            if row:
                pred = (data, row, f.name)
                break
        if not pred:
            raise LookupError("No stored inference output for " + image_id)
        data, row, fname = pred
        return {"task": request["task"], "outputs": {
            "probabilities": dict(zip(data["label_names"], row["probabilities"])),
            "image_id": image_id, "computed_from": "batch inference output " + fname}}


ADAPTERS = {
    "btxrd_medsiglip_head": EmbeddingHeadAdapter("btxrd-medsiglip-head"),
    "btxrd_cnn": PredictionLookupAdapter("btxrd-cnn-baseline"),
}


class _Auth(dict):
    def get(self, key, default=None):
        data = _load("authorizations.json") or {}
        return data.get(key, default)


AUTHORIZATIONS = _Auth()
