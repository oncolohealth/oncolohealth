"""Require explicit acknowledgement before exploratory BTXRD training jobs."""

import json
import os
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 -m training.btxrd.guard SPLIT_JSON")
    path = Path(sys.argv[1])
    if not path.is_file():
        raise SystemExit(f"BTXRD split missing at {path}; prepare it explicitly first")
    split = json.loads(path.read_text())
    if split.get("ready_for_training") is True and split.get("status") == "ready":
        return
    if split.get("status") == "exploratory_only" and os.environ.get("ONCO_ALLOW_EXPLORATORY_BTXRD") == "1":
        print("Exploratory image-level BTXRD run acknowledged; no patient-level or clinical claim")
        return
    raise SystemExit("BTXRD split is not training-ready: patient grouping/reference labels remain unresolved. "
                     "For an explicitly authorized exploratory run only, set ONCO_ALLOW_EXPLORATORY_BTXRD=1.")


if __name__ == "__main__":
    main()
